/*
 * hw.h
 *
 * Created on: October 7, 2012
 * Author: 
 */

#ifndef _KERNEL_MODULE_HW_H_
#define _KERNEL_MODULE_HW_H_

#define PortCountPerGroup        3    
#define DR_GroupX_Base( x )      ((x) * 4)
#define DR_GroupX_PortY( x, y )  ( DR_GroupX_Base(x) + y )

#define DR_BID_A                  0x14 // For version 0xA100
#define DR_BID_BE                 0x8  // For version 0xB100
#define DR_BID_MIC                0x28 // For MIC- 

static
__u32 const s_dioPortRegOffset[] = {
   DR_GroupX_PortY( 0, 0 ), DR_GroupX_PortY( 0, 1 ), DR_GroupX_PortY( 0, 2 ),
   DR_GroupX_PortY( 1, 0 ), DR_GroupX_PortY( 1, 1 ), DR_GroupX_PortY( 1, 2 ),
};

// DIO port group configuration register
#define PORTDIR_OUT   0
#define PORTDIR_IN    1
typedef union _GROUP_CTRL_REG{
   __u8 Value;
   struct{
      __u8 PCLowDir : 1;  // Port C lower nibble
      __u8 PBDir    : 1;  // Port B
      __u8 Reserved : 1;
      __u8 PCHighDir: 1;  // Port C higher nibble
      __u8 PADir    : 1;  // Port A
      __u8 Reserved2: 3;
   };
}GROUP_CTRL_REG;

#define DR_GroupX_Ctrl( x )      ( DR_GroupX_Base(x) + 3 )


#define INT_DISABLED          0
#define INT_SRC_PC0           1
#define INT_SRC_PC0_WITH_GATE 2
#define INT_SRC_TIMER1        3 
#define INT_SRC_COUNTER2      3 
#define TRIG_EDGE_RISING      1 
#define TRIG_EDGE_FALLING     0 

typedef union _DEV_INT_CSR{
   __u8 Value;
   struct{
      __u8 Grp0Mode : 2;
      __u8 Grp0Edge : 1;
      __u8 Grp0Flag : 1;
      __u8 Grp1Mode : 2;
      __u8 Grp1Edge : 1;
      __u8 Grp1Flag : 1;
   };
}DEV_INT_CSR;

#define DEV_INT_MASK   0x88
#define DR_INT_CSR     0x20

#define DR_CNTR0       0x18
#define DR_CNTR1       0x19
#define DR_CNTR2       0x1A
#define DR_CNTR_CTL    0x1B


#endif /* _KERNEL_MODULE_HW_H_ */
