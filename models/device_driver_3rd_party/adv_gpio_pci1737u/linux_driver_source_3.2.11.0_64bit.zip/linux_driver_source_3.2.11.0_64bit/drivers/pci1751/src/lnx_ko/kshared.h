/*
 * kshared.h
 *
 * Created on: October 7, 2012
 * Author: 
 */

#ifndef KERNEL_MODULE_SHARED_H_
#define KERNEL_MODULE_SHARED_H_

#include <linux/types.h>


#define ADVANTECH_VID 0x13fe
#define DEVICE_ID     0x1751
#define DEVICE_PID    BD_PCI1751
#define DEVICE_NAME   "PCI-1751"
#define DRIVER_NAME   "bio1751"

// ----------------------------------------------------------
// H/W feature and structures.
// ----------------------------------------------------------
#define DIO_PORT_COUNT		   6                     // 2 isolated DI, 2 isolated DO
#define DIO_CHL_COUNT         (DIO_PORT_COUNT * 8)
#define DI_INT_SRC_COUNT      2                     // CH#[0, 1, 16, 17]
#define DI_SNAP_SRC_COUNT     DI_INT_SRC_COUNT

#define CNTR_CHL_COUNT           3
#define CNTR_RES_IN_BIT          16
#define CNTR_DATA_SIZE           sizeof(__u16)
#define CNTR_MIN_VAL             2
#define CNTR_MAX_VAL             65535
#define CNTR_CLK_BASE            (10 * 1000 * 1000)
#define CNTR_IDLE                0

#define CNTR_RBUF_DEPTH          16
#define CNTR_RBUF_POSMASK        (CNTR_RBUF_DEPTH -1)
#define CNTR_CHK_PERIOD_NS       5000000UL
#define CNTR_CHK_PERIOD_MAX_NS   (10000000000ULL >> 4)
#define CNTR_VAL_THRESHOLD_BASE  10


enum KRNL_EVENT_IDX{
   KdxDevPropChged = 0,
   KdxDiBegin,
   KdxDiintChan16 = KdxDiBegin,
   KdxDiintChan40,
   KdxDiEnd = KdxDiintChan40,
   KdxCntBegin,
   KdxCntTmnalCnt1 = KdxCntBegin,
   KdxCntTimer1,
   KdxCntOneShot1,
   KdxCntTmnalCnt2,
   KdxCntTimer2,
   KdxCntOneShot2,
   KdxCntEnd = KdxCntOneShot2,
   KrnlSptedEventCount,
};

static inline __u32 GetEventKIndex(__u32 eventType)
{
   __u32 kdx;
   switch ( eventType )
   {
   case EvtPropertyChanged:   kdx = KdxDevPropChged;  break;
   case EvtDiintChannel016:   kdx = KdxDiintChan16;   break;
   case EvtDiintChannel040:   kdx = KdxDiintChan40;   break;
   case EvtCntTerminalCount1: kdx = KdxCntTmnalCnt1;  break;
   case EvtCntTimer1:         kdx = KdxCntTimer1;     break;
   case EvtCntOneShot1:       kdx = KdxCntOneShot1;   break;
   case EvtCntTerminalCount2: kdx = KdxCntTmnalCnt2;  break;
   case EvtCntTimer2:         kdx = KdxCntTimer2;     break;
   case EvtCntOneShot2:       kdx = KdxCntOneShot2;   break;
   default: kdx = -1; break;
   }
   return kdx;
}

// -----------------------------------------------------
// default values
// -----------------------------------------------------
#define DEF_INIT_ON_LOAD        1

// DIO default values
#define DEF_DIO_DIR             0x00
#define DEF_DO_STATE            0
#define DEF_DIINT_TRIGEDGE      RisingEdge
#define DEF_DIINT_GATECTRL      0

// CNTR default values
// If counter use external source, TimePulse function will disable 
#define DEF_CNTR_1_CLK_SRC      SigInternalClock // if want to use External source,please set SigCntClk1
#define DEF_CNTR_2_CLK_SRC      SigCntOut0 // Counter 0 cascade Counter 1 use SigCntOut0
                                           // Counter 1 clock source from Counter 0
                                           // if want to use external source, please set SigCntClk1
#define DEF_CNTR_3_CLK_SRC      SigInternalClock // if want to use External source,please set SigCntClk2

#define DEF_CNTR_CHIP_LOADVAL   ((1 << CNTR_RES_IN_BIT) - 1)
#define DEF_CNTR_CHIP_OPMODE    0
#define DEF_CNTR_OS_DELAY_COUNT 2
#define DEF_CNTR_TMR_DIVISOR    (CNTR_CLK_BASE / 200)
#define DEF_CNTR_FM_PERIOD      0

// ----------------------------------------------------------
// Device private data
// ----------------------------------------------------------
typedef struct _DI_SNAP
{
   __u8 Start;
   __u8 Count;
   __u8 State[DIO_PORT_COUNT];
} DI_SNAP;

typedef struct _CNTR_CONFIG
{
   // --------------------------------------------------------
   __u32  ChipClkSource[ CNTR_CHL_COUNT ];   
   __u32  ChipOpMode[CNTR_CHL_COUNT];
   __u32  ChipLoadValue[CNTR_CHL_COUNT];

   // --------------------------------------------------------
   __u32  OsDelayCount[CNTR_CHL_COUNT];
   // --------------------------------------------------------
   __u32  TmrDivisor[CNTR_CHL_COUNT];
   // --------------------------------------------------------
   __u32  FmPeroid[CNTR_CHL_COUNT];
}CNTR_CONFIG;

typedef struct _CNTR_STATE
{
   __u32     Operation;
   __u32     CanRead;
   __u32     AutoAdaptive;

   // ------------------------------------------
   __u32     CheckPeriod;
   __u32     Overflow;
   __u32     PrevValue;
   __u32     SummedValue;
   __s64     PrevTime;
   __u64     TotalTime;
   struct  {
      __u32  Head;
      __u32  Tail;
      __u32  CntrDelta[CNTR_RBUF_DEPTH];
      __u32  TimeDelta[CNTR_RBUF_DEPTH];
   };
}CNTR_STATE;

typedef struct _DEVICE_SHARED
{
   __u32   Size;           // Size of the structure
   __u32   ProductId;      // Device Type
   __u32   DeviceNumber;   // Zero-based device number
   __u32   SubsystemID;

   // HW Information
   __u32   BoardId;        // Board dip switch number for the device
   __u32   BusNumber;      // PCI Bus number
   __u32   SlotNumber;     // PCI Slot number
   __u32   IoBase;
   __u32   IoLength;
   __u32   Irq;
   __u32   InitOnLoad;

   // --------------------------------------------------------
   __u8    DioPortDir[DIO_PORT_COUNT]; 
   __u8    DoPortState[DIO_PORT_COUNT];
   __u8    DiintTrigEdge[DI_INT_SRC_COUNT];
   __u8    DiintGateCtrl[DI_INT_SRC_COUNT];
   DI_SNAP DiSnap[DI_SNAP_SRC_COUNT];

   // --------------------------------------------------------
   CNTR_CONFIG CntrConfig;
   CNTR_STATE  CntrState[CNTR_CHL_COUNT];
   __u32       CntrChkTimerOwner;

   // ---------------------------------------------------------
   __u32   IntState;
   __u32   IsEvtSignaled[KrnlSptedEventCount];

} DEVICE_SHARED;

#endif /* KERNEL_MODULE_SHARED_H_ */
