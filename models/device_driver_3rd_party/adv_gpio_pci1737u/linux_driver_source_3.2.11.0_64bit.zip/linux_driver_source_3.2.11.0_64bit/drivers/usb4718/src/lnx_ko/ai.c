/*
 * ai.c
 *
 *  Created on: 2011-9-15
 *      Author: rocky
 */
#include "kdriver.h"

static
__u8 daq_ai_get_hw_gain(__u8 user_gain)
{
   const __u8 thermo_gain_map[7] = {
         0x12, // Jtype_Gain, Jtype1_Gain
         0x22, // Ktype_Gain, Ktype1_Gain
         0x11, // Ttype_Gain, Ttype1_Gain
         0x22, // Etype_Gain, Etype1_Gain
         0x19, // Rtype_Gain, Rtype1_Gain
         0x28, // Stype_Gain, Stype1_Gain
         0x18, // Btype_Gain, Btype1_Gain
   };
   __u8 hw_gain = user_gain;
   if (user_gain < Jtype_Gain){
      if (user_gain == mA_4To20_Gain){
         hw_gain = mA_0To20_Gain;
      }
   } else {
      unsigned index;
      if (user_gain >= Jtype1_Gain){
         index = user_gain - Jtype1_Gain;
      } else {
         index = user_gain - Jtype_Gain;
      }
      if (index < ARRAY_SIZE(thermo_gain_map)){
         hw_gain = thermo_gain_map[index];
      } else {
         hw_gain = thermo_gain_map[0];
      }
   }
   return hw_gain;
}

static
int daq_ai_configure_channel(daq_device_t *daq_dev, __u32 phyStart, __u32 phyCount, __u8 *sctype, __u8 *gain)
{
   int   ret;
   __u32 i;
   __u8  hw_gain[AI_CHL_COUNT];

   if (phyCount == 0 ||gain == NULL){
      return 0;
   }

   phyStart &= AI_CHL_MASK;
   if (phyCount > AI_CHL_COUNT){
      phyCount = AI_CHL_COUNT;
   }

   for (i = 0; i < x_min(AI_CHL_COUNT - phyStart, phyCount); ++i){
      daq_dev->shared.AiChanGain[phyStart + i] = gain[i];
      hw_gain[i] = daq_ai_get_hw_gain(gain[i]);
   }

   ret = daq_usb_ai_configure_channel(daq_dev, phyStart, i, NULL, hw_gain);
   if (ret > 0 && i < phyCount){
      phyCount -= i;
      gain     += i;
      for (i = 0; i < phyCount; ++i){
         daq_dev->shared.AiChanGain[i] = gain[i];
         hw_gain[i] = daq_ai_get_hw_gain(gain[i]);
      }
      ret = daq_usb_ai_configure_channel(daq_dev, phyStart, i, NULL, hw_gain);
   }

   return ret < 0 ? ret : 0;
}

//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------
void daq_ai_initialize_hw(daq_device_t *daq_dev)
{
   daq_ai_configure_channel(daq_dev, 0, AI_CHL_COUNT, NULL, daq_dev->shared.AiChanGain);

   {
      __u32 chStatus[AI_CHL_COUNT];
      __u32 eeWrite = 0;
      __u32 i;

      daq_usb_ai_get_channel_status(daq_dev, EE_AiChGainType, 0, AI_CHL_COUNT, chStatus);
      for (i = 0; i < AI_CHL_COUNT; ++i) {
         if (chStatus[i] <= 8) {
            eeWrite = 1;
         }
         chStatus[i] = 100;
      }

      if (eeWrite) {
         daq_usb_ai_set_channel_status(daq_dev, EE_AiChGainType, 0, AI_CHL_COUNT, chStatus);
      }

      eeWrite = 0;
      daq_usb_ai_get_channel_status(daq_dev, EE_AiBurnOutTypeSet, 0, AI_CHL_COUNT, chStatus);
      for (i = 0; i < AI_CHL_COUNT; ++i) {
         if (chStatus[i] == 0) {
            eeWrite = 1;
         }
         chStatus[i] = 1;
      }

      if (eeWrite) {
         daq_usb_ai_set_channel_status(daq_dev, EE_AiBurnOutTypeSet, 0, AI_CHL_COUNT, chStatus);
      }
   }
}

int daq_ioctl_ai_set_channel(daq_device_t *daq_dev, unsigned long arg)
{
   AI_SET_CHAN xbuf;
   AI_CHAN_CFG cfg[AI_CHL_COUNT];
   __u8        gain[AI_CHL_COUNT];
   __u32       i;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   if (unlikely((xbuf.SetWhich & AI_SET_CHGAIN) == 0 || xbuf.PhyChanCount == 0)){
      return 0;
   }

   if (unlikely(xbuf.PhyChanCount > AI_CHL_COUNT)){
      xbuf.PhyChanCount = AI_CHL_COUNT;
   }

   if (unlikely(copy_from_user(cfg, (void *)xbuf.ChanCfg, sizeof(AI_CHAN_CFG) * xbuf.PhyChanCount))){
      return -EFAULT;
   }

   for (i = 0; i < xbuf.PhyChanCount; ++i) {
      gain[i] = cfg[i].Gain;
   }

   return daq_ai_configure_channel(daq_dev, xbuf.PhyChanStart, xbuf.PhyChanCount, NULL, gain);
}

int daq_ioctl_ai_read_sample(daq_device_t *daq_dev, unsigned long arg)
{
   AI_READ_SAMPLES xbuf;
   __u16           sample[AI_CHL_COUNT];

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   xbuf.PhyChanStart &= AI_CHL_MASK;
   xbuf.LogChanCount =  x_min(xbuf.LogChanCount, (__u32)AI_CHL_COUNT);
   if (daq_usb_ai_read_channel(daq_dev, xbuf.PhyChanStart, xbuf.LogChanCount, SAI_TIMEOUT_VAL, sample) < 0){
      return -EIO;
   }

   if (unlikely(copy_to_user((void *)xbuf.Data, sample, xbuf.LogChanCount * sizeof(__u16)))) {
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_ai_read_cjc_sample(daq_device_t *daq_dev, unsigned long arg)
{
   AI_READ_CJC_SAMPLES xbuf;
   __u16               sample[CJC_AVG_COUNT];
   unsigned            i;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   if (xbuf.CjcValCount > CJC_AVG_COUNT){
      xbuf.CjcValCount = CJC_AVG_COUNT;
   }

   if (daq_usb_ai_read_cjc_error(daq_dev, (__u16 *)&xbuf.CjcError) < 0){
      return -EIO;
   }

   for (i = 0; i < xbuf.CjcValCount; ++i){
      if (daq_usb_ai_read_cjc_value(daq_dev, SAI_TIMEOUT_VAL, &sample[i]) < 0){
         return -EIO;
      }
   }

   if (unlikely(copy_to_user((void *)arg, &xbuf, sizeof(xbuf)))){
      return -EFAULT;
   }

   if (unlikely(copy_to_user((void *)xbuf.CjcValues, sample, xbuf.CjcValCount * sizeof(__u16)))){
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_ai_burn_detect(daq_device_t *daq_dev, unsigned long arg)
{
   USB_AI_CH_STAUS xbuf;
   __u32           status[AI_CHL_COUNT];

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   if (xbuf.ChanCount > AI_CHL_COUNT){
      xbuf.ChanCount = AI_CHL_COUNT;
   }

   if (daq_usb_ai_get_channel_status(daq_dev,
         xbuf.CmdCode, xbuf.ChanStart, xbuf.ChanCount, status) < 0){
      return -EIO;
   }

   if (unlikely(copy_to_user((void *)xbuf.Status, status, xbuf.ChanCount * sizeof(__u32)))){
      return -EFAULT;
   }

   return 0;
}
