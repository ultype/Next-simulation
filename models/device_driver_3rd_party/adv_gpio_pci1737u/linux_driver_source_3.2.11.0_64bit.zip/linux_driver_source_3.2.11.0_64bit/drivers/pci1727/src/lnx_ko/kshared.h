/*
 * kshared.h
 *
 *  Created on: 2011-8-30
 *      Author: 
 */

#ifndef KERNEL_MODULE_SHARED_H_
#define KERNEL_MODULE_SHARED_H_

#include <linux/types.h>


#define ADVANTECH_VID 0x13fe
#define DEVICE_ID     0x1727
#define DRIVER_NAME   "bio1727"
#define DEVICE_NAME   "PCI-1727U"

// ----------------------------------------------------------
// H/W feature and structures.
// ----------------------------------------------------------
#define AO_CHL_COUNT             12
#define AO_RES_IN_BIT            14
#define AO_DATA_SIZE             sizeof(__u16)
#define AO_DATA_MASK             0x3fff
#define AO_EXT_REF_UNIPOLAR      10

#define AO_GAIN_V_0To5           0
#define AO_GAIN_V_0To10          1
#define AO_GAIN_V_EXTUNIPOLAR    2

#define DIO_PORT_COUNT           2
#define DIO_CHL_COUNT            (DIO_PORT_COUNT * 8)

enum KRNL_EVENT_IDX{
   KdxDevPropChged = 0,
   KrnlSptedEventCount,
};

static inline __u32 GetEventKIndex(__u32 eventType)
{
   __u32 kdx;
   switch ( eventType )
   {
   case EvtPropertyChanged:         kdx = KdxDevPropChged;    break;
   default: kdx = -1; break;
   }
   return kdx;
}

// -----------------------------------------------------
// default values
// -----------------------------------------------------
#define DEF_INIT_ON_LOAD        1

// AO default values
#define DEF_AO_INIT_STATE       0

// DIO default values
#define DEF_DO_STATE            0


typedef struct _DEVICE_SHARED
{
   __u32       Size;           // Size of the structure
   __u32       ProductId;      // Device Type
   __u32       DeviceNumber;   // Zero-based device number

   // HW Information
   __u32       BoardId;        // Board dip switch number for the device
   __u32       BusNumber;      // PCI Bus number
   __u32       SlotNumber;     // PCI Slot number
   __u32       IoBase;
   __u32       IoLength;
   __u32       Irq;
   __u32       InitOnLoad;

   // ---------------------------------------------------------
   __u32       AoChanGain[AO_CHL_COUNT];
   __u16       AoChanState[AO_CHL_COUNT];

   // ---------------------------------------------------------
   __u8        DoPortState[DIO_PORT_COUNT];

   // ---------------------------------------------------------
   __u32       IsEvtSignaled[KrnlSptedEventCount];

} DEVICE_SHARED;

#endif /* KERNEL_MODULE_SHARED_H_ */
