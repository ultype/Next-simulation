/*
 * dio.c
 *
 *  Created on: July 7, 2012
 *      Author: rocky
 */
#include "kdriver.h"
#include "hw.h"


//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------

void daq_dio_set_port_dir(daq_device_t *daq_dev)
{
   __u8 *dirs = daq_dev->shared.DioPortDir;

   DIR_CTRL_REG curDir = {0};
   DIR_CTRL_REG newDir = {0};

   newDir.PADir = *dirs++ == Input ? PORTDIR_IN : PORTDIR_OUT;
   newDir.PBDir = *dirs++ == Input ? PORTDIR_IN : PORTDIR_OUT;
   newDir.PCLowDir = (*dirs & 0x0F) == 0 ? PORTDIR_IN : PORTDIR_OUT;
   newDir.PCHighDir= (*dirs & 0xF0) == 0 ? PORTDIR_IN : PORTDIR_OUT;
   curDir.Value = AdxIoInB( daq_dev->shared.IoBase, DR_Dir_Ctrl );
   curDir.Value = curDir.Value & 0x1B;
   if ( newDir.Value != curDir.Value )
   {
      AdxIoOutB( daq_dev->shared.IoBase, DR_Dir_Ctrl, newDir.Value );
   }
}

void daq_dio_initialize_hw(daq_device_t *daq_dev)
{
   int i;
   // Initialize DIO port direction
   if(daq_dev->shared.DioPortDirConfigByHw)//The direction can only be set by hardware
   {
      __u8 portDir;
      DIR_CTRL_REG dirReg;
      dirReg.Value = AdxIoInB( daq_dev->shared.IoBase, DR_Dir_Ctrl );
      for(i = 0; i < DIO_PORTS_COUNT; ++i)
      {
         switch(i)
         {
            case 0:
               portDir = (PORTDIR_IN == dirReg.PADir ? Input : Output);
               break;
            case 1:
               portDir = (PORTDIR_IN == dirReg.PBDir ? Input : Output);
               break;
            case 2:
               portDir = (PORTDIR_IN == dirReg.PCLowDir ?  0x00 : 0x0f );
               portDir |= (PORTDIR_IN == dirReg.PCHighDir ? 0x00 : 0xf0);
               break;
            default:
               daq_trace(("DIO_PORTS_COUNT is %d, but init %d of daq_dev->shared->DioPortDir's elements in DioInitializeHardware\n", DIO_PORTS_COUNT, i));
               portDir = 0xaa;
         }
         daq_dev->shared.DioPortDir[i] = portDir;
      }
   }
   else
   {
      daq_dio_set_port_dir( daq_dev );
   }  
   // Set DO port status
   if ( daq_dev->shared.InitOnLoad )
   {
      __u8 const * state = daq_dev->shared.DoPortState;
      for ( i = 0; i < DIO_PORTS_COUNT; ++i, ++state )
      {
         AdxIoOutB(daq_dev->shared.IoBase, DR_PortX(i), *state);
      }
   }
}

int daq_ioctl_dio_set_port_dir(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED     *shared = &daq_dev->shared;
   DIO_SET_PORT_DIR  xbuf;
   __u8              *dest = NULL;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))) {
      return -EFAULT;
   }

   if (xbuf.PortStart + xbuf.PortCount > DIO_PORTS_COUNT) {
      return -EINVAL;
   }

   dest = shared->DioPortDir;
   dest += xbuf.PortStart;

   if (unlikely(copy_from_user(dest, xbuf.Dirs, xbuf.PortCount))) {
      return -EFAULT;
   }

   daq_dio_set_port_dir(daq_dev);
   return 0;
}

int daq_ioctl_di_read_port(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED     *shared = &daq_dev->shared;
   DIO_RW_PORTS xbuf;
   __u8         data[DIO_PORTS_COUNT];
   unsigned     i, port;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   xbuf.PortStart %= DIO_PORTS_COUNT;
   xbuf.PortCount  = x_min((unsigned)DIO_PORTS_COUNT, xbuf.PortCount);
   for (i = 0; i < xbuf.PortCount; ++i){
      port = (xbuf.PortStart + i) % DIO_PORTS_COUNT;
      data[i] = AdxIoInB(shared->IoBase, DR_PortX(port));
   }

   if (unlikely(copy_to_user(xbuf.Data, data, xbuf.PortCount))){
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_do_write_port(daq_device_t *daq_dev, unsigned long arg)
{
   DIO_RW_PORTS xbuf;
   __u8         data[DIO_PORTS_COUNT];
   unsigned     i, port;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   xbuf.PortStart %= DIO_PORTS_COUNT;
   xbuf.PortCount  = x_min((unsigned)DIO_PORTS_COUNT, xbuf.PortCount);
   if (unlikely(copy_from_user(data, (void *)xbuf.Data, xbuf.PortCount))){
      return -EFAULT;
   }

   xbuf.PortStart %= DIO_PORTS_COUNT;
   xbuf.PortCount  = x_min((unsigned)DIO_PORTS_COUNT, xbuf.PortCount);
   for (i = 0; i < xbuf.PortCount; ++i){
      port = (xbuf.PortStart + i) % DIO_PORTS_COUNT;
      AdxIoOutB(daq_dev->shared.IoBase, DR_PortX(port), data[i]);
   }

   return 0;
}

int daq_ioctl_do_write_bit(daq_device_t *daq_dev, unsigned long arg)
{
   DIO_RW_BIT xbuf;
   __u8       data, status;
   unsigned   port, bit;
   unsigned long flags;
   
   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }
   xbuf.Port %= DIO_PORTS_COUNT;

   port = (xbuf.Port) % DIO_PORTS_COUNT;
   bit  = xbuf.Bit;
   data = xbuf.Data;

   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   status = AdxIoInB(daq_dev->shared.IoBase, DR_PortX(port));
   status = ((data & 0x1) << bit) | (~(1 << bit) & status);
   AdxIoOutB(daq_dev->shared.IoBase, DR_PortX(port), status);
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
   
   return 0;
}

int daq_ioctl_do_read_port(daq_device_t *daq_dev, unsigned long arg)
{
   DIO_RW_PORTS xbuf;
   __u8         data[DIO_PORTS_COUNT];
   unsigned     i, port;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   xbuf.PortStart %= DIO_PORTS_COUNT;
   xbuf.PortCount  = x_min((unsigned)DIO_PORTS_COUNT, xbuf.PortCount);
   for (i = 0; i < xbuf.PortCount; ++i){
      port = (xbuf.PortStart + i) % DIO_PORTS_COUNT;
      data[i] = AdxIoInB(daq_dev->shared.IoBase, DR_PortX(port));
   }

   if (unlikely(copy_to_user(xbuf.Data, data, xbuf.PortCount))){
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_diint_set_param(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED     *shared = &daq_dev->shared;
   DIO_SET_DIINT_CFG xbuf;
   __u8              *dest = NULL;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))) {
      return -EFAULT;
   }

   if (xbuf.SrcStart + xbuf.SrcCount > DI_INT_SRC_COUNT) {
      return -EINVAL;
   }

   if (xbuf.SetWhich == DIINT_SET_TRIGEDGE) {
      dest = shared->DiintTrigEdge;
   }else{
      dest = shared->DiintGateCtrl;
   }
   dest += xbuf.SrcStart;

   if (unlikely(copy_from_user(dest, xbuf.Buffer, xbuf.SrcCount))) {
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_di_start_snap(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED     *shared = &daq_dev->shared;
   DIO_START_DI_SNAP xbuf;
   unsigned          event_kdx, src_idx, status;
   status = 0;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))) {
      return -EFAULT;
   }

   event_kdx = GetEventKIndex(xbuf.EventId);
   src_idx   = event_kdx - EvtDiIdxBegin;
   if (event_kdx == -1 || src_idx >= DI_SNAP_SRC_MAX) {
      return -EINVAL;
   }

   switch ( xbuf.EventId )
   {
      case EvtDiintChannel016:
         status = InterruptEnableDiInt( daq_dev, 1,
            shared->DiintGateCtrl[0] ? INT_SRC_PC0_WITH_GATE : INT_SRC_PC0,
            shared->DiintTrigEdge[0] == RisingEdge ? TRIG_EDGE_RISING : TRIG_EDGE_FALLING,
            event_kdx);
         daq_dev->shared.DiSnapParam[src_idx].portStart = (__u8)xbuf.PortStart;
         daq_dev->shared.DiSnapParam[src_idx].portCount = (__u8)xbuf.PortCount;
         break;
      default:
         return ErrorEventNotSpted;
   }

   return status;
}

int daq_ioctl_di_stop_snap(daq_device_t *daq_dev, unsigned long arg)
{
   uint32        event_kdx, src_idx;
   uint32        evtId;

   if (unlikely(copy_from_user(&evtId, (void *)arg, sizeof(evtId)))) {
      return -EFAULT;
   }
   event_kdx = GetEventKIndex(evtId);
   src_idx   = event_kdx - EvtDiIdxBegin;
   if (event_kdx == -1 || src_idx >= DI_SNAP_SRC_MAX) {
      return -EINVAL;
   }

   switch (evtId)
   {
      case EvtDiintChannel016:
         InterruptEnableDiInt( daq_dev, 0, INT_SRC_PC0,TRIG_EDGE_FALLING, event_kdx);
         break;
      default:
         return ErrorEventNotSpted;
   }

   return 0;
}

int InterruptEnableDiInt( daq_device_t *daq_dev, unsigned long isEnable, unsigned long src,unsigned long edge, unsigned long eventIdx)
{
   // enable the interrupt of DI
   DEV_INT_CSR csr;
   csr.Value = AdxIoInB( daq_dev->shared.IoBase, DR_IntCSR ) & (~DEV_INT_MASK);

   daq_trace(("enable interrupt: %x, event idx:%d\n", csr.Value, eventIdx));
   if (isEnable)
   {
      csr.IntMode = src;
      csr.IntEdge = edge;

      daq_device_clear_event(daq_dev, eventIdx);
      daq_dev->shared.IsEvtSignaled[eventIdx] = 0;
   }else
   {
      csr.IntMode = INT_DISABLED;
   } 
   
   // the following lines should be synchronized with interrupt
   spin_lock(&daq_dev->dev_lock);
   AdxIoOutB(daq_dev->shared.IoBase, DR_IntCSR, csr.Value);
   spin_unlock(&daq_dev->dev_lock);

   return 0;
}

