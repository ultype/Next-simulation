/*
 * isr.c
 *
 *  Created on: 2012-06-04
 *      Author: W 
 */
#include "kdriver.h"
#include "hw.h"

//only used in this file
#define DAQ_IN_CACHE_OVERFLOW 0x8

// -----------------------------------------------------------------------------
// Must hold the lock when call this function.

static inline
void IsrUpdateAiBufferStatus( FAI_STATUS *faiStatus, __u32 incCount )
{
       //
       // update WritePos
       // use a local variable 'wp' to prevent synchronize problem
       //
       __u32 wp = faiStatus->WritePos;
       __u32 WpRunBackCount = 0;
       __u32 i = 0;
       
       wp += incCount;
       WpRunBackCount = wp / faiStatus->BufLength;
       wp %= faiStatus->BufLength;
       faiStatus->WritePos = wp;
   
       for ( i = 0; i < WpRunBackCount; i++)
       {
           //InterlockedIncrement((LONG *)&faiStatus->WPRunBack);
           faiStatus->WPRunBack ++;
       }
   
       // check overrun and buffer full
       if ( faiStatus->WPRunBack )
       {
           faiStatus->BufState |= DAQ_IN_BUF_FULL;
   
           if ( faiStatus->WPRunBack > 1 || faiStatus->WritePos > faiStatus->ReadPos )
           {
               faiStatus->BufState |= DAQ_IN_BUF_OVERRUN;
           } 
       }
   
       daq_trace((KERN_ALERT"Update buffer status: RP = %u, WP = %u, status = %02X\n",
           faiStatus->ReadPos, faiStatus->WritePos, faiStatus->BufState));
}

//////////////////////////////////////////////////////////////////////////
static inline
__u32  GetAiValidDataCount(PAI_CHL_CTL Sample, __u32 Count, BOOLEAN fromBottom)
{
    
    __u32  i = 0;
    __u32  dataCount = 0;

    if (fromBottom)
    {
        for ( i = Count; i > 0; i-- )
        {
            if ( 1 == Sample[i-1].Fields.Trigger)
            {
                break;
            }
            dataCount++;
        }
        dataCount = Count - dataCount;
    }
    else
    {
        for ( i = 0; i < Count; i++ )
        {
            if ( 1 == Sample[i].Fields.D2Stop)
            {
                break;
            }
            dataCount++;
        }
    }

    return dataCount;
}


static inline
void daq_fai_read_fifo(DEVICE_SHARED *shared, __u16 *data_buf, unsigned count)
{
   __u16 * buf_end = data_buf + count;

   for (; data_buf < buf_end; ++data_buf) {
      *data_buf++ = AdxMemInD(shared->IoMemBase, DR_FIFO_DATA);
   }
}


static inline
void FaiDmaUpdateAiBufferStatus(daq_device_t *devExt, BOOLEAN dmaDataReadyInt, BOOLEAN delayToStopInt)
{
    DEVICE_SHARED *shared     = &devExt->shared;
    FAI_STATUS    *faiStatus  = &devExt->shared.FaiStatus;
//    PUCHAR             deviceBase = devExt->BAR[devExt->DeviceBarIdx].Base;
//    PUCHAR             bridgeBase = devExt->BAR[devExt->BridgeBarIdx].Base;

    //////////////////////////////////////////////////////////////////////////
    // DMA WP Calculate Logic Solution 2
    //
    // Interrupt loss is easy to occur, the platform do not warranty no loss of interrupt
    // The below solution can fix up a small quantity of interrupt
    // In such situation, we still able to calculate the correct WP
    // However, if interrupt loss is serious, consequent lost interrupt, and count up to more than the buffer size
    // Then, replace with better platform is the only solution
    //
    //
    //||----------|----------|        ----------|-----||  UserBuffer
    //            ^          ^                  ^          ^
    //            1          2                  N-1        N  SectionCount
    //
    //Case1: Normal (WP, sglIdx interval is one SectionSize)
    //           ^WP
    //                       ^(SectionIdx)sglIdx    
    //Case2: Interrupt loss 
    //           ^WP
    //                                          ^(SectionIdx)sglIdx
    //           |------------------------------| IncCount
    //Case3:
    //                                          ^WP
    //                       ^(SectionIdx)sglIdx
    // |---------------------|                  |-----|
    PLX_DMA_DPR dmaDpr;
    PLX_DMA_CSR dmaCsr;
	ulong incCount;
	
	PLX_SGL_ENTRY *sglEntry = devExt->PreSglVa; 
	ulong  trigDataCount;

    dmaDpr.Value = AdxMemInD(shared->BrMemBase, BR_PLX_DMADPR1);
    dmaCsr.Value = AdxMemInB(shared->BrMemBase, BR_PLX_DMACSR1);

    //Fix bug 10687
    //Solution2: Search the entire SGL entry to find out the SglIdx
    //Cost more time, but correct in any case
    incCount = 0;  // new data count after last DMA ready interrupt

    //Instead of searching from the beginning position, we search from the position 
    //we keep last time to speed the searching speed. The initial value of PreSglEntry is DmaSglStart
     

    // Is the buffer run back? PreSglIdx == SglIdx
    //|----------|----------|----------|----------|
    //           -->|<--               
    //               ^PreSglIdx          
    //               ^SglIdx
    if (sglEntry->DescPtr.Address == dmaDpr.NextDPRAddr) // if PreSglEntry is current entry! It means buffer runs around and go back the original position
    {  
        //Fix bug 11369
        if (dmaCsr.Done)
            incCount+= (sglEntry->DataLength/AI_DATA_SIZE);
        else       
            incCount = faiStatus->BufLength;       
    } else {                                            // otherwise, we search the entry starting from the position last time(PreSglEntry)
        // At first we assume the case like this:
        //|----------|----------|----------|----------|
        //               |<--                      -->|
        //               ^PreSglIdx                 ^SglIdx
        for ( ; sglEntry <= devExt->SglEndVa; ++sglEntry ) 
        {
            if ( sglEntry->DescPtr.Address == dmaDpr.NextDPRAddr ) 
                break;
            incCount += sglEntry->DataLength;
        } 

        // Now we know the real case like this:
        //|----------|----------|----------|----------|
        //|<--  B -->|                     |<-- A  -->|
        //              ^SglIdx            ^PreSglIdx
        if (sglEntry > devExt->SglEndVa) 
        {   // if we can't find the entry, then go back to the start position and search it again.
            // now we only need calculate the part B. 
            sglEntry = devExt->SglStartVa;
            for ( ; sglEntry <= devExt->SglEndVa; ++sglEntry ) 
            {
                if ( sglEntry->DescPtr.Address == dmaDpr.NextDPRAddr ) 
                {
                    break;
                }
                incCount += sglEntry->DataLength;
            } 
        }
        //Fix bug 11369
        if ( dmaCsr.Done )
        {
            incCount += sglEntry->DataLength;     
        }
        incCount /= AI_DATA_SIZE; //Convert to samples
        devExt->PreSglVa = sglEntry;  // keep the entry so that we can search from it next time.
    }

    daq_trace((KERN_ALERT"RP=%d, PreWP=%d, incCount=%lu, BR_DMACSR=0x%x, DMADPR:0x%08X\n", 
        faiStatus->ReadPos, faiStatus->WritePos, incCount, dmaCsr.Value, dmaDpr.Value )); 

    //
    // handle delayToStop interrupt
    // All AI data, followed with some invalid data (stop point flag), have been pushed to 
    // user buffer though DMA by hardware automatically. We need to find out the stop point
    // within the buffer area pointed by WritePos to WritePos+incCount.
    // We will check the data of this area one by one for stop point, and adjust incCount
    // to the correct stop point.
    //
    if ( delayToStopInt )
    {
        // add the last SGL entry data which have not finish transaction.
        incCount += (sglEntry->DataLength/AI_DATA_SIZE);

        daq_trace((KERN_ALERT"Searching for AI stop point from WP = %u within %lu data...\n", 
            faiStatus->WritePos, incCount));

        //
        // 1. In normal case, DelayToStop interrupt occurs far away after DMA section ready interrupts.
        //    We recognize one interrupt flag bit once, and the last one should be DelayToStop interrupt bit. 
        //    So we search the stop point from last WritePos to WritePos+incCount of data buffer.
        // 2. DelayToStop interrupt and DMA interrupt may occur at (or nearly at) the same time. 
        //    In this case, we recognize their two flag bits once. The stop point is near the bottom of 
        //    the same buffer area from WritePos to WritePos+incCount. So we search it from the bottom
        //    to save time.
        //
        trigDataCount = 0;
        if ( faiStatus->WritePos + incCount > faiStatus->BufLength)
        {
            ulong  incCountOfLastSection = faiStatus->BufLength- faiStatus->WritePos;
            trigDataCount = GetAiValidDataCount(
                ((AI_CHL_CTL*)devExt->fai_buffer.kaddr)+faiStatus->WritePos,
                incCountOfLastSection, 
                TRUE);

            if ( trigDataCount == incCountOfLastSection)
            {
                trigDataCount += GetAiValidDataCount(
                    ((AI_CHL_CTL*)devExt->fai_buffer.kaddr)+0,
                    incCount - incCountOfLastSection, 
                    dmaDataReadyInt);
            }
        }
        else
        {
            trigDataCount = GetAiValidDataCount(
                ((AI_CHL_CTL*)devExt->fai_buffer.kaddr)+faiStatus->WritePos,
                incCount, 
                dmaDataReadyInt);
        }

        incCount = trigDataCount;
        daq_trace((KERN_ALERT"Adjusted incCount = %lu.\n", incCount));
    }

    IsrUpdateAiBufferStatus(&shared->FaiStatus, incCount);
}


void daq_fai_tasklet_func(unsigned long arg)
{
   daq_device_t  *daq_dev   = (daq_device_t *) arg;
   DEVICE_SHARED *shared    = &daq_dev->shared;
   FAI_STATUS    *faiStatus = &shared->FaiStatus;
   __u32 cntrEvtIdx = InvalidEventIdx;
   PLX_INT_CSR dmaIntflag;
   DEV_INT_CONTROL devIntflag;

   // get and clear interrupt flags by interlocked operation. 
   dmaIntflag.Value = daq_dev->DmaIntFlag;
   devIntflag.Value = daq_dev->DevIntFlag;
   spin_lock(&daq_dev->fai_lock);
   daq_dev->DmaIntFlag = 0;
   daq_dev->DevIntFlag = 0;
   spin_unlock(&daq_dev->fai_lock);
   
    // Handle FAI interrupt
    //
    if ( DAQ_FN_RUNNING == faiStatus->FnState )
    {
        // check running time status: overrun, data ready. save the buffer status
        // to local variable, so even if we are preempted by ISR, it has no any effect to us.
  //      __u32 bufferStatus = faiStatus->BufState;

        faiStatus->BufState = 0;

        if ( dmaIntflag.Dma1IntActive || devIntflag.AiStopByHw )
        {
            // We always send AiBufDataReady event when DMA SGL interrupt occurs,
            // other than sending it according to data count accumulation.
            faiStatus->BufState |= DAQ_IN_DATAREADY;
            
            // update buffer WritePos and status.
            FaiDmaUpdateAiBufferStatus( 
                daq_dev, 
                dmaIntflag.Dma1IntActive,
                devIntflag.AiStopByHw);
        }

        //
        // handle FIFO full interrupt
        // We have cleared the FIFO in ISR, and we only need to send a 
        // cache overflow event here.
        //
        if ( devIntflag.FifoFull )
        {
            daq_trace((KERN_ALERT"Handle FIFO full interrupt.\n"));
            faiStatus->BufState |= DAQ_IN_CACHE_OVERFLOW;
        }

        daq_trace((KERN_ALERT"BufferStatus = %X\n", faiStatus->BufState));

        // send cache overflow event if the cache overflow occur and we hadn't signaled the event.
        if ((faiStatus->BufState & DAQ_IN_CACHE_OVERFLOW) && !shared->IsEvtSignaled[KdxAiCacheOverflow])
        {
            daq_trace((KERN_ALERT"EvtAiCacheOverflow\n"));
            daq_device_signal_event( daq_dev, KdxAiCacheOverflow );
        }

        // send overrun event if the buffer is overrun and we hadn't signaled the event.
        if ( (faiStatus->BufState & DAQ_IN_BUF_OVERRUN) && !shared->IsEvtSignaled[KdxAiOverrun])
        {
            daq_trace((KERN_ALERT"EvtAiOverrun\n"));
            daq_device_signal_event( daq_dev, KdxAiOverrun );
        } 

        // send data ready event. 
        if ( (faiStatus->BufState & DAQ_IN_DATAREADY) && !shared->IsEvtSignaled[KdxAiDataReady])
        {
            daq_trace((KERN_ALERT"EvtAiDataReady. wp: %u, rp: %u.\n", faiStatus->WritePos, faiStatus->ReadPos));
            //daq_trace((KERN_ALERT"DATA SIZE = %d, sizeof(uint32) = %d\n", AI_DATA_SIZE, sizeof(uint32)));
            daq_device_signal_event( daq_dev, KdxAiDataReady );
        }

        // If it is FINITE acquirement and the buffer is full, or if is stopped by hardware, stop FAI now.
        if (((faiStatus->BufState & DAQ_IN_BUF_FULL) && ((faiStatus->AcqMode & 0x00ff) != DAQ_ACQ_INFINITE))
               || devIntflag.AiStopByHw ) 
        {
              daq_trace((KERN_ALERT"Stop by hardware!\r\n"));
              daq_fai_stop_acquisition(daq_dev);
        }

    }
   
   // handle counter interrupt
   //
   if ( daq_dev->CntrIntFlag & (1<<3) )   // counter 0
   {
	  switch ( shared->CntrState[0].Operation )
	  {
	   case Primary:
		  cntrEvtIdx = EvtCntTerminalCount0Idx;
		  break;
	   case OneShot:
		  cntrEvtIdx = EvtCntOneShot0Idx;
                  daq_trace((KERN_ALERT"Cntr0 OneShot Interrupt!\n"));
		  break;
	   case TimerPulse:
		  cntrEvtIdx = EvtCntTimer0Idx;
                  daq_trace((KERN_ALERT"Cntr0 TimerPulse Interrupt!\n"));
		  break;  
	  default:
		  cntrEvtIdx = InvalidEventIdx;
		  break;
	  }

	  if ( (cntrEvtIdx != InvalidEventIdx) && !shared->IsEvtSignaled[cntrEvtIdx])
	  {
	       shared->IsEvtSignaled[cntrEvtIdx] = 1;
		   daq_device_signal_event(daq_dev, cntrEvtIdx);
	  }		
   }

   if ( daq_dev->CntrIntFlag & (1<<4) )  // counter 1
   {
	   switch ( shared->CntrState[1].Operation )
	   {
	    case Primary:
		    cntrEvtIdx = EvtCntTerminalCount1Idx;
		    break;
	    case OneShot:
		    cntrEvtIdx = EvtCntOneShot1Idx;
                    daq_trace((KERN_ALERT"Cntr1 OneShot Interrupt!\n"));
		    break;
	    case TimerPulse:
		    cntrEvtIdx = EvtCntTimer1Idx;
                    daq_trace((KERN_ALERT"Cntr1 TimerPulse Interrupt!\n"));
                    break;
	    default:
		    cntrEvtIdx = InvalidEventIdx;
		    break;
	   }

	   if ( (cntrEvtIdx != InvalidEventIdx) && !shared->IsEvtSignaled[cntrEvtIdx])
	   {
	       shared->IsEvtSignaled[cntrEvtIdx] = 1;
		   daq_device_signal_event(daq_dev, cntrEvtIdx);
	   }		
   }

///////////////////////////////////////////////////////////////////


   
    return;

}

irqreturn_t daq_irq_handler(int irq, void *dev_id)
{
   daq_device_t *daq_dev = (daq_device_t *) dev_id;
   DEVICE_SHARED *shared = &daq_dev->shared;
   PLX_INT_CSR intCsr9056;
   DEV_INT_CONTROL intCsr1706;
   irqreturn_t irqret = IRQ_NONE;
   BOOLEAN intThisDev = FALSE;
   PLX_DMA_CSR csr; 
   intCsr9056.Value = AdxMemInD(shared->BrMemBase, BR_PLX_INTCSR); 
   intCsr1706.Value = AdxMemInW(shared->IoMemBase, DR_INTR_FLAG) & (BIT(0)|BIT(1)|BIT(2)|BIT(3)|BIT(4));

   // counter interrupt   
   daq_dev->CntrIntFlag = intCsr1706.Value & (1<<(3)|1<<(4));

   spin_lock(&daq_dev->fai_lock);
   // record device interrupt flags
   daq_dev->DevIntFlag |= (long)intCsr1706.Value;
   
   // record DMA interrupt flag
   daq_dev->DmaIntFlag = (long)intCsr9056.Value;
   spin_unlock(&daq_dev->fai_lock);
   
    if ( intCsr1706.Value )
    {
        intThisDev = TRUE;
         irqret = IRQ_HANDLED;
         
        //
        // Handle FIFO full interrupt
        // We have to clear the FIFO to prevent FIFO full interrupt from keeping sending.
        //
        if ( intCsr1706.FifoFull )
        {
            AI_FIFO_CSR  fifoCsr;
            fifoCsr.Value = AdxMemInW(shared->IoMemBase, DR_FIFO_CONTROL);
            fifoCsr.Fields.Clear = 1; // clear FIFO
            AdxMemOutW(shared->IoMemBase, DR_FIFO_CONTROL, fifoCsr.Value);
        }

        // write back to clear interrupt(s)
        AdxMemOutW(shared->IoMemBase, DR_INTR_FLAG, intCsr1706.Value);
    }


    if ( intCsr9056.Dma1IntActive )
    {
         irqret = IRQ_HANDLED;
        //
        // clear DMA interrupt. 
        // Note: don't set DMA start bit here, otherwise
        // there will be an unexpected interrupt.
        // set only the bits for DMA enable and clear interrupt
        //
        csr.Value = AdxMemInB( shared->BrMemBase, BR_PLX_DMACSR1 );
        csr.Start = 0;
        csr.ClearInt = 1;
        AdxMemOutB( shared->BrMemBase, BR_PLX_DMACSR1, csr.Value );

        intThisDev = TRUE;
    }

    if ( intThisDev )
    {
        tasklet_schedule(&daq_dev->fai_tasklet);
        daq_trace((KERN_ALERT"----------------------------------interrupt------------------------------\n"));
    }

   
   return IRQ_RETVAL(irqret);
}
