/*
 * counter.c
 *
 *  Created on: 2012-8-10
 *      Author: W 
 */
#include "kdriver.h"
#include "hw.h"

#define  FREQ_BASE_0   (20*1000*1000UL)
#define  FREQ_BASE_1   (20UL)
#define  FREQ_BASE_2   (200UL)
#define  FREQ_BASE_3   (2000UL)

//////////////////////////////////////////////////////////////////////////
// counter parameter set table used in freqIn operations.
typedef struct _CNTR_FREQIN_PARAM 
{
   __u32  ClockSource;
   __u32  GateSource;
   __u32  BaseFreq;
   __u32  FmMethod;     // CountingPulseByDevTime: freq = (load+hold) * BaseFreq
                   // PeriodInverse:          freq = BaseFreq / (load+hold)
   __u32  UpperLimit;   // if load > UpperLimit then use "ForwardIdx" parameter set.
   __u32  LowerLimit;   // if load < LowerLimit then use "BackwardIdx" parameter set.
   __u32  ForwardIdx;
   __u32  BackwardIdx;
} CNTR_FREQIN_PARAM, *PCNTR_FREQIN_PARAM;


static const CNTR_FREQIN_PARAM s_FmParam[] = {
   // clock		                                gate		                   BaseFreq 	         FmMethod				  UpperLimit			   LowerLimit			 forward/backward		   Measure Range
   {CNTR_CLOCK_SOURCE_20M,       CNTR_GATE_SOURCE_GATEN,  FREQ_BASE_0,  PeriodInverse, 		      CNTR_MAX_VAL, 		   FREQ_BASE_0/(20*1000),	  0, 1},	//   1  Hz -  20	KHz
   {CNTR_CLOCK_SOURCE_GATE_N,	 CNTR_GATE_SOURCE_20,     FREQ_BASE_1,  CountingPulseByDevTime,  (220*1000)/FREQ_BASE_1,  (18*1000)/FREQ_BASE_1,	  2, 0},	//  18 KHz - 220	KHz
   {CNTR_CLOCK_SOURCE_GATE_N,	 CNTR_GATE_SOURCE_200,    FREQ_BASE_2,  CountingPulseByDevTime,  (2200*1000)/FREQ_BASE_2, (200*1000)/FREQ_BASE_2,	  3, 1},	// 200 KHz -	2.2 MHz
   {CNTR_CLOCK_SOURCE_GATE_N,	 CNTR_GATE_SOURCE_2K,     FREQ_BASE_3,  CountingPulseByDevTime,  CNTR_MAX_VAL, 		      (2000*1000)/FREQ_BASE_3,    3, 2},	//   2 MHz -  10	MHz
   {CNTR_CLOCK_SOURCE_GATE_N,	 CNTR_GATE_SOURCE_2,      2,			CountingPulseByDevTime,  (22*1000)/2,			  (2*1000)/2,				  1, 0},    // never used in auto mode
};

static 
inline __u32  CntrClkSrcBioToHw(__u32 bioClkSrc, __u32 cntrID )
{
   __u32 hwClkSrc = CNTR_CLOCK_SOURCE_NONE;

   switch ( bioClkSrc )
   {
      case SigCntClk0:
      case SigCntClk1:
            hwClkSrc = ( ( bioClkSrc - SigCntClk0 ) != cntrID ) ? CNTR_CLOCK_SOURCE_CLK_N1 : CNTR_CLOCK_SOURCE_CLK_N;
            break;
      case SigCntGate0:
      case SigCntGate1:
            hwClkSrc = CNTR_CLOCK_SOURCE_GATE_N;
            break;
      case SigCntOut0:
      case SigCntOut1:
            hwClkSrc = CNTR_CLOCK_SOURCE_OUT_N1;
            break;
      case SigInternal20MHz:
            hwClkSrc = CNTR_CLOCK_SOURCE_20M;
            break;
      case SigInternal2MHz:
            hwClkSrc = CNTR_CLOCK_SOURCE_2M;
            break;
      case SigInternal200KHz:
            hwClkSrc = CNTR_CLOCK_SOURCE_200K;
            break;
      case SigInternal20KHz:
            hwClkSrc = CNTR_CLOCK_SOURCE_20K;
            break;
      case SigInternal2KHz:
            hwClkSrc = CNTR_CLOCK_SOURCE_2K;
            break;
      case SigInternal200Hz:
            hwClkSrc = CNTR_CLOCK_SOURCE_200;
            break;
      case SigInternal20Hz:
            hwClkSrc = CNTR_CLOCK_SOURCE_20;
            break;
      case SigInternal2Hz:
            hwClkSrc = CNTR_CLOCK_SOURCE_2;
            break;
      default:
            break;
   }

   return hwClkSrc;
}

static 
inline __u32  CntrGateSrcBioToHw(__u32 bioGateSrc, __u32 cntrID)
{
   __u32  hwGateSrc = CNTR_GATE_SOURCE_RESERVED;
  
   switch ( bioGateSrc )
   {
      case SigCntGate0:
      case SigCntGate1:
            hwGateSrc = ( ( bioGateSrc - SigCntGate0 ) != cntrID ) ? CNTR_GATE_SOURCE_GATE_N1 : CNTR_GATE_SOURCE_GATEN; 
            break;
      case SigCntOut0:
      case SigCntOut1:
            hwGateSrc = CNTR_GATE_SOURCE_OUT_N1;
            break;
      case SigInternal2KHz:
            hwGateSrc = CNTR_GATE_SOURCE_2K;
            break;
      case SigInternal200Hz:
            hwGateSrc = CNTR_GATE_SOURCE_200;
            break;
      case SigInternal20Hz:
            hwGateSrc = CNTR_GATE_SOURCE_20;
            break;
      case SigInternal2Hz:
            hwGateSrc = CNTR_GATE_SOURCE_2;
            break;
      default:
            break;
   }

   return hwGateSrc;
}

static 
inline __u32 CntrOutSignalBioToHw( __u32 bioOutType,  __u32 * hwCOE)
{
   __u32  hwCOM = CNTR_OUTPUT_HIGH_PULSE;

   *hwCOE = 1;

   switch (bioOutType)
   {
      case SignalOutNone:
            *hwCOE = 0;
            break;
      case PositivePulse:
            hwCOM = CNTR_OUTPUT_HIGH_PULSE;
            break;
      case NegativePulse:
            hwCOM = CNTR_OUTPUT_LOW_PULSE;
            break;
      case ToggledFromLow:
            hwCOM = CNTR_OUTPUT_LOW_TTL;
            break;
      case ToggledFromHigh:
            hwCOM = CNTR_OUTPUT_HIGH_TTL;
            break;
      default:
            *hwCOE = 0;
            break;
   }

   return hwCOM;
}

static 
inline void EnableCounterInterrupt( daq_device_t *daq_dev, __u32 start )
{
   DEVICE_SHARED  *shared = &daq_dev->shared;
   PLX_INT_CSR intcsr;
   DEV_INT_CONTROL		 intReg;

   intReg.Value = AdxMemInW(shared->IoMemBase, DR_EN_INTR);

   intcsr.Value = 0;
   intcsr.PciIntEn  = 1;
   intcsr.LocIntInputEn = 1;
   AdxMemOutD(shared->BrMemBase,BR_PLX_INTCSR,intcsr.Value);

   if ( start == 0 )
   {
      intReg.Count0 = 1;
   }
   else
   {
      intReg.Count1 = 1;
   }

   AdxMemOutW(shared->IoMemBase, DR_EN_INTR, intReg.Value);
}
  
static 
inline void DisableCounterInterrupt( daq_device_t *daq_dev, __u32 start )
{
   DEVICE_SHARED  *shared = &daq_dev->shared;

   DEV_INT_CONTROL	 intReg;
   PLX_INT_CSR intcsr;

   intcsr.Value = 0;
   AdxMemOutD(shared->BrMemBase,BR_PLX_INTCSR,intcsr.Value);

   intReg.Value = AdxMemInW(shared->IoMemBase, DR_EN_INTR);

   if ( start == 0 )
   {
      intReg.Count0 = 0;
   }
   else
   {
      intReg.Count1 = 0;
   }

   AdxMemOutW(shared->IoMemBase, DR_EN_INTR, intReg.Value);

}



static 
void 	daq_cntr_start(DEVICE_SHARED *shared, __u32 channel)
{
   __u8 cnt_cmd_reg;
   __u8 cnt_enable_reg;	

   cnt_cmd_reg = DR_COUNTER0_CMD + channel * 4;
   cnt_enable_reg = DR_COUNTER0_ENABLE + channel * 4;

   AdxMemOutB(shared->IoMemBase, cnt_cmd_reg, CNT_CMD_LOAD); /* issue LOAD */
   AdxMemOutB(shared->IoMemBase, cnt_enable_reg, 0x01);

   AdxMemOutB(shared->IoMemBase, cnt_cmd_reg, CNT_CMD_ARM); /* issue ARM */
   AdxMemOutB(shared->IoMemBase, cnt_enable_reg, 0x01);

   printk("LoadAndArmCounter!\n");
}

static
int daq_cntr_start_primary(daq_device_t *daq_dev, __u32 cntrID)
{
   DEVICE_SHARED  *shared = &daq_dev->shared;
   COUNTER_CHL_CSR ctlWord = {0};
   unsigned long flags;
   unsigned  outEn = 0; 

   //Mode A
   ctlWord.CounterRepe = CNTR_MODE_ONCE;
   ctlWord.CounterReload = CNTR_MODE_FROM_LOAD;
   ctlWord.CounterGateMode = shared->CntrConfig.EcGateEnable[cntrID];

   //Default configuration
   ctlWord.CounterMode = shared->CntrConfig.ChipCntType[cntrID];
   ctlWord.CounterClkSource = CntrClkSrcBioToHw(shared->CntrConfig.ChipClkSource[cntrID], cntrID);
   ctlWord.CounterEdge = (( Negative == shared->CntrConfig.ChipClkPolarity[cntrID]) ? CNTR_EDGE_FALLING : CNTR_EDGE_RISING); 
   ctlWord.CounterOutputEnable = CNTR_OUTPUT_ENABLE;
   ctlWord.CounterOutputMode = CntrOutSignalBioToHw(shared->CntrConfig.ChipOutSignal[cntrID], &outEn);
   ctlWord.CounterGateClkSource = CntrGateSrcBioToHw(shared->CntrConfig.ChipGateSrc[cntrID], cntrID);
   ctlWord.CounterGatePolarity = (( Negative == shared->CntrConfig.ChipGatePolarity[cntrID])? GP_LOW_FALLING : GP_HIGH_RISING);

   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   if (shared->CntrState[cntrID].Operation == CNTR_IDLE) {
      memset(&shared->CntrState[cntrID], 0, sizeof(CNTR_STATE));
      shared->CntrState[cntrID].Operation = InstantEventCount;
   } else {
      spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
      return -EBUSY;
   }
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

   AdxMemOutD(shared->IoMemBase, DR_COUNTER0_MODE + (cntrID * 4), ctlWord.Value );
   AdxMemOutD(shared->IoMemBase, DR_COUNTER0_LOAD + (cntrID * 4), shared->CntrConfig.ChipLoadValue[cntrID]);
   AdxMemOutD(shared->IoMemBase, DR_COUNTER0_HOLD + (cntrID * 4), shared->CntrConfig.ChipHoldValue[cntrID] );

   // enable interrupt
   if ( ((0 == cntrID) && daq_device_event_alive(daq_dev, EvtCntTerminalCount0Idx)) || 
      ((1 == cntrID) && daq_device_event_alive(daq_dev, EvtCntTerminalCount1Idx)) 	)
   {
      shared->IsEvtSignaled[EvtCntOneShot0Idx+cntrID] = 0;
      EnableCounterInterrupt(daq_dev, cntrID);
   }

   daq_cntr_start(shared, cntrID);

   return 0;
}

static
int daq_cntr_start_one_shot(daq_device_t *daq_dev, __u32 cntrID)
{
   DEVICE_SHARED  *shared = &daq_dev->shared;
   COUNTER_CHL_CSR ctlWord = {0};
   unsigned long  flags;
   __u32  outEn = 0;

   //Mode F
   ctlWord.CounterRepe = CNTR_MODE_REPETITIVELY;
   ctlWord.CounterReload = CNTR_MODE_FROM_LOAD;
   ctlWord.CounterGateMode = ((shared->CntrConfig.OstGateSource[cntrID]==SignalNone)?0:2);

   //Default configuration
   ctlWord.CounterMode = CNTR_MODE_DOWN;
   ctlWord.CounterOutputEnable = CNTR_OUTPUT_ENABLE;
   ctlWord.CounterOutputMode =   CntrOutSignalBioToHw(shared->CntrConfig.OstOutSignal[cntrID], &outEn);
   ctlWord.CounterClkSource = CntrClkSrcBioToHw(shared->CntrConfig.OstClkSource[cntrID], cntrID);
   ctlWord.CounterGateClkSource = CntrGateSrcBioToHw(shared->CntrConfig.OstGateSource[cntrID], cntrID);
   ctlWord.CounterGatePolarity = (( Negative == shared->CntrConfig.OstGatePolarity[cntrID]) ? GP_LOW_FALLING : GP_HIGH_RISING);
   ctlWord.CounterEdge = (( Negative == shared->CntrConfig.OsClkPolarity[cntrID]) ? CNTR_EDGE_FALLING : CNTR_EDGE_RISING);

   printk("GateMode = %d, ClkSource = %d,OSClkSource = %d\n",ctlWord.CounterGateMode,ctlWord.CounterClkSource,shared->CntrConfig.OstClkSource[cntrID]);

   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   if (shared->CntrState[cntrID].Operation == CNTR_IDLE) {
      memset(&shared->CntrState[cntrID], 0, sizeof(CNTR_STATE));
      shared->CntrState[cntrID].Operation = OneShot;
   } else {
      spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
      return -EBUSY;
   }
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

   AdxMemOutD(shared->IoMemBase, DR_COUNTER0_MODE + (cntrID * 4), ctlWord.Value );

   AdxMemOutD(shared->IoMemBase, DR_COUNTER0_LOAD + (cntrID * 4), shared->CntrConfig.OstDelayCount[cntrID]-1);
   shared->FaiParam.XferMode = DAQ_XFER_DMA;
   // enable interrupt
   if ( ((0 == cntrID) && daq_device_event_alive(daq_dev, EvtCntOneShot0Idx)) || 
         ((1 == cntrID) && daq_device_event_alive(daq_dev, EvtCntOneShot1Idx)) 	)
   {
      shared->IsEvtSignaled[EvtCntOneShot0Idx+cntrID] = 0;
      EnableCounterInterrupt(daq_dev, cntrID);
      printk("Enable EvtCntOneShot%u\n",cntrID);
   }

   //
   daq_cntr_start(shared, cntrID);

   return 0;
}

static
int daq_cntr_start_event_count(daq_device_t *daq_dev, __u32 cntrID)
{
   DEVICE_SHARED  *shared = &daq_dev->shared;
   COUNTER_CHL_CSR ctlWord = {0};
   unsigned long  flags;

   //Mode A
   ctlWord.CounterRepe = CNTR_MODE_REPETITIVELY;
   ctlWord.CounterReload = CNTR_MODE_FROM_LOAD;

   //Default configuration
   ctlWord.CounterMode = CNTR_MODE_UP;
   ctlWord.CounterClkSource = CNTR_CLOCK_SOURCE_CLK_N;
   ctlWord.CounterGateClkSource = CNTR_GATE_SOURCE_GATEN;
   ctlWord.CounterOutputEnable = CNTR_OUTPUT_DISENABLE;
   ctlWord.CounterOutputMode = CNTR_OUTPUT_HIGH_PULSE;
   ctlWord.CounterGatePolarity = (( Negative == shared->CntrConfig.EcGatePolarity[cntrID]) ? GP_LOW_FALLING : GP_HIGH_RISING);
   ctlWord.CounterEdge = (( Negative == shared->CntrConfig.EcClockPolarity[cntrID]) ? CNTR_EDGE_FALLING : CNTR_EDGE_RISING);
   ctlWord.CounterGateMode = shared->CntrConfig.EcGateEnable[cntrID];

   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   if (shared->CntrState[cntrID].Operation == CNTR_IDLE) {
      memset(&shared->CntrState[cntrID], 0, sizeof(CNTR_STATE));
      shared->CntrState[cntrID].Operation = InstantEventCount;
   } else {
      spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
      return -EBUSY;
   }
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

   AdxMemOutD(shared->IoMemBase, DR_COUNTER0_MODE + (cntrID * 4), ctlWord.Value );
   AdxMemOutD(shared->IoMemBase, DR_COUNTER0_LOAD + (cntrID * 4), 0 );
   AdxMemOutD(shared->IoMemBase, DR_COUNTER0_HOLD + (cntrID * 4), 0 );

   daq_cntr_start(shared, cntrID);
   return 0;
}

static
int daq_cntr_start_timer_pulse(daq_device_t *daq_dev, __u32 cntrID)
{
   DEVICE_SHARED  *shared = &daq_dev->shared;
   COUNTER_CHL_CSR ctlWord = {0};
   unsigned long  flags;
   __u32  outEn = 0;

   //Mode E
   ctlWord.CounterRepe = CNTR_MODE_REPETITIVELY;
   ctlWord.CounterReload = CNTR_MODE_FROM_LOAD;
   ctlWord.CounterGateMode =shared->CntrConfig.TmGateEnable[cntrID];

   //Default configuration
   ctlWord.CounterClkSource = CNTR_CLOCK_SOURCE_20M;
   ctlWord.CounterEdge = CNTR_EDGE_RISING;
   ctlWord.CounterGateClkSource = CNTR_GATE_SOURCE_GATEN;
   ctlWord.CounterMode = CNTR_MODE_DOWN;
   ctlWord.CounterOutputEnable = CNTR_OUTPUT_ENABLE;
   ctlWord.CounterGatePolarity = (( Negative == shared->CntrConfig.TmGatePolarity[cntrID]) ? GP_LOW_FALLING : GP_HIGH_RISING);
   ctlWord.CounterOutputMode   =  CntrOutSignalBioToHw(shared->CntrConfig.TmOutSignal[cntrID], &outEn);

   printk("TmOutSignal = %u, CounterOutputMode =   %u\n",shared->CntrConfig.TmOutSignal[cntrID],ctlWord.CounterOutputMode);

   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   if (shared->CntrState[cntrID].Operation == CNTR_IDLE) {
      memset(&shared->CntrState[cntrID], 0, sizeof(CNTR_STATE));
      shared->CntrState[cntrID].Operation = TimerPulse;
   } else {
      spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
      return -EBUSY;
   }
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

   AdxMemOutD(shared->IoMemBase, DR_COUNTER0_MODE + (cntrID * 4), ctlWord.Value );

   AdxMemOutD(shared->IoMemBase, DR_COUNTER0_LOAD + (cntrID * 4), shared->CntrConfig.TmrFreqDiv[cntrID]);

   printk("TimerPulse = %u: ctrl =  0x%8X,load = %u\n",cntrID,ctlWord.Value,shared->CntrConfig.TmrFreqDiv[cntrID]);

   // enable interrupt
   if ( ((0 == cntrID) && daq_device_event_alive(daq_dev, EvtCntTimer0Idx)) || 
         ((1 == cntrID) && daq_device_event_alive(daq_dev, EvtCntTimer1Idx)) 	)
   {
      shared->IsEvtSignaled[EvtCntOneShot0Idx+cntrID] = 0;
      EnableCounterInterrupt(daq_dev, cntrID);
   }

   //

   daq_cntr_start(shared, cntrID);

   return 0;
}

static
int daq_cntr_start_freq_measure(daq_device_t *daq_dev, __u32 cntrID)
{
   DEVICE_SHARED  *shared = &daq_dev->shared;
   COUNTER_CHL_CSR ctlWord = {0};
   struct timespec     tm_now;
   unsigned long  flags;

   //X3 Mode
   ctlWord.CounterRepe = CNTR_MODE_REPETITIVELY;////1
   ctlWord.CounterReload = CNTR_MODE_FROM_HOLD;////1
   ctlWord.CounterGateMode = CNTR_GATE_MODE_PULSE;///3

   //Default configuration
   ctlWord.CounterMode = CNTR_MODE_UP;///1
   ctlWord.CounterEdge = CNTR_EDGE_RISING;////0
   ctlWord.CounterGatePolarity = GP_HIGH_RISING;////0
   ctlWord.CounterOutputMode = CNTR_OUTPUT_HIGH_PULSE;////0;
   ctlWord.CounterOutputEnable = CNTR_OUTPUT_DISENABLE;////0

   // set clock source and gate source according to FmMethod
   if ( CountingPulseByDevTime == shared->CntrConfig.FmMethod[cntrID] )
   {
      if ( shared->CntrConfig.FmPeriod[cntrID] < 5 )
      {
         daq_dev->CntrFmParamIdx[cntrID] = 3;  
      }
      else if ( shared->CntrConfig.FmPeriod[cntrID] < 50 )
      {
         daq_dev->CntrFmParamIdx[cntrID] = 2;
      }
      else if ( shared->CntrConfig.FmPeriod[cntrID] < 500 )
      {
         daq_dev->CntrFmParamIdx[cntrID] = 1;
      }
      else
      {
         daq_dev->CntrFmParamIdx[cntrID] = 4;
      }
   }
   else
   {
      daq_dev->CntrFmParamIdx[cntrID] = 0;
   }

   ctlWord.CounterClkSource = s_FmParam[daq_dev->CntrFmParamIdx[cntrID]].ClockSource; ////0
   ctlWord.CounterGateClkSource = s_FmParam[daq_dev->CntrFmParamIdx[cntrID]].GateSource;////8

   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   if (shared->CntrState[cntrID].Operation == CNTR_IDLE) {
      memset(&shared->CntrState[cntrID], 0, sizeof(CNTR_STATE));
      shared->CntrState[cntrID].Operation = InstantFreqMeter;
   } else {
      spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
      return -EBUSY;
   }

   printk("CntrFmParamIdx = %d\n",daq_dev->CntrFmParamIdx[cntrID]);
   printk("Counter Clk Source = %d , Gate Clk Source = %d \n",ctlWord.CounterClkSource,ctlWord.CounterGateClkSource);

   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

   AdxMemOutD(shared->IoMemBase, DR_COUNTER0_MODE + (cntrID * 4), ctlWord.Value );

   AdxMemOutD(shared->IoMemBase, DR_COUNTER0_LOAD + (cntrID * 4), 0);
   AdxMemOutD(shared->IoMemBase, DR_COUNTER0_HOLD + (cntrID * 4), 0);

   //
   // prepare cntrStatus
   //

   printk("ctlWord = 0x%8X\n",ctlWord.Value);
   ctlWord.Value =  AdxMemInD(shared->IoMemBase, DR_COUNTER0_MODE + (cntrID * 4) );
   printk("ctlWord = 0x%8X\n",ctlWord.Value);

   daq_cntr_start(shared, cntrID);

   shared->CntrConfig.BaseFreq[cntrID] = s_FmParam[daq_dev->CntrFmParamIdx[cntrID]].BaseFreq;
   shared->CntrConfig.FmMethod[cntrID] = s_FmParam[daq_dev->CntrFmParamIdx[cntrID]].FmMethod;

   daq_dev->cntr_interval = 100;

   tm_now = current_kernel_time();
   shared->CntrState[cntrID].PrevTime = timespec_to_ns(&tm_now);
   shared->CntrChkTimerOwner |= 0x1 << cntrID;
   schedule_delayed_work(&daq_dev->cntr_fm_work, 1);

   return 0;
}

static
void daq_cntr_update_mf_config(COUNTER_CHL_CSR *ctlWord, __u8 clockSrc, __u8 gateSrc)
{
   ctlWord->CounterClkSource = clockSrc;
   ctlWord->CounterGateClkSource = gateSrc;
}

static
void daq_cntr_update_pwm_state(CNTR_STATE *cntr, __s64 *tm_stamp, __u8 ch)
{
   __u32  tm_delta;
   tm_delta = (__u32)(*tm_stamp - cntr->PrevTime);
   cntr->CanRead = 1;
}

static
void daq_cntr_update_fm_state(DEVICE_SHARED *shared, COUNTER_CHL_CSR ctlWord, __s64 *tm_stamp, __u8 ch, __u8 changed)
{
   shared->CntrState[ch].CanRead = 1;
   shared->CntrState[ch].PrevTime = *tm_stamp;

   if(changed){
      AdxMemOutD(shared->IoMemBase, DR_COUNTER0_MODE + (ch * 4), ctlWord.Value );
   }
}

static
int daq_cntr_start_pwm_in(daq_device_t *daq_dev, __u32 cntrID)
{
   DEVICE_SHARED  *shared = &daq_dev->shared;
   COUNTER_CHL_CSR ctlWord = {0};
   unsigned long  flags;

   //Mode X3 
   ctlWord.CounterRepe = CNTR_MODE_REPETITIVELY;
   ctlWord.CounterReload = CNTR_MODE_FROM_HOLD;
   ctlWord.CounterGateMode = CNTR_GATE_MODE_PULSE;

   //Default configuration
   ctlWord.CounterMode = CNTR_MODE_UP;
   ctlWord.CounterClkSource = CNTR_CLOCK_SOURCE_20M;
   ctlWord.CounterEdge = CNTR_EDGE_RISING;
   ctlWord.CounterGateClkSource = CNTR_GATE_SOURCE_GATEN;
   ctlWord.CounterGatePolarity = GP_HIGH_RISING;
   ctlWord.CounterOutputMode = CNTR_OUTPUT_HIGH_PULSE;
   ctlWord.CounterOutputEnable = CNTR_OUTPUT_DISENABLE;


   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   if (shared->CntrState[cntrID].Operation == CNTR_IDLE) {
      memset(&shared->CntrState[cntrID], 0, sizeof(CNTR_STATE));
      shared->CntrState[cntrID].Operation = InstantPwmIn;
   } else {
      spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
      return -EBUSY;
   }
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

   AdxMemOutD(shared->IoMemBase, DR_COUNTER0_LOAD + (cntrID * 4), 0);
   AdxMemOutD(shared->IoMemBase, DR_COUNTER0_HOLD + (cntrID * 4), 0);

   AdxMemOutD(shared->IoMemBase, DR_COUNTER0_MODE + (cntrID * 4), ctlWord.Value );

   daq_cntr_start(shared, cntrID);

   schedule_delayed_work(&daq_dev->cntr_fm_work, 1);

   printk("CntrChkTimerOwner = %u\n",shared->CntrChkTimerOwner);
   shared->CntrChkTimerOwner |= 0x1 << cntrID;

   printk("CntrChkTimerOwner = %u\n",shared->CntrChkTimerOwner);
   return 0;
}

static
int daq_cntr_start_pwm_out(daq_device_t *daq_dev, __u32 cntrID)
{
   DEVICE_SHARED  *shared = &daq_dev->shared;
   COUNTER_CHL_CSR ctlWord = {0};
   unsigned long  flags;

   //Mode K
   ctlWord.CounterRepe = CNTR_MODE_REPETITIVELY;
   ctlWord.CounterReload = CNTR_MODE_FROM_HOLD;
   ctlWord.CounterGateMode = shared->CntrConfig.PoGateEn[cntrID];

   //Default configuration
   ctlWord.CounterClkSource = CNTR_CLOCK_SOURCE_20M;
   ctlWord.CounterMode = CNTR_MODE_DOWN;
   ctlWord.CounterEdge = CNTR_EDGE_RISING;
   ctlWord.CounterGateClkSource = CNTR_GATE_SOURCE_GATEN;
   ctlWord.CounterGatePolarity = (( Negative == shared->CntrConfig.PoGatePolarity[cntrID]) ? GP_LOW_FALLING : GP_HIGH_RISING);
   ctlWord.CounterOutputMode = CNTR_OUTPUT_HIGH_TTL;
   ctlWord.CounterOutputEnable = CNTR_OUTPUT_ENABLE;

   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   if (shared->CntrState[cntrID].Operation == CNTR_IDLE) {
      memset(&shared->CntrState[cntrID], 0, sizeof(CNTR_STATE));
      shared->CntrState[cntrID].Operation = InstantPwmOut;
   } else {
      spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
      return -EBUSY;
   }
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

   AdxMemOutD(shared->IoMemBase, DR_COUNTER0_MODE + (cntrID * 4), ctlWord.Value );
   AdxMemOutD(shared->IoMemBase, DR_COUNTER0_LOAD + (cntrID * 4), shared->CntrConfig.PoLowDiv[cntrID]);
   AdxMemOutD(shared->IoMemBase, DR_COUNTER0_HOLD + (cntrID * 4), shared->CntrConfig.PoHighDiv[cntrID]);

   daq_cntr_start(shared, cntrID);

   printk("PWM out = %d: crtl = 0x%08X , hold = %u , load = %u !\n",cntrID,ctlWord.Value, shared->CntrConfig.PoHighDiv[cntrID],shared->CntrConfig.PoLowDiv[cntrID]);

   return 0;
}

//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------
void daq_cntr_update_state_work_func(struct work_struct *work)
{
   daq_device_t        *daq_dev = container_of(delayed_work_ptr(work), daq_device_t, cntr_fm_work);
   DEVICE_SHARED       *shared  = &daq_dev->shared;
   struct timespec     tm_now;
   __s64               tm_now_ns;
   __u32               i;
   __u32 active= shared->CntrChkTimerOwner;
   __u32 changed = 0, delay = 1;
   __u32 SumPeriod[CNTR_CHL_COUNT];
   __u32 LowPeriod[CNTR_CHL_COUNT], HiPeriod[CNTR_CHL_COUNT];
   __u32 currentValue[CNTR_CHL_COUNT];
   __u32 idx;

   COUNTER_CHL_CSR ctlWord = { 0 };

   getnstimeofday(&tm_now);
   tm_now_ns = timespec_to_ns(&tm_now);

   for (i = 0; active; ++i, active >>= 1){
      if (active & 0x1) {
	  	 currentValue[i] = AdxMemInD(shared->IoMemBase, DR_COUNTER0_DATA + i*4);
         LowPeriod[i]    = AdxMemInD(shared->IoMemBase, DR_COUNTER0_LOAD + i*4);
         HiPeriod[i]     =  AdxMemInD(shared->IoMemBase, DR_COUNTER0_HOLD + i*4);

         shared->CntrConfig.PoLowDiv[i] = LowPeriod[i];
         shared->CntrConfig.PoHighDiv[i] = HiPeriod[i];
         //if Count's operation is InstantFreqMeter
         if (shared->CntrState[i].Operation == InstantFreqMeter){

			 if(daq_dev->cntr_interval-- == 0)
			 {
				  ctlWord.Value =  AdxMemInD(shared->IoMemBase, DR_COUNTER0_MODE + (i*4));
				  
				  SumPeriod[i] = LowPeriod[i] + HiPeriod[i];
				  shared->CntrState[i].SummedValue = SumPeriod[i];
				 
				  idx = daq_dev->CntrFmParamIdx[i];
				 
				 if ( (SumPeriod[i] > 0) 
					 || ((0 == SumPeriod[i]) && (0 == currentValue[i])) ) 
				 {
					 if ( SumPeriod[i] > s_FmParam[idx].UpperLimit )
					 {
						 idx = s_FmParam[idx].ForwardIdx;
					 }
					 else if ( SumPeriod[i] < s_FmParam[idx].LowerLimit )
					 {
						 idx = s_FmParam[idx].BackwardIdx;
					 }
				 }
				 
				 if ( idx != daq_dev->CntrFmParamIdx[i] )
					{
				 
						//printk("\nFreqMeter %u: prepare adjusting. paramIdx = %u, load = %u, hold = %u, current = %u\n",
						 //   i, daq_dev->CntrFmParamIdx[i], HiPeriod[i] , LowPeriod[i], currentValue[i]);
						//Reset counter
						AdxMemOutB(shared->IoMemBase, DR_COUNTER0_CMD+ i * 4, CNT_CMD_RESET);
						AdxMemOutB(shared->IoMemBase, DR_COUNTER0_ENABLE+ i * 4, 1);
				 
						daq_cntr_update_mf_config(&ctlWord, s_FmParam[idx].ClockSource, s_FmParam[idx].GateSource); 	
						//
						// update cntrStatus
						//
						shared->CntrConfig.FmMethod[i] = s_FmParam[idx].FmMethod;
						shared->CntrConfig.BaseFreq[i] = s_FmParam[idx].BaseFreq;
						daq_dev->CntrFmParamIdx[i] = idx;			 
						// set load and hold to 0
						AdxMemOutD(shared->IoMemBase, DR_COUNTER0_LOAD + i * 4, 0);
						AdxMemOutD(shared->IoMemBase, DR_COUNTER0_HOLD + i * 4, 0);
				 
						// set counter control register
						AdxMemOutD(shared->IoMemBase, DR_COUNTER0_MODE + i * 4, ctlWord.Value);
				 
						AdxMemOutB(shared->IoMemBase, DR_COUNTER0_CMD + i * 4, CNT_CMD_LOAD); 
						AdxMemOutB(shared->IoMemBase, DR_COUNTER0_ENABLE+ i * 4, 0x01);
				 
						AdxMemOutB(shared->IoMemBase, DR_COUNTER0_CMD + i * 4, CNT_CMD_ARM);
						AdxMemOutB(shared->IoMemBase, DR_COUNTER0_ENABLE+ i * 4, 0x01);
						
						//printk("ctlWord.Value	   =0x%8X , LowPeriod[%d] = %u , HiPeriod[%d] = %u\n",ctlWord.Value,i,LowPeriod[i],i,HiPeriod[i]);
				 
					}
				 
			 	daq_dev->cntr_interval = 100;
			 }

            //update measure frequencement state
            daq_cntr_update_fm_state(shared, ctlWord, &tm_now_ns, i, changed);
         } else if (shared->CntrState[i].Operation == InstantPwmIn){
         daq_cntr_update_pwm_state(&shared->CntrState[i], &tm_now_ns, i);
         }
      }
   }

   if (daq_dev->shared.CntrChkTimerOwner){
      schedule_delayed_work(delayed_work_ptr(work), msecs_to_jiffies(delay));
   }
}


int daq_ioctl_cntr_set_param(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   CNTR_SET_CFG  cntr;
   void*         dataPtr;
   __u32         valLen;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= CNTR_CHL_COUNT) {
      return -EINVAL;
   }

   if (cntr.Count > CNTR_CHL_COUNT - cntr.Start) {
      cntr.Count = CNTR_CHL_COUNT - cntr.Start;
   }
  
   switch (cntr.PropID)
   {
      // primal counter
      case CFG_ChipOperationModeOfCounters:
            dataPtr = &shared->CntrConfig.ChipOpMode[cntr.Start];
            valLen	= sizeof(__u32)*cntr.Count;
            break;
      case CFG_ChipSignalCountingTypeOfCounters:
            dataPtr = &shared->CntrConfig.ChipCntType[cntr.Start];
            valLen	= sizeof(__u32)*cntr.Count;
            break;
      case CFG_ChipClkSourceOfCounters:
            dataPtr = &shared->CntrConfig.ChipClkSource[cntr.Start];
            valLen	= sizeof(__u32)*cntr.Count;
            break;
      case CFG_ChipClkPolarityOfCounters:
            dataPtr = &shared->CntrConfig.ChipClkPolarity[cntr.Start];
            valLen	= sizeof(__u32)*cntr.Count;
            break;
      case CFG_ChipGateSourceOfCounters:
            dataPtr = &shared->CntrConfig.ChipGateSrc[cntr.Start];
            valLen	= sizeof(__u32)*cntr.Count;
            break;
      case CFG_ChipGatePolarityOfCounters:
            dataPtr = &shared->CntrConfig.ChipGatePolarity[cntr.Start];
            valLen	= sizeof(__u32)*cntr.Count;
            break;
      case CFG_ChipOutSignalOfCounters:
            dataPtr = &shared->CntrConfig.ChipOutSignal[cntr.Start];
            valLen	= sizeof(__u32)*cntr.Count;
            break;
      case CFG_ChipLoadValueOfCounters:
            dataPtr = &shared->CntrConfig.ChipLoadValue[cntr.Start];
            valLen	= sizeof(__u32)*cntr.Count;
            break;
      case CFG_ChipHoldValueOfCounters:
            dataPtr = &shared->CntrConfig.ChipHoldValue[cntr.Start];
            valLen	= sizeof(__u32)*cntr.Count;
            break;

      // EventCount Feature
      case CFG_EcClkPolarityOfCounters:
            dataPtr = &shared->CntrConfig.EcClockPolarity[cntr.Start];
            valLen  = sizeof(__u32) * cntr.Count;
            break;
      case CFG_EcGateEnabledOfCounters:
            dataPtr = &shared->CntrConfig.EcGateEnable[cntr.Start];
            valLen  = sizeof(__u32) * cntr.Count;
            break;
      case CFG_EcGatePolarityOfCounters:
            dataPtr = &shared->CntrConfig.EcGatePolarity[cntr.Start];
            valLen  = sizeof(__u32) * cntr.Count;
            break;
      // OneShot Feature
      case CFG_OsClkSourceOfCounters:
            dataPtr = &shared->CntrConfig.OstClkSource[cntr.Start];
            valLen  = sizeof(__u32) * cntr.Count;
            break;
      case CFG_OsClkPolarityOfCounters:
            dataPtr = &shared->CntrConfig.OsClkPolarity[cntr.Start];
            valLen  = sizeof(__u32)*cntr.Count;
            break;		
      case CFG_OsDelayCountOfCounters:
            dataPtr = &shared->CntrConfig.OstDelayCount[cntr.Start];
            valLen  = sizeof(__u32) * cntr.Count;
            break;
      case CFG_OsGateSourceOfCounters:
            dataPtr = &shared->CntrConfig.OstGateSource[cntr.Start];
            valLen  = sizeof(__u32) * cntr.Count;
            break;
      case CFG_OsGatePolarityOfCounters:
            dataPtr = &shared->CntrConfig.OstGatePolarity[cntr.Start];
            valLen  = sizeof(__u32) * cntr.Count;
            break;
      case CFG_OsOutSignalOfCounters:
            dataPtr = &shared->CntrConfig.OstOutSignal[cntr.Start];
            valLen  = sizeof(__u32) * cntr.Count;
            break;
      // TimerPulse  Feature
      case CFG_TmrGateEnabledOfCounters:
            dataPtr = &shared->CntrConfig.TmGateEnable[cntr.Start];
            valLen  = sizeof(__u32) * cntr.Count;
            break;
      case CFG_TmrGatePolarityOfCounters:
            dataPtr = &shared->CntrConfig.TmGatePolarity[cntr.Start];
            valLen  = sizeof(__u32) * cntr.Count;
            break;
      case CFG_TmrOutSignalOfCounters:
            dataPtr = &shared->CntrConfig.TmOutSignal[cntr.Start];
            valLen  = sizeof(__u32) * cntr.Count;
            break;	
      case CFG_TmrFrequencyOfCounters:
            dataPtr = &shared->CntrConfig.TmrFreqDiv[cntr.Start];
            valLen  = sizeof(__u32) * cntr.Count;
            break;		
      // Frequency Measurement Feature
      case CFG_FmMethodOfCounters:
            dataPtr = &shared->CntrConfig.FmMethod[cntr.Start];
            valLen  = sizeof(__u32)*cntr.Count;
            break;
      case CFG_FmCollectionPeriodOfCounters:
            dataPtr = &shared->CntrConfig.FmPeriod[cntr.Start];
            valLen  = sizeof(__u32) * cntr.Count;
            break;		
      // PWMout  Feature
      case CFG_PoHiPeriodOfCounters:
            dataPtr = &shared->CntrConfig.PoHighDiv[cntr.Start];
            valLen  = sizeof(__u32) * cntr.Count;
            break;
      case CFG_PoLoPeriodOfCounters:
            dataPtr = &shared->CntrConfig.PoLowDiv[cntr.Start];
            valLen  = sizeof(__u32) * cntr.Count;
            break;
      case CFG_PoGateEnabledOfCounters:
            dataPtr = &shared->CntrConfig.PoGateEn[cntr.Start];
            valLen  = sizeof(__u32) * cntr.Count;
            break;
      case CFG_PoGatePolarityOfCounters:
            dataPtr = &shared->CntrConfig.PoGatePolarity[cntr.Start];
            valLen  = sizeof(__u32) * cntr.Count;
            break;

      default:
            return -EINVAL;

   }

   if (unlikely(copy_from_user(dataPtr, cntr.Value, valLen))){
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_cntr_start(daq_device_t *daq_dev, unsigned long arg)
{
   CNTR_START cntr;
   unsigned i,ch;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= CNTR_CHL_COUNT || cntr.Count > CNTR_CHL_COUNT){
      return -EINVAL;
   }
  
   i = 0;
   ch = 0;
   switch(cntr.Operation)
   {
      case Primary:
            for ( i = 0; i < cntr.Count; i++ ){
               ch = (cntr.Start+i) % CNTR_CHL_COUNT;	 	
               return daq_cntr_start_primary(daq_dev, ch);
            };	 	
      case InstantEventCount:
            for ( i = 0; i < cntr.Count; i++ ){
               ch = (cntr.Start+i) % CNTR_CHL_COUNT;	 	
               return daq_cntr_start_event_count(daq_dev, ch);
            };
      case OneShot:
            for ( i = 0; i < cntr.Count; i++ ){
               ch = (cntr.Start+i) % CNTR_CHL_COUNT;	
               return daq_cntr_start_one_shot(daq_dev, ch);
            };
      case TimerPulse:
            for ( i = 0; i < cntr.Count; i++ ){
               ch = (cntr.Start+i) % CNTR_CHL_COUNT;	
               return daq_cntr_start_timer_pulse(daq_dev, ch);
            };	 	
      case InstantFreqMeter:
            for ( i = 0; i < cntr.Count; i++ ){
               ch = (cntr.Start+i) % CNTR_CHL_COUNT;	
               return daq_cntr_start_freq_measure(daq_dev, ch);
            };	 	
      case InstantPwmIn:
            for ( i = 0; i < cntr.Count; i++ ){
               ch = (cntr.Start+i) % CNTR_CHL_COUNT;	
               return daq_cntr_start_pwm_in(daq_dev, ch);
            };	 	
      case InstantPwmOut:
            for ( i = 0; i < cntr.Count; i++ ){
               ch = (cntr.Start+i) % CNTR_CHL_COUNT;	
               return daq_cntr_start_pwm_out(daq_dev, ch);
            };		 	
      default:
            return -ENOSYS;
   }
}

int daq_ioctl_cntr_read(daq_device_t *daq_dev, unsigned long arg)
{
   CNTR_READ  cntr;
   CNTR_VALUE vals[CNTR_CHL_COUNT];
   CNTR_VALUE *curr = vals;

   __u32 cnt_control_reg;
   __u32 cnt_hold_reg;
   __u32 cnt_data_reg;
   __u32 cnt_cmd_reg;
   __u32 i;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= CNTR_CHL_COUNT || cntr.Count > CNTR_CHL_COUNT){
      return -EINVAL;
   }

   {
      DEVICE_SHARED    *shared  = &daq_dev->shared;
      COUNTER_CHL_CSR  ctl_word = {0};

      cnt_control_reg = DR_COUNTER0_MODE + cntr.Start * 4;
      cnt_hold_reg = DR_COUNTER0_HOLD + cntr.Start * 4;
      cnt_data_reg = DR_COUNTER0_HOLD + cntr.Start * 4 + 0x10;
      cnt_cmd_reg = DR_COUNTER0_CMD + cntr.Start * 4;

      for(i = 0; i < cntr.Count; i++){
         ctl_word.Value = AdxMemInD(shared->IoMemBase, cnt_control_reg);
         if(!(ctl_word.Value & 0x20))
         {
            curr->CanRead= 1;
            AdxMemOutW(shared->IoMemBase, cnt_cmd_reg, CNT_CMD_SAVE);
            AdxMemOutB(shared->IoMemBase, DR_COUNTER0_ENABLE + (cntr.Start * 4), ENABLE_COUNTER);

            vals->Value = AdxMemInD(shared->IoMemBase, cnt_hold_reg);
         } else {
            curr->CanRead= 0;
         }
      }
   }

   if (unlikely(copy_to_user(cntr.Value, vals, cntr.Count * sizeof(CNTR_VALUE)))){
      return -EFAULT;
   }

   return 0;
}

void daq_cntr_reset(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED  *shared = &daq_dev->shared;
   COUNTER_CMD_CSR cmdWord = {0};
   unsigned long  flags, i;

   printk("Reset Counter\n");
   spin_lock_irqsave(&daq_dev->dev_lock, flags);

   for (i = 0; i < count; i++){

      DisableCounterInterrupt(daq_dev, i);
      //disarm counter
      cmdWord.CmdCode = DISARM;
      AdxMemOutW(shared->IoMemBase, DR_COUNTER0_CMD + i * 4, cmdWord.Value);

      //reset counter
      cmdWord.CmdCode = RESETCOUNTER;
      AdxMemOutW(shared->IoMemBase, DR_COUNTER0_CMD + i * 4, cmdWord.Value);

      //enable counter
      AdxMemOutW(shared->IoMemBase, DR_COUNTER0_ENABLE + i * 4, ENABLE_COUNTER);

      //cannel work if Operation is PwmIn
      if(shared->CntrState[i].Operation == InstantPwmIn || 
            shared->CntrState[i].Operation == InstantFreqMeter || 
            shared->CntrChkTimerOwner){
         cancel_delayed_work(&daq_dev->cntr_fm_work);
      }

      shared->CntrState[i].Operation = CNTR_IDLE;

      // properties for Primal Counter
      shared->CntrConfig.ChipOpMode[i]		 = C1780_MD;
      shared->CntrConfig.ChipCntType[i] 	     = DownCount;
      shared->CntrConfig.ChipClkSource[i]		 = SigInternal20MHz;
      shared->CntrConfig.ChipClkPolarity[i]   = Positive;
      shared->CntrConfig.ChipGateSrc[i] 	     = SigCntGate0+i;
      shared->CntrConfig.ChipGatePolarity[i]  = Positive;
      shared->CntrConfig.ChipOutSignal[i]	 = PositivePulse;
      shared->CntrConfig.ChipLoadValue[i] 	     = CNTR_MAX_VAL;
      shared->CntrConfig.ChipHoldValue[i] 	     = CNTR_MIN_VAL;

      //TimePulse
      shared->CntrConfig.TmGateEnable[i]   = 1;
      shared->CntrConfig.TmGatePolarity[i] = Positive;
      shared->CntrConfig.TmOutSignal[i]    = ToggledFromLow;
      shared->CntrConfig.TmrFreqDiv[i]     = 2000000-1; // 10 Hz
      //EventCount
      shared->CntrConfig.EcClockPolarity[i] = Positive;
      shared->CntrConfig.EcGateEnable[i]    = 0;
      shared->CntrConfig.EcGatePolarity[i]  = Positive;
      //OneShot
      shared->CntrConfig.OstDelayCount[i]  = 200000; // about 10 ms/pulse
      shared->CntrConfig.OstClkSource[i]   = SigInternal20MHz;
      shared->CntrConfig.OsClkPolarity[i]  = Positive;
      shared->CntrConfig.OstGateSource[i]  = SigCntGate0+i;
      shared->CntrConfig.OstGatePolarity[i] = Positive;
      shared->CntrConfig.OstOutSignal[i] = ToggledFromLow;
      //Frequency Measurement
      shared->CntrConfig.FmMethod[i]	= AutoAdaptive;
      shared->CntrConfig.FmPeriod[i] = 50;	 
      //PWM_OUT
      shared->CntrConfig.PoGateEn[i]	   = 1;
      shared->CntrConfig.PoGatePolarity[i] = Positive;
      shared->CntrConfig.PoHighDiv[i]	   = 1600000-1; // 0.08s
      shared->CntrConfig.PoLowDiv[i]	   =  400000-1; // 0.02s

      shared->CntrConfig.BaseFreq[i] = CNTR_CLK_BASE;
      shared->CntrChkTimerOwner &= ~(1<<i);
   }

   for (i = 0; i < count; i++){
      daq_dev->CntrFmParamIdx[i] = 0; 
   }

  
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
}

int daq_ioctl_cntr_reset(daq_device_t *daq_dev, unsigned long arg)
{
   CNTR_RESET cntr;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= CNTR_CHL_COUNT || cntr.Count > CNTR_CHL_COUNT){
      return -EINVAL;
   }
   daq_cntr_reset(daq_dev, cntr.Start, cntr.Count);

   return 0;
}
