/*
 * ai.c
 *
 *  Created on: 2012-06-04
 *      Author: W
 */

#include "kdriver.h"
#include "hw.h"

//static void PrintSgl( IN PPLX_SGL_ENTRY sglStart, IN ulong sglCount );


unsigned daq_ai_calc_log_chan_count(unsigned char *chType, unsigned count)
{
   unsigned logCount = count;
   unsigned i;

   for (i = 0; i < count; i += 2) {
      if (chType[i] == Differential) {
         --logCount;
      }
   }
   logCount = 8; //pci1706 channels are all differential
   return logCount;
}

static void msi_model_config(DEVICE_SHARED *shared)
{
   // the following 3 lines have no effect if the device is not in a group.
   AdxMemOutB(shared->IoMemBase, DR8_MSICLK0_SRC, shared->FaiParam.MsiModel.CnvClkSrc);                // AMSI clock 0 source
   AdxMemOutB(shared->IoMemBase, DR8_MSICLK0_DIR, shared->FaiParam.MsiModel.CnvClkDir);                // AMSI clock 0 direction
   AdxMemOutD(shared->IoMemBase, DR32_MSICLK0_DIV, shared->FaiParam.ConvDivide); // AMSI clock 0 divider

   AdxMemOutB(shared->IoMemBase, DR8_MSICLK1_SRC, shared->FaiParam.MsiModel.ScnClkSrc);                // AMSI clock 1 source
   AdxMemOutB(shared->IoMemBase, DR8_MSICLK1_DIR, shared->FaiParam.MsiModel.ScnClkDir);                // AMSI clock 1 direction
   AdxMemOutD(shared->IoMemBase, DR32_MSICLK1_DIV, shared->FaiParam.ScanDivide); // AMSI clock 1 divider

   AdxMemOutB(shared->IoMemBase, DR8_MSITRG0_SRC, shared->FaiParam.MsiModel.TrigSrc); // AMSI trigger source
   AdxMemOutB(shared->IoMemBase, DR8_MSITRG0_DIR, shared->FaiParam.MsiModel.TrigDir); // AMSI trigger direction
}


static
int daq_ai_configure_channel(DEVICE_SHARED *shared, __u32 chan, __u8 sctype, __u8 gain, __u8 dma)
{
   int ai_cmd_chan;
   AI_CHL_CTL ctl;

   shared->AiChanType[chan] = sctype;
   shared->AiChanGain[chan] = gain;

   ai_cmd_chan = DR_CONTROL_CH0 + (chan * 4);

   ctl.Value = 0;//= AdxMemInD(shared->IoMemBase, ai_cmd_chan);
   ctl.Fields.Data = 0;
   ctl.Fields.Gain = gain;
   ctl.Fields.DMA_Enable = dma;
   AdxMemOutD(shared->IoMemBase, ai_cmd_chan, ctl.Value);

   //Write 1 after gain changed
   AdxMemOutW(shared->IoMemBase, AI_GAIN_CHANGE, AI_GAIN_CHG_VALUE);

   return 0;
}

static
__u32 daq_ai_read_channel(DEVICE_SHARED *shared, unsigned timeout, unsigned channel)
{
   DEV_CTL_STA   sta;
   DEV_TRIG_SOURCE_REG trigSource;

   unsigned long absolute_timeout;
   unsigned readChannel;

   // Set TrigMode to Analog Trigger
   trigSource.Value = AdxMemInW(shared->IoMemBase, DR_TRIG_SOURCE);
   trigSource.TrigSource = 0x01;
   AdxMemOutW(shared->IoMemBase, DR_TRIG_SOURCE, trigSource.Value);

   // Trigger a A/D conversion.
   sta.Value =  AdxMemInW(shared->IoMemBase, DR_EN_AIWORK);
   sta.Tri = 0x1;	
   AdxMemOutW(shared->IoMemBase, DR_EN_AIWORK, sta.Value);

   // use time-out detecting.
   absolute_timeout = jiffies + msecs_to_jiffies(timeout);

   // waiting for data ready
   do {
      sta.Value = AdxMemInD(shared->IoMemBase, DR_EN_AIWORK);
      if (sta.Tri){
         break;
      }
      if (time_is_before_jiffies(absolute_timeout)){
         daq_trace((KERN_ERR "read ai time-out."));
         return -1;
      }
   }while (1);

   readChannel = channel * 4;
   return AdxMemInD(shared->IoMemBase, readChannel);
}

static
void daq_fai_prepare_hardware(DEVICE_SHARED *shared)
{
   uint32 status;
   // Disable device interrupt
   status = AdxMemInW(shared->IoMemBase, DR_INTR_FLAG);
   AdxMemOutW(shared->IoMemBase, DR_INTR_FLAG, status);

   // PLX9056 register setup ---------------------------------------
   //
   // Local Address Space 0 Local Base Address
   // Enable Local address space 0, base address 0
   {
      PLX_LAS0_BA las0ba = {0};
      las0ba.Spc0En  = 1;
      AdxMemOutW(shared->BrMemBase, BR_PLX_LAS0BA, las0ba.Value);
   }
   // Mode/DMA Arbitration
   // Local Bus BREQ Enable, Local Bus Direct Slave Release Bus Mode
   {
      PLX_MOD_DMA_ARB marbr  = {0};
      marbr.LocBusBREQEn = 1;
      marbr.LocBusDSRBM  = 1;
      AdxMemOutD(shared->BrMemBase, BR_PLX_MODDMAARB, marbr.Value);
   }
   // Interrupt Control / Status register
   // PCI Interrupt Enable, Local DMA Channel 1 Interrupt Enable.
   {
      PLX_INT_CSR intcsr = {0};
      intcsr.PciIntEn     = 1;
      intcsr.LocDMA1IntEn = 0;
      intcsr.LocIntInputEn = 1;
      AdxMemOutD(shared->BrMemBase, BR_PLX_INTCSR, intcsr.Value);
   }
   // Local Address Space 0/Expansion ROM Bus Region Descriptor
   // 32bit local bus width, 3 internal wait state
   {
      PLX_LAS0_BUS_RGN_DPR lbrd = {0};
      lbrd.MemSpc0LBWidth   = 3;
      lbrd.MemSpc0WaitState = 1;
      AdxMemOutW(shared->BrMemBase, BR_PLX_LAS0BUSRGNDPR, lbrd.Value);
   }
   // DMA Threshold
   // zero for all field.
   {
      PLX_DMA_THR dmathr = {0};
      AdxMemOutW(shared->BrMemBase, BR_PLX_DMATHR, dmathr.Value);
   }
   // DMA Channel 1 Mode
   // Local bus width : 32Bit, Internal wait state: 3
   // Local Burst Enable, Scatter/Gather Mode, Done Interrupt Enable,
   // Local Addressing Mode 1 ( holds the Local Address bus constant),
   // Demand Mode, DMA Channel 1 Interrupt Select.
   {
      PLX_DMA_MODE dmamode = {0};
      dmamode.LocBusWidth   = 3;
      dmamode.IntlWaitState = 2;
      dmamode.LocBurstEn    = 0;
      dmamode.SGModeEn      = 1;
      dmamode.LocAddrMode   = 1;
      dmamode.DemandModeEn  = 1;
      dmamode.DmaIntSelect  = 1;
      dmamode.DoneIntEn     = 1;
      dmamode.DacChainLoad  = 0;//PLX_DAC_CHAIN_LOAD;
      AdxMemOutD(shared->BrMemBase, BR_PLX_DMAMODE1, dmamode.Value);
   }
}

//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------
void daq_ai_initialize_hw(daq_device_t *daq_dev)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   int i;

   for (i = 0; i < AI_CHL_COUNT; ++i) {
      daq_ai_configure_channel(shared, i, shared->AiChanType[i], shared->AiChanGain[i], AI_DMA_DISABLE);
   }

   shared->AiLogChanCount = daq_ai_calc_log_chan_count(shared->AiChanType, AI_CHL_COUNT);
}

void daq_fai_stop_acquisition(daq_device_t *daq_dev)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   unsigned long flags, status, i;

   spin_lock_irqsave(&daq_dev->fai_lock, flags);
   if (shared->FaiStatus.FnState != DAQ_FN_RUNNING){
      spin_unlock_irqrestore(&daq_dev->fai_lock, flags);
      return;
   }
   shared->FaiStatus.FnState = DAQ_FN_STOPPED;
   spin_unlock_irqrestore(&daq_dev->fai_lock, flags);

   AdxMemOutW(shared->IoMemBase, DR_EN_AIWORK, 0);
   status = AdxMemInW(shared->IoMemBase, DR_INTR_FLAG);
   AdxMemOutW(shared->IoMemBase, DR_INTR_FLAG, status);

   //Disable interrupt
   {
      INT_EN_REG int_enable;
      int_enable.Value = AdxMemInW(shared->IoMemBase, DR_EN_INTR);
      int_enable.Fields.EnFifoAF = 0;
      int_enable.Fields.EnFifoFF = 0;
      int_enable.Fields.EnAiStopByHw = 0;
      AdxMemOutW(shared->IoMemBase, DR_EN_INTR, int_enable.Value);
   }
   //Clear DMA Enable of Each Channel
   for (i = 0; i < AI_CHL_COUNT; i++){
      daq_ai_configure_channel(shared, i, shared->AiChanType[i], shared->AiChanGain[i], AI_DMA_DISABLE);
   }
#ifdef  DEBUG_1706
   unsigned int tmp = 0;
   printk(KERN_ALERT"-----Stop FAI------PCI  1706  CONFIGURATION TABLE--------------\n");
   for (i = 0; i < 0xff; i += 2){
      tmp = AdxMemInW(shared->IoMemBase, i);
      if ((i != 0) && (i % 16) == 0) printk(KERN_ALERT"\n");
      if ((i == 0) || (i % 16) == 0) printk(KERN_ALERT"Offset: 0x%4x: ", i);	
      printk(KERN_ALERT" %04x ", tmp);
   }
   printk(KERN_ALERT" ");
   printk(KERN_ALERT"-----------PCI  1706  CONFIGURATION TABLE END--------------\n");
#endif

   if (shared->FaiParam.XferMode == DAQ_XFER_DMA)
   {
      // Stop DMA transfer
      PLX_DMA_CSR dmacsr;
      dmacsr.Value  = AdxMemInB(shared->BrMemBase, BR_PLX_DMACSR1);
      dmacsr.Enable = 0;
      {
         PLX_INT_CSR intcsr = {0};
         intcsr.PciIntEn     = 0;
         intcsr.LocDMA1IntEn = 0;
         AdxMemOutD(shared->BrMemBase, BR_PLX_INTCSR, intcsr.Value);
      }     
      AdxMemOutB(shared->BrMemBase, BR_PLX_DMACSR1, dmacsr.Value);
      if (!dmacsr.Done)
      {
         do{
            dmacsr.Abort = 1;
            AdxMemOutB(shared->BrMemBase, BR_PLX_DMACSR1, dmacsr.Value);
            dmacsr.Value = AdxMemInB(shared->BrMemBase, BR_PLX_DMACSR1);
         } while (!dmacsr.Done);
      }
   }

   daq_device_signal_event(daq_dev, KdxAiStopped);
   wake_up_interruptible(&daq_dev->fai_queue);
}

void daq_fai_cleanup(daq_device_t *daq_dev)
{
   unsigned long flags;

   daq_fai_stop_acquisition(daq_dev);

   daq_umem_free(&daq_dev->fai_buffer);
   //daq_kmem_free(&daq_dev->fai_sgl);
   daq_plx905x_free_sgl_mem(&daq_dev->fai_sgl);

   spin_lock_irqsave(&daq_dev->fai_lock, flags);
   daq_dev->shared.FaiStatus.FnState = DAQ_FN_IDLE;
   spin_unlock_irqrestore(&daq_dev->fai_lock, flags);
}

int daq_ioctl_ai_set_channel(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   AI_SET_CHAN   xbuf;
   AI_CHAN_CFG   cfg[AI_CHL_COUNT];
   __u32         i, ch;

   if (unlikely(shared->FaiStatus.FnState == DAQ_FN_RUNNING)){
      return -EBUSY;
   }

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }
   if (unlikely(xbuf.PhyChanCount > AI_CHL_COUNT)){
      xbuf.PhyChanCount = AI_CHL_COUNT;
   }
   if (unlikely(copy_from_user(cfg, (void *)xbuf.ChanCfg, sizeof(AI_CHAN_CFG) * xbuf.PhyChanCount))){
      return -EFAULT;
   }

   for (i = 0; i < xbuf.PhyChanCount; ++i)
   {
      ch = (xbuf.PhyChanStart + i) & AI_CHL_MASK;
      daq_ai_configure_channel(shared, ch, cfg[i].SCType, cfg[i].Gain, AI_DMA_ENABLE);
   }

   shared->AiLogChanCount = daq_ai_calc_log_chan_count(shared->AiChanType, AI_CHL_COUNT * 2);//all channels are static differetial

   return 0;
}

int daq_ioctl_ai_read_sample(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED   *shared = &daq_dev->shared;
   AI_READ_SAMPLES xbuf;
   __u32           sample[AI_CHL_COUNT];
   __u32           *data_ptr;
   __u32           result;
   __u16				chStart, chCount;

   if (unlikely(daq_dev->shared.FaiStatus.FnState == DAQ_FN_RUNNING)){
      return -EBUSY;
   }

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   chStart = xbuf.PhyChanStart & AI_CHL_MASK;
   xbuf.LogChanCount =  x_min(xbuf.LogChanCount, shared->AiLogChanCount);
   chCount = xbuf.LogChanCount;

   // Read samples
   for(data_ptr = sample; data_ptr < sample + xbuf.LogChanCount; ++data_ptr, ++chStart){
      udelay(SAI_DELAY_TIME);
      result = daq_ai_read_channel(shared, SAI_TIMEOUT_VAL, chStart);
      if (result == -1){
         return -EIO;
      }
      *data_ptr = result;
   }

   if (unlikely(copy_to_user((void *)xbuf.Data, sample, xbuf.LogChanCount * sizeof(__u32)))) {
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_fai_set_param(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   FAI_CONFIG    xbuf;
   unsigned long flags;
   int           ret = 0;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   spin_lock_irqsave(&daq_dev->fai_lock, flags);
   if (unlikely(shared->FaiStatus.FnState != DAQ_FN_IDLE)){
      ret = -EBUSY;
   } else {
      shared->FaiParam              = xbuf;
      shared->FaiParam.PhyChanStart = xbuf.PhyChanStart & AI_CHL_MASK;
      shared->FaiParam.LogChanCount = x_min(xbuf.LogChanCount, shared->AiLogChanCount);
   }
   spin_unlock_irqrestore(&daq_dev->fai_lock, flags);

   if (likely(!ret)){
      daq_device_signal_event(daq_dev, KdxDevPropChged);
   }

   return ret;
}

/*static void PrintSgl( IN PPLX_SGL_ENTRY sglStart, IN ulong sglCount )
{
    PPLX_SGL_ENTRY sglEntry;
    unsigned long i;

    daq_trace(((KERN_ALERT"Print SGL...sglCount = %u\n"), sglCount));

    for ( i = 0; i < sglCount; i++ )
    {
        sglEntry = sglStart + i;
        daq_trace((KERN_ALERT"\n"));
        daq_trace((KERN_ALERT"SGL[%u]: va = %08X\n", i, sglEntry));
        daq_trace((KERN_ALERT"PciAddrlow = %08X\n", sglEntry->PciAddrLow));
#if defined(_WIN64) || defined(__x86_64)
        daq_trace((KERN_ALERT"PciAddrhigh = %08X\n", sglEntry->PciAddrHigh));
#endif
        daq_trace((KERN_ALERT"LocAddress = %08X\n", sglEntry->LocAddress));
        daq_trace((KERN_ALERT"DataLength = %u\n", sglEntry->DataLength));

        if ( sglEntry->DescPtr.TermCountInt )
        {
            daq_trace((KERN_ALERT"DescPtr    = %08X\t---------------Interrupt------------\n", sglEntry->DescPtr));
        }
        else
        {
            daq_trace((KERN_ALERT"DescPtr    = %08X\n", sglEntry->DescPtr));
        }
    }
    daq_trace((KERN_ALERT"\n"));
}
*/

int daq_ioctl_fai_set_buffer(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   FAI_CONFIG    *faiParam = &shared->FaiParam;
   FAI_STATUS    *faiStatus = &shared->FaiStatus;
   
   unsigned long flags;
   unsigned      sgl_len, data_len, sect_len;
   int           ret = 0;

   daq_trace((KERN_ALERT"----------------------------------daq_ioctl_fai_set_buffer------------------------------\n"));
   if(unlikely(!faiParam -> SampleCount)){
      return -EINVAL;
   }

   spin_lock_irqsave(&daq_dev->fai_lock, flags);
   if (unlikely(faiStatus->FnState != DAQ_FN_IDLE)){
      ret = -EBUSY;
   } else {
      shared->FaiStatus.FnState     = DAQ_FN_READY;
      faiStatus->BufLength = faiParam->SampleCount;
   }
   spin_unlock_irqrestore(&daq_dev->fai_lock, flags);

   do {
         if (unlikely(ret)){
            break;
         }

         data_len = faiParam->SampleCount * AI_DATA_SIZE;
         ret = daq_umem_alloc(data_len, &daq_dev->fai_buffer, 1);
         if(unlikely(ret)){
            break;
         }

         sect_len = faiParam->SectionSize * AI_DATA_SIZE;
         if(faiParam->XferMode == DAQ_XFER_DMA){
            sgl_len = daq_plx905x_calc_sgl_length(data_len, sect_len);
            ret = daq_plx905x_alloc_sgl_mem(sgl_len, &daq_dev->fai_sgl);
            if(unlikely(ret)){
               break;
            }

            ret = daq_plx905x_build_sgl(&daq_dev->fai_buffer, 
                  data_len, sect_len, DR_AI_DATA, 1, &daq_dev->fai_sgl);
            if(unlikely(ret)){
               break;
            }
            
            daq_dev->SglStartVa = daq_dev->fai_sgl.start;//(PLX_SGL_ENTRY *)daq_dev->fai_sgl.pages[0];
            daq_dev->SglEndVa = daq_dev->fai_sgl.end;//daq_dev->fai_sgl_end;
            daq_trace((KERN_ALERT"----------------------------------PrintSgl------------------------------\n"));
            //PrintSgl(daq_dev->SglStartVa,10);
            
            daq_fai_prepare_hardware(shared);
           }
         }while (0);
   
   if (ret){
      daq_umem_free(&daq_dev->fai_buffer);
      //daq_kmem_free(&daq_dev->fai_sgl);
      daq_plx905x_free_sgl_mem(&daq_dev->fai_sgl);
      shared->FaiStatus.FnState = DAQ_FN_IDLE;
   }

   return ret;
}


int daq_ioctl_fai_start(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   DEV_CTL_STA   dev_csr;
   unsigned long flags;
   int           ret = 0;
   int16 startCh, chanCount, i, Channel;
  

   spin_lock_irqsave(&daq_dev->fai_lock, flags);
   do{
      if (shared->FaiStatus.FnState == DAQ_FN_IDLE){
         ret = -EINVAL;
         break;
      }

      if (shared->FaiStatus.FnState == DAQ_FN_RUNNING){
         ret = -EBUSY;
         break;
      }

      memset(shared->IsEvtSignaled, 0, sizeof(shared->IsEvtSignaled));
      memset(&shared->FaiStatus, 0, sizeof(FAI_STATUS));
      shared->FaiStatus.FnState   = DAQ_FN_RUNNING;
      shared->FaiStatus.AcqMode   = (__u32)arg;
      shared->FaiStatus.BufLength = shared->FaiParam.SampleCount;
      shared->FaiStatus.WritePos = 0;
      shared->FaiStatus.ReadPos = 0;
      shared->FaiStatus.WPRunBack = 0;

   } while (0);
  
   spin_unlock_irqrestore(&daq_dev->fai_lock, flags);

   if (ret){
      return ret;
   }

   daq_device_clear_event(daq_dev, KdxAiDataReady);
   daq_device_clear_event(daq_dev, KdxAiOverrun);
   daq_device_clear_event(daq_dev, KdxAiStopped);
   daq_device_clear_event(daq_dev, KdxAiCacheOverflow);

   daq_dev->fai_StopByHw = FALSE;
   daq_dev->PreSglVa = daq_dev->SglStartVa;
   // Register setup ----------------------------------------------
   // Clear A/D control register
   // AdxMemOutW(shared->IoMemBase, DR_EN_AIWORK, 0);

   // Clear device's AD interrupt and FIFO
   // status = AdxMemInW(shared->IoMemBase, DR_INTR_FLAG);
   // AdxMemOutW(shared->IoMemBase, DR_INTR_FLAG, status);


   for (i = 0; i < AI_CHL_COUNT; i++){
      daq_ai_configure_channel(shared, i, shared->AiChanType[i], shared->AiChanGain[i], AI_DMA_DISABLE);
   }

   // Set channel scan range
   {
      startCh = shared->FaiParam.PhyChanStart;
      chanCount = shared->FaiParam.LogChanCount;

      daq_trace((KERN_ALERT"daq_ioctl_fai_start:: Channel Start = %d, Channel Count = %d\n", \
                  shared->FaiParam.PhyChanStart, shared->FaiParam.LogChanCount));

      for (i = 0; i < chanCount; i++) {
         Channel = startCh + i;
         if (Channel > AI_CHL_COUNT){
            Channel = AI_CHL_COUNT;
            break;
         }
         daq_trace((KERN_ALERT"daq_ioctl_fai_start:: AiChanType[%d] = %d, AiChanGain[%d] = %d\n", \
                     Channel, shared->AiChanType[Channel], Channel, shared->AiChanGain[Channel]));
         daq_ai_configure_channel(shared, Channel, shared->AiChanType[i], shared->AiChanGain[i], AI_DMA_ENABLE);
      }

   }


   // Set ConvDiv
   AdxMemOutD(shared->IoMemBase, DR_CONV_DIV, shared->FaiParam.ConvDivide);

   // Set SacnDiv
   AdxMemOutD(shared->IoMemBase, DR_SCAN_DIV, shared->FaiParam.ScanDivide);

   // Set TrigSource
   AdxMemOutW(shared->IoMemBase, DR_TRIG_SOURCE, shared->FaiParam.TrigSource.Value);

   // Set TrigActive
   AdxMemOutW(shared->IoMemBase, DR_TRIG_ACTIVE, shared->FaiParam.TrigActive.Value);

   // Set ScanCount
   // Bionic specifies that "ScanClockSource = SignalNone", instead of "ScanCount = 0", 
   // means "Disable scan clock" in the latest SPEC. ( See bug-10132 in AXA BugZilla)
   // Since our device hardware has been designed as "ScanCount = 0 means disable",
   // we have to do a conversion here: 
   // if ScanClockSource == SignalNone, then set ScanCounter register to 0, but keep
   // the variable ScanCount for display.
   //
   if( shared->FaiParam.TrigSource.ScanClock == AI_CLK_NONE){
      AdxMemOutW( shared->IoMemBase, DR_CONV_COUNTER, 0 );
   }else{      
      AdxMemOutW(shared->IoMemBase, DR_CONV_COUNTER, shared->FaiParam.ScanCount);
   }

   // Set DelayCount
   AdxMemOutD(shared->IoMemBase, DR_TRIG_DELAY_COUNT, shared->FaiParam.DelayCount);

   // Set Hystersis Voltage
   AdxMemOutW(shared->IoMemBase, DR_HYST_VOL, HYSTERSIS_VOLTAGE_VALUE);

   // Set Trig Voltage
   AdxMemOutW(shared->IoMemBase, DR_TRIG_VOL, shared->FaiParam.TriggerSourceLevelBinary);

   //Set MSI model
   if(IS_DEVICE_GROUPED(shared->ProductId, shared->GroupId)){
      msi_model_config(shared);
   }

   // Set interrupt enable bit of mode delay_to_stop
   //#define DEBUG_1706
#ifdef  DEBUG_1706
   unsigned int tmp = 0;
   printk(KERN_ALERT"-----------PCI  1706  CONFIGURATION TABLE--------------\n");
   for (i = 0; i < 0xff; i += 2){
      tmp = AdxMemInW(shared->IoMemBase, i);
      if ((i != 0) && (i % 16) == 0) printk(KERN_ALERT"\n");
      if ((i == 0) || (i % 16) == 0) printk(KERN_ALERT"1706rega Offset: 0d%4x: ", i);	
      printk(KERN_ALERT"1706rega %04x ", tmp);
   }
   printk(KERN_ALERT" ");
   printk(KERN_ALERT"-----------PCI  1706  CONFIGURATION TABLE END--------------\n");
#endif
 
   dev_csr.Value = 0;
   dev_csr.Tri = 0;
   dev_csr.Ent = 1;
   if (shared->FaiParam.XferMode == DAQ_XFER_INT)
   {
      dev_csr.Ent = 1;
   } else {
      if (shared->FaiStatus.AcqMode == DAQ_ACQ_INFINITE) {
         //daq_dev->fai_sgl_end->DescPtr.LastElement = 0;
         daq_dev->fai_sgl.end->DescPtr.LastElement = 0;
      } else {
         //daq_dev->fai_sgl_end->DescPtr.LastElement = 1;
         daq_dev->fai_sgl.end->DescPtr.LastElement = 1;
      }

      //Enable interrupt
      {  
         INT_EN_REG int_enable;
         int_enable.Value = AdxMemInW(shared->IoMemBase, DR_EN_INTR);
         int_enable.Fields.EnFifoAF = 0;
         int_enable.Fields.EnFifoFF = 1;
         int_enable.Fields.EnAiStopByHw = ( DelayToStop == shared->FaiParam.TrigSource.TrigMode );
         AdxMemOutW(shared->IoMemBase, DR_EN_INTR, int_enable.Value);
      }
      {
         PLX_INT_CSR intcsr = {0};
         intcsr.Value = AdxMemInD(shared->BrMemBase,BR_PLX_INTCSR);
         intcsr.LocDMA1IntEn = 1;
         AdxMemOutD(shared->BrMemBase, BR_PLX_INTCSR, intcsr.Value);
      }
      // Clear device's AD interrupt and FIFO
      {
         FIFO_DMARQ_CTL fifo_clr;
         fifo_clr.Clear_FIFO = 1;
         fifo_clr.DMA_Request = 1;
         AdxMemOutW(shared->IoMemBase, DR_FIFO_CONTROL, fifo_clr.Value);
      }
  
      // DMA Channel 1 Descriptor Pointer
      {
         PLX_DMA_DPR dmadpr = {0};
         dmadpr.Value      = daq_dev->fai_sgl.startPA;//virt_to_phys((void *)daq_dev->fai_sgl.pages[0]);
         dmadpr.NextDPRLoc = 1;
         AdxMemOutD(shared->BrMemBase, BR_PLX_DMADPR1, dmadpr.Value);
      }
      //Enable Done interrupt
      {
         PLX_DMA_MODE dmamode = {0};
         dmamode.Value = AdxMemInD(shared->BrMemBase, BR_PLX_DMAMODE1);
         dmamode.DoneIntEn     = 1;
         AdxMemOutD(shared->BrMemBase, BR_PLX_DMAMODE1, dmamode.Value);
      }
      // DMA Channel 1 Command/Status
      // Enable the DMA channel, clear interrupt.
      {
         PLX_DMA_CSR dmacmd  = {0};
         dmacmd.Enable   = 1;
         dmacmd.ClearInt = 1;
         AdxMemOutB(shared->BrMemBase, BR_PLX_DMACSR1, dmacmd.Value);

         dmacmd.Start  = 1;
         AdxMemOutB(shared->BrMemBase, BR_PLX_DMACSR1, dmacmd.Value);
      }
   }

   // start AI acquirement
   // the following lines should be synchronized with interrupt
   spin_lock_irqsave(&daq_dev->fai_lock, flags);
   AdxMemOutW(shared->IoMemBase, DR_EN_AIWORK, 2/*dev_csr.Value*/);
   spin_unlock_irqrestore(&daq_dev->fai_lock, flags);

   // add the task to wait_queue for sync read
   if (shared->FaiStatus.AcqMode == DAQ_ACQ_FINITE_SYNC){
      ret = wait_event_interruptible(daq_dev->fai_queue, shared->FaiStatus.FnState != DAQ_FN_RUNNING);
   }

   return ret;
}

int daq_ioctl_fai_stop(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;

   if (shared->FaiStatus.FnState == DAQ_FN_IDLE){
      return 0;
   }

   daq_dev->fai_StopByHw = FALSE;   

   if (arg & FAI_STOP_FREE_RES){
      daq_fai_cleanup(daq_dev);
   } else {
      daq_fai_stop_acquisition(daq_dev);
   }

   return 0;
}

