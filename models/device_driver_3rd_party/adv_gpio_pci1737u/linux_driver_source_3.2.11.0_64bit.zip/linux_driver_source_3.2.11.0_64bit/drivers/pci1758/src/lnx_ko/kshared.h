/*
 * kshared.h
 *
 *  Created on: 2011-8-30
 *      Author: rocky
 */

#ifndef KERNEL_MODULE_SHARED_H_
#define KERNEL_MODULE_SHARED_H_

#include <linux/types.h>


#define ADVANTECH_VID 0x13fe
#define DEVICE_ID     0x1758
#define DRIVER_NAME   "bio1758"

#define DEVICE_NAME_FROM_PID(pid) \
   (pid == BD_PCI1758UDI ? "PCI-1758UDI" : \
    pid == BD_PCI1758UDO ? "PCI-1758UDO" : "PCI-1758UDIO")

// ----------------------------------------------------------
// H/W feature and structures.
// ----------------------------------------------------------
#define DIO_PORT_MAX          16
#define DIO_CHL_MAX           (DIO_PORT_MAX * 8)
#define DIO_GRP_MAX           (DIO_PORT_MAX / 4)

#define DIO_PORT_COUNT(pid)   (pid == BD_PCI1758UDIO ? 8 : 16)
#define DIO_CHL_COUNT(pid)    (DIO_PORT_COUNT(pid) * 8)

#define DI_PORT_COUNT(pid)    (pid == BD_PCI1758UDO ? 0 : DIO_PORT_COUNT(pid) )
#define DI_CHL_COUNT(pid)     (DI_PORT_COUNT(pid) * 8)

#define DO_PORT_COUNT(pid)    (pid == BD_PCI1758UDI ? 0 : DIO_PORT_COUNT(pid) )

#define DI_GRP_COUNT(pid)     (DI_PORT_COUNT(pid) / 4)
#define DO_GRP_COUNT(pid)     (DO_PORT_COUNT(pid) / 4)

#define DI_SNAP_SRC_COUNT(pid) (DI_PORT_COUNT(pid) * 8)

#define KdxDiBegin            0
#define KdxDiEnd              (KdxDiBegin + 127)
#define KdxWdt                (KdxDiEnd + 1)
#define KdxDevPropChged       (KdxWdt + 1)

#define KrnlSptedEventCount   (KdxDevPropChged + 1)

#define DI_SNAP_SRC_MAX       (KdxDiEnd - KdxDiBegin + 1)

static inline __u32 GetEventKIndex(__u32 pid, __u32 eventid)
{
   __u32 kdx = -1;
   if (eventid == EvtPropertyChanged) {
      kdx = KdxDevPropChged;
   } else if (eventid == EvtReflectWdtOccured) {
      if (pid != BD_PCI1758UDI) {
         kdx = KdxWdt;
      }
   } else {
      __u32 ch = eventid - EvtDiintChannel000;
      if (pid != BD_PCI1758UDO && ch < DIO_CHL_COUNT(pid)) {
         kdx = KdxDiBegin + ch;
      }
   }

   return kdx;
}

// -----------------------------------------------------
// default values
// -----------------------------------------------------
#define DEF_INIT_ON_LOAD        1

// DIO default values
#define DEF_DIINT_RISING        0xffff
#define DEF_DIINT_FALLING       0

#define DEF_DIFLT_TIME          0            // disabled
#define DEF_DIFLT_EN            0

#define DEF_WDT_INTERVAL        0xffffffff
#define DEF_WDT_LOCKVAL         0

#define DEF_DO_STATE            0

// ----------------------------------------------------------
// Device private data
// ----------------------------------------------------------
typedef struct _DI_SNAP_CONFIG
{
   __u8 PortStart;
   __u8 PortCount;
} DI_SNAP_CONFIG;

typedef struct _DI_SNAP_STATE
{
   __u32 State[DIO_GRP_MAX];
} DI_SNAP_STATE;

typedef struct _DEVICE_SHARED
{
   __u32       Size;           // Size of the structure
   __u32       ProductId;      // Device Type
   __u32       DeviceNumber;   // Zero-based device number

   // HW Information
   __u32       BoardId;        // Board dip switch number for the device
   __u32       BusNumber;      // PCI Bus number
   __u32       SlotNumber;     // PCI Slot number
   __u32       IoBase;
   __u32       IoLength;
   __u32       FlashBase;
   __u32       FlashLength;
   __u32       Irq;
   __u32       InitOnLoad;

   // --------------------------------------------------------
   __u32          DiFilterTime;
   __u32          DiFilterEn[DIO_GRP_MAX];
   __u16          DiRisingEdgeEn[DIO_PORT_MAX / 2];
   __u16          DiFallingEdgeEn[DIO_PORT_MAX / 2];
   DI_SNAP_CONFIG DiSnapParam[DI_SNAP_SRC_MAX];
   DI_SNAP_STATE  DiSnapState[DI_SNAP_SRC_MAX];

   __u32          WdtInterval;
   __u32          WdtLockValue[DIO_GRP_MAX];
   __u32          DoPortState[DIO_GRP_MAX];

   // ---------------------------------------------------------
   __u32          WdtIntState;
   __u32          DiIntState[DIO_GRP_MAX];
   __u32          IsEvtSignaled[(KrnlSptedEventCount + 31) / 32];

} DEVICE_SHARED;

#endif /* KERNEL_MODULE_SHARED_H_ */
