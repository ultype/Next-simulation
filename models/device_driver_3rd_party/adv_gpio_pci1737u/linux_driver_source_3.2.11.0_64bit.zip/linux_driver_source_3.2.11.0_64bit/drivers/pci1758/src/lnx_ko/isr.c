/*
 * isr.c
 *
 *  Created on: Nov 29, 2011
 *      Author: rocky
 */
#include "kdriver.h"
#include "hw.h"

// -----------------------------------------------------------------------------
// Must hold the lock when call this function.
static
void daq_di_int_update_state(daq_device_t *daq_dev)
{
   DEVICE_SHARED *shared  = &daq_dev->shared;
   DREG_TABLE    *table;
   unsigned long flags;

   __u32  intState[MAX_DIO_PORT_COUNT / 4];
   __u32  *snapped_data = NULL;
   int    group, offset, ch, i;
   int    group_count = DI_PORT_COUNT(shared->ProductId) / 4;

   table  = GetDeviceRegTable(shared->ProductId);

   // Copy the interrupt state to local cache to avoid impose the interrupt handler.
   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   for (group = 0; group < group_count; ++group) {
      intState[group] = shared->DiIntState[group];
      shared->DiIntState[group] = 0;
   }
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

   // check interrupt state
   for (group = 0; group < group_count; ++group) {

      for (offset = 0; intState[group]; ++offset, intState[group] >>= 1) {

         if (!(intState[group] & 0x1)) {
            continue;
         }

         // The channel assert DI interrupt
         // snap DI data
         ch = group * 32 + offset;

         if (shared->DiSnapParam[ch].PortCount) {
            if (!snapped_data) {
               snapped_data = shared->DiSnapState[ch].State;
               for (i = 0; i < group_count; ++i) {
                  snapped_data[i] = AdxIoInD(shared->IoBase, table->DI_BASE + i * 4);
               }
            } else {
               for (i = 0; i < group_count; ++i) {
                  shared->DiSnapState[ch].State[i] = snapped_data[i];
               }
            }
         }

         // signal the event if needed.
         if (!(shared->IsEvtSignaled[group] & (0x1 << offset))) {
            shared->IsEvtSignaled[group] |= 0x1 << offset;
            daq_device_signal_event(daq_dev, ch + KdxDiBegin);
         }
      }
   }
}

void daq_dio_tasklet_func(unsigned long arg)
{
   daq_device_t  *daq_dev = (daq_device_t *) arg;

   // check DI interrupt
   if (daq_dev->shared.ProductId != BD_PCI1758UDO) {
      daq_di_int_update_state(daq_dev);
   }

   // check watchdog interrupt
   if (daq_dev->shared.ProductId != BD_PCI1758UDI) {
      __u32 wdt_stat = daq_dev->shared.WdtIntState;
      if (wdt_stat & WDT_TIMEOUT){
         if (!(daq_dev->shared.IsEvtSignaled[KdxWdt / 31] & (0x1 << (KdxWdt & 31)))){
            daq_dev->shared.IsEvtSignaled[KdxWdt / 31] |= 0x1 << (KdxWdt & 31);
            daq_device_signal_event(daq_dev, KdxWdt);
         }
      }
   }
}

irqreturn_t daq_irq_handler(int irq, void *dev_id)
{
   daq_device_t  *daq_dev = (daq_device_t *) dev_id;
   DEVICE_SHARED *shared  = &daq_dev->shared;
   DREG_TABLE    *table   = GetDeviceRegTable(shared->ProductId);
   int           i, int_occur= 0;

   // Detect DI interrupt
   if (table->DI_INT_IDENTIFY != -1) {
      __u32 port_ident = AdxIoInW(shared->IoBase, table->DI_INT_IDENTIFY);

      int_occur = port_ident != 0;

      spin_lock(&daq_dev->dev_lock);
      for (i = 0; port_ident; ++i, port_ident >>= 4) {
         if (port_ident & 0xf) {
            shared->DiIntState[i] |= AdxIoInD(shared->IoBase, table->DI_INT_STA_BASE + i * 4);
            AdxIoOutD(shared->IoBase, table->DI_INT_STA_BASE + i * 4, shared->DiIntState[i]);
         }
      }
      spin_unlock(&daq_dev->dev_lock);
   }

   // Detech watchdog interrupt
   if (table->WDT_CTL_STA != -1) {
      __u32 wdt_stat = AdxIoInW(shared->IoBase, table->WDT_CTL_STA);
      if ((wdt_stat & WDT_INT_EN) && (wdt_stat & WDT_TIMEOUT)) {
         int_occur = 1;
         shared->WdtIntState = wdt_stat;

         AdxIoOutW(shared->IoBase, table->WDT_CTL_STA, wdt_stat & ~WDT_INT_EN);
         AdxIoOutW(shared->IoBase, table->WDT_CTL_STA, wdt_stat);
      }
   }

   if (!int_occur) {
      return IRQ_RETVAL(0);
   }

   tasklet_schedule(&daq_dev->dio_tasklet);
   return IRQ_RETVAL(1);
}
