/*
 * dio.c
 *
 * Created on: October 7, 2012
 * Author: 
 */
#include "kdriver.h"
#include "hw.h"

//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------

void daq_dio_initialize_hw(daq_device_t *daq_dev)
{
   DEVICE_SHARED *shared = &daq_dev->shared;

   DIO_CSR ctl;
   ctl.Value = shared->DoConfig;

   if (shared->InitOnLoad) {
      ctl.Do = shared->DoState[0];
   } else {
      ctl.Do = AdxIoInD(shared->IoBase, DR_DIO_CSR);
   }
   AdxIoOutD(shared->IoBase, DR_DIO_CSR, ctl.Value);
}

int daq_ioctl_di_read_port(daq_device_t *daq_dev, unsigned long arg)
{
   DIO_RW_PORTS xbuf;
   __u8         data[DIO_PORT_COUNT];

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   xbuf.PortStart %= DIO_PORT_COUNT;
   xbuf.PortCount  = x_min((unsigned)DIO_PORT_COUNT, xbuf.PortCount);

   data[0] = AdxIoInW(daq_dev->shared.IoBase, DR_DIO_CSR) >> 4;
   data[0] ^= daq_dev->shared.DiInverse[0];

   if (unlikely(copy_to_user(xbuf.Data, data, xbuf.PortCount))){
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_do_write_port(daq_device_t *daq_dev, unsigned long arg)
{
   DIO_RW_PORTS xbuf;
   __u8         data[DIO_PORT_COUNT];

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   xbuf.PortStart %= DIO_PORT_COUNT;
   xbuf.PortCount  = x_min((unsigned)DIO_PORT_COUNT, xbuf.PortCount);
   if (unlikely(copy_from_user(data, (void *)xbuf.Data, xbuf.PortCount))){
      return -EFAULT;
   }

   AdxIoOutW(daq_dev->shared.IoBase, DR_DIO_CSR, data[0]);

   return 0;
}

int daq_ioctl_do_write_bit(daq_device_t *daq_dev, unsigned long arg)
{
   DIO_RW_BIT xbuf;
   __u16      status;
   unsigned long flags;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }
   if (xbuf.Port >= DIO_PORT_COUNT || xbuf.Bit >= 8) {
      return -EINVAL;
   }

   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   status  = AdxIoInW(daq_dev->shared.IoBase, DR_DIO_CSR) & 0xF;
   status &= ~(1 << xbuf.Bit);
   status |= (xbuf.Data & 0x1) << xbuf.Bit;
   AdxIoOutW(daq_dev->shared.IoBase, DR_DIO_CSR, status);
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
   
   return 0;
}

int daq_ioctl_do_read_port(daq_device_t *daq_dev, unsigned long arg)
{
   DIO_RW_PORTS xbuf;
   __u8         data[DIO_PORT_COUNT];

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   xbuf.PortStart %= DIO_PORT_COUNT;
   xbuf.PortCount  = x_min((unsigned)DIO_PORT_COUNT, xbuf.PortCount);
   data[0] = AdxIoInW(daq_dev->shared.IoBase, DR_DIO_CSR) & 0xF;

   if (unlikely(copy_to_user(xbuf.Data, data, xbuf.PortCount))){
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_diint_set_param(daq_device_t *daq_dev, unsigned long arg)
{
   DIO_SET_DIINT_CFG xbuf;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))) {
      return -EFAULT;
   }

   if (xbuf.SrcStart + xbuf.SrcCount > DIO_PORT_COUNT) {
      return -EINVAL;
   }  

   return 0;
}

int daq_ioctl_di_start_snap(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED     *shared = &daq_dev->shared;
   DIO_START_DI_SNAP xbuf;
   unsigned          event_kdx, src_idx;
   unsigned long     flags;


   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))) {
      return -EFAULT;
   }

   event_kdx = GetEventKIndex(xbuf.EventId);
   src_idx   = event_kdx - KdxDiBegin;
   if (src_idx >= DI_SNAP_SRC_COUNT) {
      return -EINVAL;
   }

   daq_device_clear_event(daq_dev, event_kdx);
   shared->IsEvtSignaled[event_kdx] = 0;
   shared->DiSnap[src_idx].Start = (__u8)xbuf.PortStart;
   shared->DiSnap[src_idx].Count = (__u8)xbuf.PortCount;

   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   {
      daq_dev->IntrCtl.DI   |= 1 << src_idx;
      daq_dev->IntrCtl.Intr  = 1;
      AdxIoOutD(shared->IoBase, DR_INTR_CSR, daq_dev->IntrCtl.Value);
   }
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

   return 0;
}

int daq_ioctl_di_stop_snap(daq_device_t *daq_dev, unsigned long arg)
{
   unsigned      event_kdx, src_idx;
   unsigned long flags;

   event_kdx = GetEventKIndex((__u32)arg);
   src_idx   = event_kdx - KdxDiBegin;
   if (src_idx >= DI_SNAP_SRC_COUNT) {
      return -EINVAL;
   }

   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   if (daq_dev->shared.CntrSnap[KdxCntDiLatch0 - KdxCntBegin + src_idx].RefCount == 0) {
      daq_dev->IntrCtl.DI = daq_dev->IntrCtl.DI & (~(1 << src_idx));

      // No interrupt source is active.
      if ((daq_dev->IntrCtl.Value << 1) == 0) { 
         daq_dev->IntrCtl.Intr = 0;
      }

      AdxIoOutD(daq_dev->shared.IoBase, DR_INTR_CSR, daq_dev->IntrCtl.Value);
   }
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

   return 0;
}

