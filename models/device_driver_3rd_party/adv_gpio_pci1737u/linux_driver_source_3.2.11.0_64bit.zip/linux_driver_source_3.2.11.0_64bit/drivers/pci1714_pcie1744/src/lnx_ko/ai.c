/*
 * ai.c
 *
 *  Created on: 2011-11-10
 *      Author: rocky
 */

#include "kdriver.h"
#include "hw.h"

#define  AI_LOAD_CALI_MAX_WAIT_US 10000
#define  AI_CH_CHGED_MAX_WAIT_US  1000
#define  NO_HW_CHECK              0xffffffff

static __u64 daq_get_time_epoch_us(void)
{
   struct timeval tv;
   do_gettimeofday(&tv);
   return ((uint64)tv.tv_sec) * 1000 * 1000 + tv.tv_usec;
}

static 
int daq_ai_wait_status_ready(DEVICE_SHARED *shared, __u32 offset, __u32 mask, __u32 timeout)
{
   __u64 now, end;
   
   end = daq_get_time_epoch_us() + timeout;
   do {
      if (offset != NO_HW_CHECK) {
          if (AdxIoInW(shared->IoBase, offset) & mask) {
             return 1;
          }
      }
  
      now = daq_get_time_epoch_us();   
   } while (time_before64(now, end));
   
   return 0;
}

static
void daq_ai_update_hw_chan_ctl(DEVICE_SHARED *shared)
{
   AdxIoOutW(shared->IoBase, DR_AI_CHCTL, shared->AiChanCtl);
   daq_ai_wait_status_ready(shared, DR_CALI_CMD, CALI_BUSY_MASK, AI_LOAD_CALI_MAX_WAIT_US);
   daq_ai_wait_status_ready(shared, NO_HW_CHECK, 0, AI_CH_CHGED_MAX_WAIT_US);
}

static
int daq_ai_configure_channel(DEVICE_SHARED *shared, __u32 chan, __u8 sctype, __u8 gain)
{
   shared->AiChanType[chan] = sctype;
   shared->AiChanGain[chan] = gain;

   shared->AiChanCtl &= ~AI_CHCTL_GAIN_MASK(chan);
   shared->AiChanCtl |= AI_CHCTL_GAIN(chan, gain);
   
   /*AdxIoOutW(shared->IoBase, DR_AI_CHCTL, shared->AiChanCtl);*/

   return 0;
}

static
__u32 daq_ai_read_channel(DEVICE_SHARED *shared, __u32 chan, unsigned timeout)
{
   unsigned long absolute_timeout;
   __u32         fifo_state;
   __u32         fifo_empty = AI_FIFO_EMPTY(chan);

   // Trigger a A/D conversion.
   AdxIoOutW(shared->IoBase, DR_AI_CHAN(chan), 1);

   // use time-out detecting.
   absolute_timeout = jiffies + msecs_to_jiffies(timeout);

   // waiting for data ready
   do {
      fifo_state = AdxIoInD(shared->IoBase, DR_AI_FIFOCSR);
      if (!(fifo_state & fifo_empty)){
         break;
      }
      if (time_is_before_jiffies(absolute_timeout)){
         daq_trace((KERN_ERR "read ai time-out."));
         return -1;
      }
   }while (1);

   return AdxIoInW(shared->IoBase, DR_AI_CHAN(chan));
}

static
void daq_ai_flush_fifo(daq_device_t *daq_dev)
{
   FAI_STATUS *faiStatus = &daq_dev->shared.FaiStatus;
   FAI_CONFIG *faiParam  = &daq_dev->shared.FaiParam;

   __u16 *userBuffer = (__u16*)daq_dev->fai_buffer.kaddr;
   __u16 *ptr;
   __u16 *endPtr;

   __u32 trigCount = faiParam->TrigDelayCount * faiParam->LogChanCount;
   __u32 trigIndex;
   __u32 lastIndex;
   __u32 leftCount;

   if (trigCount > faiParam->SampleCount) {
      trigCount = faiParam->SampleCount;
   }

   if (userBuffer[faiStatus->WritePos] >= 0x8000) {
      ptr    = &userBuffer[faiStatus->WritePos];
      endPtr = userBuffer;

      for (; ptr > endPtr && *ptr >= 0x8000; --ptr) {
         ;
      }
      trigIndex = (__u32)(ptr - userBuffer);
      if (*ptr < 0x8000) {
         ++trigIndex;
      }

      if (trigIndex == 0 && userBuffer[0] >= 0x8000) {
         ptr = &userBuffer[faiParam->SampleCount - 1];

         if (*ptr >= 0x8000) {
            endPtr = &userBuffer[faiStatus->WritePos];

            for (; ptr > endPtr && *ptr >= 0x8000; --ptr) {
               ;
            }
            trigIndex = (__u32)(ptr - userBuffer);
            if (*ptr < 0x8000) {
               ++trigIndex;
            }
            if (trigIndex == faiStatus->WritePos) {
               trigIndex = 0;
            }
         }
      }
   } else {
      ptr    = &userBuffer[faiStatus->WritePos];
      endPtr = userBuffer + faiParam->SampleCount;

      for (; ptr < endPtr && *ptr < 0x8000; ++ptr) { }
      trigIndex = (__u32)(ptr - userBuffer);

      if (trigIndex == faiParam->SampleCount
         && userBuffer[faiParam->SampleCount - 1] < 0x8000) {
         ptr    = userBuffer;
         endPtr = &userBuffer[faiStatus->WritePos];

         for (; ptr < endPtr && *ptr < 0x8000; ++ptr) {
            ;
         }
         trigIndex = (__u32)(ptr - userBuffer);
      }
      if (trigIndex == faiStatus->WritePos) {
         trigIndex = 0;
      }
   }

   lastIndex  = trigIndex + trigCount;
   lastIndex %= faiParam->SampleCount;
   ptr        = &userBuffer[lastIndex];
   if (lastIndex < trigCount) {
      endPtr = userBuffer;

      for (; ptr > endPtr && *ptr < 0x8000; --ptr) {
         ;
      }
      lastIndex = (__u32)(ptr - userBuffer);
      if (*endPtr >= 0x8000) {
         ++lastIndex;
      }

      if (userBuffer[faiParam->SampleCount - 1] < 0x8000) {
         ptr = &userBuffer[faiParam->SampleCount - 1];
         endPtr = &userBuffer[trigIndex];

         for (; ptr > endPtr && *ptr < 0x8000; --ptr) {
            ;
         }
         lastIndex = (__u32)(ptr - userBuffer);
      }
   } else {
      endPtr = &userBuffer[trigIndex];

      for (; ptr > endPtr && *ptr < 0x8000; --ptr) {
         ;
      }
      lastIndex = (__u32)(ptr - userBuffer);
      if (lastIndex == trigCount) {
         lastIndex = 0;
      } else {
         if (*endPtr >= 0x8000) {
            ++lastIndex;
         }
      }
   }

   if (trigIndex == lastIndex && userBuffer[0] >= 0x8000) {
      leftCount = 0;
   } else {
      __u32 count = (lastIndex - trigIndex + faiParam->SampleCount) % faiParam->SampleCount;
      leftCount = (count >= trigCount) ? 0 : (trigCount - count);
   }

   {
      __u32 fifoEmptyMask = AI_FIFO_EMPTY(0) | AI_FIFO_EMPTY(1) | AI_FIFO_EMPTY(2) | AI_FIFO_EMPTY(3);
      __u32 fifoState = AdxIoInD(daq_dev->shared.IoBase, DR_AI_FIFOCSR);

      if ((fifoState & fifoEmptyMask) == fifoEmptyMask) {
         faiStatus->WritePos = lastIndex;
         return;
      }
   }

   {
      __u32 chan, i, j;
      for (j = leftCount / faiParam->LogChanCount; j > 0; --j) {
         for (i = 0; i < faiParam->LogChanCount; ++i) {
            chan = (faiParam->PhyChanStart + i) % AI_CHL_COUNT;
            userBuffer[lastIndex] = AdxIoInW(daq_dev->shared.IoBase, DR_AI_CHAN(chan));
            lastIndex = (lastIndex + 1) % faiParam->SampleCount;
         }
      }
   }

   faiStatus->WritePos = lastIndex;
}

static
void daq_fai_setup_pacer(DEVICE_SHARED *shared)
{
   AI_CLK_CTL clk_ctl = {0};
   clk_ctl.Source = AI_CLK_OFF;
   AdxIoOutW(shared->IoBase, DR_AI_CLKCTL, clk_ctl.Value);

   if (shared->FaiParam.ConvClkSource == SigInternalClock) {
      clk_ctl.Divider = shared->FaiParam.PacerDivider;
      clk_ctl.Source  = AI_CLK_INTERNAL;
   } else {
      clk_ctl.Divider = 1;
      if (shared->FaiParam.ConvClkSource == SigExtAnaClock) {
         clk_ctl.Source = AI_CLK_EXTANA;
      } else {
         clk_ctl.Source = AI_CLK_EXTDIG;
      }
   }

   AdxIoOutW(shared->IoBase, DR_AI_CLKCTL, clk_ctl.Value);
}

static
int daq_fai_start_hardware(daq_device_t *daq_dev)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   FAI_CONFIG  *faiParam = &shared->FaiParam;
   FAI_STATUS *faiStatus = &shared->FaiStatus;
   AI_TRIG_CSR trig_ctl  = {0};

   // Disable device interrupt
   AdxIoOutW(shared->IoBase, DR_DEV_INTCSR, 0);

   // Clear FIFO
   AdxIoOutD(shared->IoBase, DR_AI_FIFOCSR, AI_FIFO_CLRALL | AI_FIFO_RSTALL);
   AdxIoOutW(shared->IoBase, DR_DEV_INTCLR, 0);

   // pacer trigger
   daq_fai_setup_pacer(shared);

   if (faiParam->LogChanCount == 4) {
      AdxIoOutW(shared->IoBase, DR_DMA_XFERRST, 0);
   }

   if (faiParam->PhyChanStart == 0) {
      AdxIoOutW(shared->IoBase, DR_DMA_DREQSEL, 0);
   } else {
      AdxIoOutW(shared->IoBase, DR_DMA_DREQSEL, 1);
   }

   if (faiParam->TrigSource != SignalNone) {
      AdxIoOutW(shared->IoBase, DR_AI_DMACNTR_RST, 0);
   }

   {
      trig_ctl.DmaTCFlag = 1;
      trig_ctl.TrigFlag  = 1;
      trig_ctl.TrigEdge  = faiParam->TrigEdge == RisingEdge ? 0 : 1;
      trig_ctl.TrigSrc   = AI_TRIGSRC_DIGITAL;
      AdxIoOutW(shared->IoBase, DR_AI_TRIGCSR, trig_ctl.Value);

      if (faiParam->TrigSource != SignalNone && faiParam->TrigAction != ActionNone) {
         if (faiParam->TrigSource != SigExtDigTrigger0) {
            trig_ctl.TrigSrc = AI_TRIGSRC_AICHAN(faiParam->TrigSource - SigAi0);
         } 
         AdxIoOutW(shared->IoBase, DR_AI_TRIGCSR, trig_ctl.Value);

         if ( faiParam->TrigAction == DelayToStart ) {
            trig_ctl.TrigMode = faiParam->TrigDelayCount == 0 ? AI_TRIGMODE_POST : AI_TRIGMODE_DELAY;
         } else {
            trig_ctl.TrigMode = AI_TRIGMODE_ABOUT;
         }
      } else {
         trig_ctl.TrigMode = AI_TRIGMODE_PACER;
      }

      if (trig_ctl.TrigMode == AI_TRIGMODE_ABOUT) {
         AdxIoOutW(shared->IoBase, DR_DEV_INTCSR, DEV_INT_DMATERMCOUNT | DEV_INT_ENABLED);
      } else {
         AdxIoOutW(shared->IoBase, DR_DEV_INTCSR, 0);
      }

      AdxIoOutW(shared->IoBase, DR_AI_TRIGVOLT, faiParam->TrigLevelBin);
      AdxIoOutW(shared->IoBase, DR_AI_DMACNTR,  faiParam->TrigDelayCount);
   }

   // Program the FIFO
   {
      int i = 0;
      for (; i < 4; ++i) {
         AdxIoOutW(shared->IoBase, DR_AI_FIFOPROG(i), 8);
         AdxIoOutW(shared->IoBase, DR_AI_FIFOPROG(i), 1);
      }
   }

   // PLX9056 register setup ---------------------------------------
   {
      // reset the DMA terminated flag of about trigger
      faiStatus->DmaTCFlag = 0;

      if ( faiStatus->AcqMode == DAQ_ACQ_INFINITE ) {
         daq_dev->fai_sgl.end->DescPtr.LastElement = 0;
      } else {
         daq_dev->fai_sgl.end->DescPtr.LastElement = 1;
      }

      // Local Address Space 0 Local Base Address
      // Enable Local address space 0, base address 0
      {
         PLX_LAS0_BA las0ba = {0};
         las0ba.Spc0En  = 1;
         AdxIoOutW(shared->BrBase, BR_PLX_LAS0BA, las0ba.Value);
      }

      // Mode/DMA Arbitration
      // Local Bus BREQ Enable, Local Bus Direct Slave Release Bus Mode
      {
         PLX_MOD_DMA_ARB marbr  = {0};
         marbr.LocBusBREQEn = 1;
         marbr.LocBusDSRBM  = 1;
         AdxIoOutD(shared->BrBase, BR_PLX_MODDMAARB, marbr.Value);
      }

      // Local Address Space 0/Expansion ROM Bus Region Descriptor
      // 32bit local bus width, 1 internal wait state
      {
         PLX_LAS0_BUS_RGN_DPR lbrd = {0};
         lbrd.MemSpc0LBWidth   = 3;
         lbrd.MemSpc0WaitState = 1;
         AdxIoOutW(shared->BrBase, BR_PLX_LAS0BUSRGNDPR, lbrd.Value);
      }

      // DMA Threshold
      // zero for all field.
      AdxIoOutW(shared->BrBase, BR_PLX_DMATHR, 0);

      // DMA DAC: zero it
      AdxIoOutD(shared->BrBase, BR_PLX_DMADAC0, 0);

      // Interrupt Control / Status register
      // PCI Interrupt Enable, Local DMA Channel 0 Interrupt Enable.
      {
         PLX_INT_CSR intcsr = {0};
         intcsr.PciIntEn     = 1;
         intcsr.LocDMA0IntEn = 1;
         if ((faiParam->TrigAction == DelayToStop)
            && (faiParam->TrigSource != SignalNone)) {
               intcsr.LocIntInputEn = 1;
         }
         AdxIoOutD(shared->BrBase, BR_PLX_INTCSR, intcsr.Value);
      }

      // DMA Channel 0 Mode
      // Local bus width : 16Bit, Internal wait state: 3
      // Local Burst Enable, Scatter/Gather Mode, Done Interrupt Enable,
      // Local Addressing Mode 1 ( holds the Local Address bus constant),
      // Demand Mode, DMA Channel 0 Interrupt Select.
      {
         PLX_DMA_MODE dmamode  = {0};
         dmamode.LocBusWidth   = shared->FaiParam.LogChanCount > 1 ? 3 : 1;
         dmamode.IntlWaitState = 1;
         dmamode.LocBurstEn    = 1;
         dmamode.SGModeEn      = 1;
         dmamode.LocAddrMode   = 1;
         dmamode.DemandModeEn  = 1;
         dmamode.DmaIntSelect  = 1;
         dmamode.DacChainLoad  = 0;
         AdxIoOutD(shared->BrBase, BR_PLX_DMAMODE0, dmamode.Value);
      }

      // DMA Channel 0 Descriptor Pointer
      {
         PLX_DMA_DPR dmadpr = {0};
         dmadpr.Value       = daq_dev->fai_sgl.startPA;
         dmadpr.NextDPRLoc  = 1;
         AdxIoOutD(shared->BrBase, BR_PLX_DMADPR0, dmadpr.Value);
      }
   }

   // start AI acquisition
   {
      __u32 ch_enabled = ((1 << faiParam->LogChanCount) - 1) << faiParam->PhyChanStart;
      AdxIoOutW(shared->IoBase, DR_AI_CONVEN, ch_enabled);
      AdxIoOutD(shared->IoBase, DR_AI_FIFOCSR, AI_FIFO_CLRALL);
   }

   // DMA Channel 0 Command/Status
   // Enable the DMA channel, clear interrupt.
   {
      PLX_DMA_CSR dmacmd = {0};
      dmacmd.Enable   = 1;
      dmacmd.ClearInt = 1;
      dmacmd.Start    = 1;
      AdxIoOutB(shared->BrBase, BR_PLX_DMACSR0, dmacmd.Value);
   }

   // fix bug#10259: we must write the trigger control register at the end of function. 
   AdxIoOutW(shared->IoBase, DR_AI_TRIGCSR,  trig_ctl.Value );

   // add the task to wait_queue for sync read
   if (faiStatus->AcqMode == DAQ_ACQ_FINITE_SYNC){
      return wait_event_interruptible(daq_dev->fai_queue, faiStatus->FnState != DAQ_FN_RUNNING);
   }

   return 0;
}

//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------
void daq_ai_initialize_hw(daq_device_t *daq_dev)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   int i;

   AdxIoOutW(shared->IoBase, DR_AI_CONVEN, 0);

   for (i = 0; i < AI_CHL_COUNT; ++i) {
      daq_ai_configure_channel(shared, i, shared->AiChanType[i], shared->AiChanGain[i]);
   }
   
   daq_ai_update_hw_chan_ctl(shared);
   
   shared->AiLogChanCount = daq_ai_calc_log_chan_count(shared->AiChanType, AI_CHL_COUNT);
   
   // 
   AdxIoOutW(shared->IoBase, DR_AI_FIFOPROG(0), 8);
   AdxIoOutW(shared->IoBase, DR_AI_FIFOPROG(0), 1);
   AdxIoOutW(shared->IoBase, DR_AI_FIFOPROG(1), 8);
   AdxIoOutW(shared->IoBase, DR_AI_FIFOPROG(1), 1);
   AdxIoOutW(shared->IoBase, DR_AI_FIFOPROG(2), 8);
   AdxIoOutW(shared->IoBase, DR_AI_FIFOPROG(2), 1);
   AdxIoOutW(shared->IoBase, DR_AI_FIFOPROG(3), 8);
   AdxIoOutW(shared->IoBase, DR_AI_FIFOPROG(3), 1);
   
}

void daq_fai_stop_acquisition(daq_device_t *daq_dev, int cleanup)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   FAI_CONFIG  *faiParam = &shared->FaiParam;
   FAI_STATUS *faiStatus = &shared->FaiStatus;

   unsigned long flags;

   spin_lock_irqsave(&daq_dev->fai_lock, flags);
   if (faiStatus->FnState != DAQ_FN_RUNNING) {
      spin_unlock_irqrestore(&daq_dev->fai_lock, flags);
   } else {
      faiStatus->FnState = DAQ_FN_STOPPED;
      spin_unlock_irqrestore(&daq_dev->fai_lock, flags);
     
      AdxIoOutW(shared->IoBase, DR_AI_CONVEN, 0);
      AdxIoOutW(shared->IoBase, DR_DEV_INTCSR, 0);
     
     {
         AI_TRIG_CSR trig_csr;
         trig_csr.TrigMode = AI_TRIGMODE_SW;
         trig_csr.DmaTCFlag= 1;
         trig_csr.TrigFlag = 1;
         AdxIoOutW(shared->IoBase, DR_AI_TRIGCSR, trig_csr.Value);
      }

      if (faiParam->XferMode == DAQ_XFER_DMA) {
         PLX_DMA_CSR dmacsr;
         dmacsr.Value = AdxIoInB(shared->BrBase, BR_PLX_DMACSR0);
         while (!dmacsr.Done) {
            dmacsr.Abort = 1;
            AdxIoOutB(shared->BrBase, BR_PLX_DMACSR0, dmacsr.Value);
            dmacsr.Value = AdxIoInB(shared->BrBase, BR_PLX_DMACSR0);
         }
      }

      if (faiStatus->DmaTCFlag) {
         daq_ai_flush_fifo(daq_dev);
      }

      if (faiParam->TrigSource != SignalNone && faiParam->TrigAction == DelayToStop) {
         __u32 availDataStart;
         if (faiStatus->WPRunBack) {
            availDataStart = faiStatus->WritePos;
         } else {
            availDataStart = 0;
         }
         if (faiStatus->ReadPos <= availDataStart) {
            faiStatus->ReadPos = availDataStart;
         }
      }

      daq_device_signal_event(daq_dev, KdxAiStopped);
      wake_up_interruptible(&daq_dev->fai_queue);
   }

   if (cleanup) {
      daq_umem_free(&daq_dev->fai_buffer);
      daq_plx905x_free_sgl_mem(&daq_dev->fai_sgl);

      spin_lock_irqsave(&daq_dev->fai_lock, flags);
      faiStatus->FnState = DAQ_FN_IDLE;
      spin_unlock_irqrestore(&daq_dev->fai_lock, flags);
   }
   
   AdxIoOutD(shared->BrBase, BR_PLX_INTCSR, 0);
}

int daq_ioctl_ai_set_channel(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   AI_SET_CHAN   xbuf;
   AI_CHAN_CFG   cfg[AI_CHL_COUNT];
   __u32         i, ch;

   if (unlikely(shared->FaiStatus.FnState == DAQ_FN_RUNNING)){
      return -EBUSY;
   }

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   if (unlikely(xbuf.PhyChanCount > AI_CHL_COUNT)){
      xbuf.PhyChanCount = AI_CHL_COUNT;
   }
   if (unlikely(copy_from_user(cfg, (void *)xbuf.ChanCfg, sizeof(AI_CHAN_CFG) * xbuf.PhyChanCount))){
      return -EFAULT;
   }

   AdxIoOutW(shared->IoBase, DR_AI_CONVEN, 0);

   for (i = 0; i < xbuf.PhyChanCount; ++i) {
      ch = (xbuf.PhyChanStart + i) & AI_CHL_MASK;
      daq_ai_configure_channel(shared, ch, cfg[i].SCType, cfg[i].Gain);
   }

   daq_ai_update_hw_chan_ctl(shared);
   
   shared->AiLogChanCount = daq_ai_calc_log_chan_count(shared->AiChanType, AI_CHL_COUNT);

   return 0;
}

int daq_ioctl_ai_read_sample(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED   *shared = &daq_dev->shared;
   AI_READ_SAMPLES xbuf;
   __u16           sample[AI_CHL_COUNT];
   __u16           *data_ptr;
   __u32           result;

   if (unlikely(daq_dev->shared.FaiStatus.FnState == DAQ_FN_RUNNING)){
      return -EBUSY;
   }

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   xbuf.PhyChanStart &= AI_CHL_MASK;
   xbuf.LogChanCount =  x_min(xbuf.LogChanCount, shared->AiLogChanCount);

   // configure hardware
   AdxIoOutW(shared->IoBase, DR_DEV_INTCLR, 0);
   AdxIoOutW(shared->IoBase, DR_AI_TRIGCSR, AI_TRIGMODE_SW);

   {
      __u32 i, ch, fifo_ctl = 0, ch_range = 0;
      for (i = 0; i < xbuf.LogChanCount; ++i) {
          ch = (xbuf.PhyChanStart + i) & AI_CHL_MASK;
          fifo_ctl |= AI_FIFO_CLR(ch);
          ch_range |= 1 << ch;
      }

      AdxIoOutD(shared->IoBase, DR_AI_FIFOCSR, fifo_ctl);
      AdxIoOutW(shared->IoBase, DR_AI_CONVEN, ch_range);
   }

   // Read samples
   for(data_ptr = sample; data_ptr < sample + xbuf.LogChanCount; ++data_ptr){
      result = daq_ai_read_channel(shared, xbuf.PhyChanStart, SAI_TIMEOUT_VAL);
      if (result == -1){
         return -EIO;
      }
      *data_ptr = (__u16)result;
      xbuf.PhyChanStart = (xbuf.PhyChanStart + 1) & AI_CHL_MASK;
   }

   if (unlikely(copy_to_user((void *)xbuf.Data, sample, xbuf.LogChanCount * sizeof(__u16)))) {
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_fai_set_param(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   FAI_CONFIG    xbuf;
   unsigned long flags;
   int           ret = 0;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   spin_lock_irqsave(&daq_dev->fai_lock, flags);
   if (unlikely(shared->FaiStatus.FnState != DAQ_FN_IDLE)){
      ret = -EBUSY;
   } else {
      shared->FaiParam              = xbuf;
      shared->FaiParam.PhyChanStart = xbuf.PhyChanStart & AI_CHL_MASK;
      shared->FaiParam.LogChanCount = x_min(xbuf.LogChanCount, shared->AiLogChanCount);
   }
   spin_unlock_irqrestore(&daq_dev->fai_lock, flags);

   if (likely(!ret)){
      daq_device_signal_event(daq_dev, KdxDevPropChged);
   }

   return ret;
}

int daq_ioctl_fai_set_buffer(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   FAI_CONFIG  *faiParam = &shared->FaiParam;
   FAI_STATUS *faiStatus = &shared->FaiStatus;

   unsigned long flags;
   unsigned      sgl_len, data_len, sect_len;
   int           ret = 0;
   __u32         dev_loc_addr;

   if (unlikely(!faiParam->SampleCount)) {
      return -EINVAL;
   }

   spin_lock_irqsave(&daq_dev->fai_lock, flags);
   if (unlikely(faiStatus->FnState != DAQ_FN_IDLE)){
      ret = -EBUSY;
   } else {
      faiStatus->FnState   = DAQ_FN_READY;
      faiStatus->BufLength = faiParam->SampleCount;
   }
   spin_unlock_irqrestore(&daq_dev->fai_lock, flags);

   do {
      if (unlikely(ret)){
         break;
      }

      data_len = faiParam->SampleCount * AI_DATA_SIZE;
      ret = daq_umem_alloc(data_len, &daq_dev->fai_buffer, 1);
      if (unlikely(ret)){
         break;
      }

      sect_len = faiParam->SectionSize * AI_DATA_SIZE;
      if (faiParam->XferMode == DAQ_XFER_DMA) {
         sgl_len = daq_plx905x_calc_sgl_length(data_len, sect_len);
         ret = daq_plx905x_alloc_sgl_mem(sgl_len, &daq_dev->fai_sgl);
         if (unlikely(ret)){
            break;
         }

         if (faiParam->LogChanCount == 4) {
            dev_loc_addr = DR_AI_FOURCHDATA;
         } else {
            dev_loc_addr = faiParam->PhyChanStart ? DR_AI_CHAN(2) : DR_AI_CHAN(0);
         }

         ret = daq_plx905x_build_sgl(&daq_dev->fai_buffer, 
                  data_len, sect_len, dev_loc_addr, 1, &daq_dev->fai_sgl);
         if (unlikely(ret)){
            break;
         }
      }
   } while (0);

   if (ret){
      daq_umem_free(&daq_dev->fai_buffer);
      daq_plx905x_free_sgl_mem(&daq_dev->fai_sgl);
      faiStatus->FnState = DAQ_FN_IDLE;
   }

   return ret;
}

int daq_ioctl_fai_start(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   unsigned long flags;
   int           ret = 0;

   spin_lock_irqsave(&daq_dev->fai_lock, flags);
   do {
      if (shared->FaiStatus.FnState == DAQ_FN_IDLE){
         ret = -EINVAL;
         break;
      }

      if (shared->FaiStatus.FnState == DAQ_FN_RUNNING){
         ret = -EBUSY;
         break;
      }

      memset(shared->IsEvtSignaled, 0, sizeof(shared->IsEvtSignaled));
      memset(&shared->FaiStatus, 0, sizeof(FAI_STATUS));
      shared->FaiStatus.FnState   = DAQ_FN_RUNNING;
      shared->FaiStatus.AcqMode   = (__u32)arg;
      shared->FaiStatus.BufLength = shared->FaiParam.SampleCount;
   } while (0);
   spin_unlock_irqrestore(&daq_dev->fai_lock, flags);

   if (ret){
      return ret;
   }

   daq_device_clear_event(daq_dev, KdxAiDataReady);
   daq_device_clear_event(daq_dev, KdxAiOverrun);
   daq_device_clear_event(daq_dev, KdxAiStopped);
   daq_device_clear_event(daq_dev, KdxAiCacheOverflow);

   memset(daq_dev->fai_buffer.kaddr, 0, shared->FaiStatus.BufLength * AI_DATA_SIZE);

   ret = daq_fai_start_hardware(daq_dev);

   return ret;
}

int daq_ioctl_fai_stop(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;

   if (shared->FaiStatus.FnState == DAQ_FN_IDLE){
      return 0;
   }

   daq_fai_stop_acquisition(daq_dev, arg & FAI_STOP_FREE_RES);

   return 0;
}

