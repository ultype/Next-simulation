/*
 * hw.h
 *
 *  Created on: 2011-10-19
 *      Author: rocky
 */

#ifndef _KERNEL_MODULE_HW_H_
#define _KERNEL_MODULE_HW_H_

// device register : AI Data
#define DR_AI_DATA_BASE   0x0
#define DR_AI_CHAN(ch)    (DR_AI_DATA_BASE + (ch) * 2)

#define AI_CHCTL_GAIN(ch, gain) ((gain) << ((ch) * 2))
#define AI_CHCTL_GAIN_MASK(ch)  (0x3 << ((ch) * 2))
#define DR_AI_CHCTL             0x8

#define DR_AI_CONVEN            0xA

typedef union _AI_CLK_CTL {
   __u16 Value;
   struct{
      __u16 Divider  : 8;
      __u16 Source   : 2;
   };
} AI_CLK_CTL;

#define AI_CLK_INTERNAL   0
#define AI_CLK_EXTANA     1
#define AI_CLK_EXTDIG     2
#define AI_CLK_OFF        3
#define DR_AI_CLKCTL      0xC

typedef union _AI_TRIG_CSR {
   __u16 Value;
   struct{
      __u16 TrigMode : 3;
      __u16 unused1  : 1;
      __u16 TrigSrc  : 3;
      __u16 TrigEdge : 1;
      __u16 unused2  : 6;
      __u16 DmaTCFlag: 1;
      __u16 TrigFlag : 1;
   };
} AI_TRIG_CSR;

#define AI_TRIGMODE_SW        0
#define AI_TRIGMODE_PACER     1
#define AI_TRIGMODE_POST      2
#define AI_TRIGMODE_DELAY     3
#define AI_TRIGMODE_ABOUT     4
#define AI_TRIGSRC_AICHAN(ch) ch
#define AI_TRIGSRC_DIGITAL    4
#define DR_AI_TRIGCSR         0xE

#define AI_FIFO_CLR(n)         ( 0x1 << ((n) * 8))
#define AI_FIFO_RST(n)         ( 0x2 << ((n) * 8))
#define AI_FIFO_EMPTY(n)       ( 0x1 << ((n) * 8))
#define AI_FIFO_HALFFULL(n)    ( 0x2 << ((n) * 8))
#define AI_FIFO_FULL(n)        ( 0x4 << ((n) * 8))
#define AI_FIFO_ALMOSTEMPTY(n) (0x10 << ((n) * 8))
#define AI_FIFO_ALMOSTFULL(n)  (0x20 << ((n) * 8))
#define AI_FIFO_CLRALL         0x01010101
#define AI_FIFO_RSTALL         0x02020202
#define AI_FIFO_FULL_MASK      0x04040404
#define DR_AI_FIFOCSR          0x10

#define DR_AI_FIFOPROG_BASE    0x14
#define DR_AI_FIFOPROG(n)      (DR_AI_FIFOPROG_BASE + (n) * 2)

#define DR_AI_DMACNTR          0x1C
#define DR_AI_DMACNTR_RST      0x1E

#define DEV_INT_FIFOHALFFULL(n)   (0x1 << ((n) * 2))
#define DEV_INT_FIFOALMOSTFULL(n) (0x2 << ((n) * 2))
#define DEV_INT_DMATERMCOUNT      0x100
#define DEV_INT_ENABLED            0x8000
#define DEV_INT_OCCURRED           0x8000
#define DR_DEV_INTCSR              0x20

#define DR_DEV_INTCLR              0x22

#define DR_AI_TRIGVOLT     0x24

#define CALI_BUSY_MASK     0x0800
#define DR_CALI_CMD        0x28

#define DR_BID             0x2c

#define DR_AI_FOURCHDATA   0x30

#define DR_DMA_XFERRST     0x30

#define DR_DMA_DREQSEL     0x34

#endif /* _KERNEL_MODULE_HW_H_ */
