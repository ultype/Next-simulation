/*
 * kshared.h
 *
 *  Created on: 2011-8-30
 *      Author: rocky
 */

#ifndef KERNEL_MODULE_SHARED_H_
#define KERNEL_MODULE_SHARED_H_

#include <linux/types.h>

#define ADVANTECH_VID  0x13fe
#define DEVICE_1714    0x1714
#define DEVICE_1744    0x1744
#define DEVICE_3714    0x3714

#define DRIVER_NAME   "bio1714"
#define DEVICE_NAME_FROM_PID(pid) ParseDeviceName(pid)
#define DEVICE_ID_FROM_PID(pid)   ParseDeviceId(pid)

#ifdef __cplusplus
static inline char const * ParseDeviceName(uint32 pid)
#else
static inline char * ParseDeviceName(uint32 pid)
#endif
{
   switch(pid)
   {
   case BD_PCI1714UL:  return "PCI-1714UL";
   case BD_PCIE1744:   return "PCIE-1744";
   case BD_MIC3714:    return "MIC-3714";
   default:            return "PCI-1714";
   }
}
static inline int ParseDeviceId(uint32 pid)
{
   switch(pid)
   {
   case BD_PCI1714UL:  return 0x1714;
   case BD_PCIE1744:   return 0x1744;
   case BD_MIC3714:    return 0x3714;
   default:            return 0x1714;
   }
}

// ----------------------------------------------------------
// H/W feature and structures.
// ----------------------------------------------------------
#define AI_CHL_COUNT             4
#define AI_SE_CHL_COUNT          AI_CHL_COUNT
#define AI_DIFF_CHL_COUNT        0
#define AI_CHL_MASK              (AI_CHL_COUNT - 1)   //
#define AI_RES_IN_BIT            12
#define AI_DATA_SIZE             sizeof(unsigned short)
#define AI_DATA_MASK             0xfff

#define AI_GAIN_V_Neg5To5          0
#define AI_GAIN_V_Neg2pt5To2pt5    1
#define AI_GAIN_V_Neg1To1          2
#define AI_GAIN_mV_Neg500To500     3

#define AI_CLK_BASE              (60*1000*1000)
#define AI_FIFO_SIZE             (32*1024)
#define AI_MAX_PACER             (AI_CLK_BASE / 2)
#define AI_MIN_PACER             (AI_CLK_BASE / 256)

#define AI_CLK_BASE_UL           (20*1000*1000)
#define AI_FIFO_SIZE_UL          (8*1024)
#define AI_MAX_PACER_UL          (AI_CLK_BASE_UL/2)
#define AI_MIN_PACER_UL          (AI_CLK_BASE_UL/256)

#define SAI_TIMEOUT_VAL          1000  // 1000ms time-out value for each sample reading.
#define SAI_DELAY_TIME           10    // 10us delay before reading data

#define GET_AI_CLK_BASE(pid)     (pid == BD_PCI1714UL ? AI_CLK_BASE_UL : AI_CLK_BASE)

enum KRNL_EVENT_IDX{
   KdxDevPropChged = 0,
   KdxAiDataReady,
   KdxAiOverrun,
   KdxAiStopped,
   KdxAiCacheOverflow,
   KrnlSptedEventCount,
};

static inline __u32 GetEventKIndex(__u32 eventType)
{
   __u32 kdx;
   switch ( eventType )
   {
   case EvtPropertyChanged:         kdx = KdxDevPropChged;    break;
   case EvtBufferedAiDataReady:     kdx = KdxAiDataReady;     break;
   case EvtBufferedAiOverrun:       kdx = KdxAiOverrun;       break;
   case EvtBufferedAiStopped:       kdx = KdxAiStopped;       break;
   case EvtBufferedAiCacheOverflow: kdx = KdxAiCacheOverflow; break;
   default: kdx = -1; break;
   }
   return kdx;
}

// -----------------------------------------------------
// default values
// -----------------------------------------------------
#define DEF_INIT_ON_LOAD        1

// AI default values
#define DEF_AI_CHTYPE           0 // single-ended
#define DEF_AI_GAIN             AI_GAIN_V_Neg5To5
#define DEF_FAI_CHSTART         0
#define DEF_FAI_CHCOUNT         1
#define DEF_FAI_CLKSRC          SigInternalClock
#define DEF_FAI_PACERDIVISOR    256
#define DEF_FAI_SECTSIZE(pid)   (pid == BD_PCI1714UL ? AI_FIFO_SIZE_UL / 2 : AI_FIFO_SIZE / 2)

#define DEF_FAI_TRIGSRC         SignalNone
#define DEF_FAI_TRIGACTION      DelayToStart
#define DEF_FAI_TRIGEDGE        RisingEdge
#define DEF_FAI_TRIGLEVEL       0
#define DEF_FAI_TRIGDELAY       0

// ----------------------------------------------------------
// Device private data
// ----------------------------------------------------------
typedef struct _FAI_CONFIG
{
   __u32  XferMode;
   __u32  PhyChanStart;
   __u32  LogChanCount;
   __u32  ConvClkSource;
   double ConvClkRatePerCH;
   __u32  PacerDivider;
   __u32  SectionSize;
   __u32  SampleCount;

   __u32  TrigAction;
   __u32  TrigSource;
   __u32  TrigEdge;
   __u32  TrigDelayCount;
   __u32  TrigLevelBin;
   double TrigLevel;
} FAI_CONFIG;

typedef struct _FAI_STATUS
{
   __u32  AcqMode;
   __u32  FnState;
   __u32  BufState;
   __u32  BufLength;
   __u32  WPRunBack;
   __u32  WritePos;
   __u32  ReadPos;
   __u32  DmaTCFlag;
} FAI_STATUS;

typedef struct _DEVICE_SHARED
{
   __u32       Size;           // Size of the structure
   __u32       ProductId;      // Device Type
   __u32       DeviceNumber;   // Zero-based device number

   // HW Information
   __u32       BoardId;        // Board dip switch number for the device
   __u32       BusNumber;      // PCI Bus number
   __u32       SlotNumber;     // PCI Slot number
   __u32       BrBase;
   __u32       BrLength;
   __u32       IoBase;
   __u32       IoLength;
   __u32       Irq;
   __u32       InitOnLoad;

   // --------------------------------------------------------
   __u8        AiChanType[AI_CHL_COUNT];
   __u8        AiChanGain[AI_CHL_COUNT];
   __u32       AiChanCtl;
   __u32       AiLogChanCount;

   FAI_CONFIG  FaiParam;
   FAI_STATUS  FaiStatus;

   // ---------------------------------------------------------
   __u32       IsEvtSignaled[KrnlSptedEventCount];
} DEVICE_SHARED;

#endif /* KERNEL_MODULE_SHARED_H_ */
