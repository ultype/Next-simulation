/*
 * isr.c
 *
 * Created on: October 7, 2012
 * Author: 
 */
#include "kdriver.h"
#include "hw.h"

// -----------------------------------------------------------------------------
// Must hold the lock when call this function.
void daq_dio_tasklet_func(unsigned long arg)
{
   daq_device_t  *daq_dev = (daq_device_t *) arg;
   DEVICE_SHARED *shared  = &daq_dev->shared;
   unsigned long flags;
   __u32         int_state, src_idx, i;

   // Copy the interrupt state to local cache to avoid impose the interrupt handler.
   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   int_state = shared->IntState;
   shared->IntState = 0;
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

   // check counter interrupt state
   if(shared->ProductId == BD_MIC3756 && (int_state & CT_X(0))) {
      int_state &= ~CT_X(0);
      if(!shared->IsEvtSignaled[KdxCntTimer0]) {
         shared->IsEvtSignaled[KdxCntTimer0] = 1;
         daq_device_signal_event(daq_dev, KdxCntTimer0);
      }
   }

   // check DI interrupt state
   for (src_idx = 0; int_state; int_state >>= 1, ++src_idx) {
      if (int_state & 0x1) {
          if (shared->DiSnap[src_idx].Count) {
             for ( i = 0; i < DIO_PORT_COUNT; ++i ) {
                shared->DiSnap[src_idx].State[i] = AdxIoInB(shared->IoBase, DR_DI_PORTX(i));
             }
          }

          // signal the event if needed.
          if (!shared->IsEvtSignaled[src_idx + KdxDiBegin]) {
             shared->IsEvtSignaled[src_idx + KdxDiBegin] = 1;
             daq_device_signal_event(daq_dev, src_idx + KdxDiBegin);
          }
      }
   }
}

irqreturn_t daq_irq_handler(int irq, void *dev_id)
{
   daq_device_t  *daq_dev = (daq_device_t *) dev_id;
   DEVICE_SHARED *shared  = &daq_dev->shared;

   __u32 i, x, int_state = 0;

   // for DI interrupt
   for(i = 0; i < DI_INT_SRC_COUNT; ++i) {
	   x = AdxIoInW(shared->IoBase, DR_DI_INT_CSR(i)) ;
	   if(x & DI_INT_MASK) {
		   AdxIoOutW(shared->IoBase, DR_DI_INT_CSR(i), int_state);
		   int_state |= DI_INT_X(i);
	   }
   }

   // for counter interrupt
   if(shared->ProductId == BD_MIC3756) {
	   x = AdxIoInW(shared->IoBase, DR_CT_CSR) ;
	   if(x & CT_INT_MASK) {
		   AdxIoOutW(shared->IoBase, DR_CT_CSR, x);
		   int_state |= CT_X(0);
	   }
   }

   if (!int_state) {
      return IRQ_RETVAL(0);
   }

   spin_lock(&daq_dev->dev_lock);
   shared->IntState |= int_state;
   spin_unlock(&daq_dev->dev_lock);

   tasklet_schedule(&daq_dev->dio_tasklet);

   return IRQ_RETVAL(1);
}

