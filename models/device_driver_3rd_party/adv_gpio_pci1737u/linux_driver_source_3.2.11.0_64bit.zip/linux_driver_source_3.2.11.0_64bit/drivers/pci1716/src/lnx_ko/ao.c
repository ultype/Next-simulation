/*
 * ao.c
 *
 *  Created on: 2013-8-3
 *      Author: 
 */
#include "kdriver.h"
#include "hw.h"

static inline
void  daq_ao_fill_chan_csr(unsigned chan, unsigned gain, AO_CHL_CSR *csr)
{
    csr->Gain = gain;
    csr->LdEn = 1;
}

//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------
void daq_ao_initialize_hw(daq_device_t *daq_dev)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   AO_CHL_CSR    csr     = {0};
   int           ao_cfg  = 0;
   int           i;
    
   for (i = 0; i < AO_CHL_COUNT; ++i) {
      daq_ao_fill_chan_csr(i, shared->AoChanGain[i], &csr);
      ao_cfg |= csr.Value << (i * 8);
   }
   AdxIoOutW(shared->IoBase, DR_AO_CHCSR, ao_cfg);

   // set channel init state
   if (shared->InitOnLoad) {
      for (i = 0; i < AO_CHL_COUNT; ++i) {
         AdxIoOutW(shared->IoBase, DR_AO_CHAN(i), shared->AoChanState[i]);
      }

      AdxIoInD(shared->IoBase, DR_AO_DATA_BASE);
   }
}

int daq_ioctl_ao_set_channel(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   AO_SET_CHAN   xbuf;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   if (xbuf.SetWhich & AO_SET_EXTREFUNI) {
      memcpy(&shared->AoExtRefUnipolar, &xbuf.ExtRefUnipolar, sizeof(shared->AoExtRefUnipolar));
   }
   
   if (xbuf.SetWhich & AO_SET_EXTREFBI) {
      memcpy(&shared->AoExtRefBipolar, &xbuf.ExtRefBipolar, sizeof(shared->AoExtRefBipolar));
   }

   if (xbuf.SetWhich & AO_SET_CHVRG){
      int        ao_cfg = 0;
      AO_CHL_CSR csr    = {0};
      __u32      i, ch, gains[AO_CHL_COUNT];

      if (unlikely(xbuf.ChanCount > AO_CHL_COUNT)){
         xbuf.ChanCount = AO_CHL_COUNT;
      }
      if (unlikely(copy_from_user(gains, (void *)xbuf.Gains, xbuf.ChanCount * sizeof(__u32)))){
         return -EFAULT;
      }

      csr.Value = AdxIoInW(shared->IoBase, DR_AO_CHCSR);
      for (i = 0; i < xbuf.ChanCount; ++i) {
         ch = (xbuf.ChanStart + i) & AO_CHL_MASK;
         shared->AoChanGain[ch] = gains[i];
         daq_ao_fill_chan_csr(ch, gains[i], &csr);

         ao_cfg &= ~(0xff << (ch * 8));
         ao_cfg |= csr.Value << (ch * 8);
      }

      // Set AO channel configuration
      AdxIoOutW(shared->IoBase, DR_AO_CHCSR, ao_cfg);
   }

   return 0;
}

int daq_ioctl_ao_write_sample(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED    *shared = &daq_dev->shared;
   AO_WRITE_SAMPLES xbuf;
   __u16            data[AO_CHL_COUNT];
   __u32            i, ch;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   if (unlikely(xbuf.ChanStart >= AO_CHL_COUNT || xbuf.ChanCount > AO_CHL_COUNT)){
      return -EINVAL;
   }


   if (unlikely(copy_from_user(data, (void *)xbuf.Data, xbuf.ChanCount * sizeof(__u16)))){
      return -EFAULT;
   }

   // Write samples
   for(i = 0; i < xbuf.ChanCount; ++i)
   {
      ch = (xbuf.ChanStart + i) & AO_CHL_MASK;
      AdxIoOutW(shared->IoBase, DR_AO_CHAN(ch), data[i]);
   }

   AdxIoInD(shared->IoBase, DR_AO_DATA_BASE);

   return 0;
}


