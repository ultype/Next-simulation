/*
 * kshared.h
 *
 *  Created on: 2013-8-3
 *      Author: 
 */

#ifndef KERNEL_MODULE_SHARED_H_
#define KERNEL_MODULE_SHARED_H_

#include <linux/types.h>


#define ADVANTECH_VID 0x13fe
#define DEVICE_1716   0x1716
#define DEVICE_3716   0x3716

#define DRIVER_NAME   "bio1716"

#define DEVICE_NAME_FROM_PID(pid) \
   (pid == BD_PCI1716 ? "PCI-1716" : (pid == BD_PCI1716L ? "PCI-1716L" : "MIC-3716"))

#define DEVICE_ID_FROM_PID(pid) \
   (pid == BD_MIC3716 ? 0x3716 : 0x1716)

// ----------------------------------------------------------
// H/W feature and structures.
// ----------------------------------------------------------
#define AI_CHL_COUNT             16
#define AI_SE_CHL_COUNT          AI_CHL_COUNT
#define AI_DIFF_CHL_COUNT        (AI_CHL_COUNT / 2)
#define AI_CHL_MASK              (AI_CHL_COUNT - 1)   //
#define AI_RES_IN_BIT            16
#define AI_DATA_SIZE             sizeof(unsigned short)
#define AI_DATA_MASK             0xffff

#define AI_GAIN_V_Neg5To5          0
#define AI_GAIN_V_Neg2pt5To2pt5    1
#define AI_GAIN_V_Neg1pt25To1pt25  2
#define AI_GAIN_mV_Neg625To625     3
#define AI_GAIN_V_Neg10To10        4
#define AI_GAIN_V_0To10            16
#define AI_GAIN_V_0To5             17
#define AI_GAIN_V_0To2pt5          18
#define AI_GAIN_V_0To1pt25         19

#define AI_CLK_BASE              (10*1000*1000)       // 10MHz clock
#define AI_MAX_PACER             (250*1000)           // 250KHz
#define AI_MIN_PACER             (AI_CLK_BASE / (65535.0 * 65535.0) )
#define AI_FIFO_SIZE             1024                 // Ai fifo size in samples.

#define SAI_TIMEOUT_VAL          1000  // 1000ms time-out value for each sample reading.
#define SAI_DELAY_TIME           20    // 10us delay before reading data

#define AO_CHL_COUNT             2
#define AO_CHL_MASK              (AO_CHL_COUNT - 1)
#define AO_RES_IN_BIT            16
#define AO_DATA_SIZE             sizeof(__u16)
#define AO_DATA_MASK             0xffff
#define AO_EXT_REF_UNIPOLAR      10
#define AO_EXT_REF_BIPOLAR       10   

#define AO_GAIN_V_Neg5To5        0
#define AO_GAIN_V_Neg10To10      1   
#define AO_GAIN_V_0To5           2
#define AO_GAIN_V_0To10          3
#define AO_GAIN_V_EXTBIPOLAR     4 
#define AO_GAIN_V_EXTUNIPOLAR    6

#define DIO_PORT_COUNT           2
#define DIO_CHL_COUNT            (DIO_PORT_COUNT * 8)

#define CNTR_CHL_COUNT           1
#define CNTR_RES_IN_BIT          16
#define CNTR_DATA_SIZE           sizeof(__u16)
#define CNTR_MIN_VAL             2
#define CNTR_MAX_VAL             65535
#define CNTR_CLK_BASE            (1 * 1000 * 1000)
#define CNTR_IDLE                0
#define CNTR_RBUF_DEPTH          16
#define CNTR_RBUF_POSMASK        (CNTR_RBUF_DEPTH -1)
#define CNTR_CHK_PERIOD_NS       10000000UL
#define CNTR_CHK_PERIOD_MAX_NS   625000000UL  // 10000000000UL >> 4
#define CNTR_VAL_THRESHOLD_BASE  10


enum KRNL_EVENT_IDX{
   KdxDevPropChged = 0,
   KdxAiDataReady,
   KdxAiOverrun,
   KdxAiStopped,
   KdxAiCacheOverflow,
   KrnlSptedEventCount,
};

static inline __u32 GetEventKIndex(__u32 eventType)
{
   __u32 kdx;
   switch ( eventType )
   {
   case EvtPropertyChanged:         kdx = KdxDevPropChged;    break;
   case EvtBufferedAiDataReady:     kdx = KdxAiDataReady;     break;
   case EvtBufferedAiOverrun:       kdx = KdxAiOverrun;       break;
   case EvtBufferedAiStopped:       kdx = KdxAiStopped;       break;
   case EvtBufferedAiCacheOverflow: kdx = KdxAiCacheOverflow; break;
   default: kdx = -1; break;
   }
   return kdx;
}

// -----------------------------------------------------
// default values
// -----------------------------------------------------
#define DEF_INIT_ON_LOAD        1

// AI default values
#define DEF_AI_CHTYPE           0 // single-ended
#define DEF_AI_GAIN             AI_GAIN_V_Neg5To5
#define DEF_FAI_CHSTART         0
#define DEF_FAI_CHCOUNT         1
#define DEF_FAI_CLKSRC          SigInternalClock
#define DEF_FAI_PACERDIVISOR    (100 * 100)
#define DEF_FAI_SECTSIZE        (AI_FIFO_SIZE / 2)
#define DEF_FAI_MODE            0

// AO default values
#define DEF_AO_GAIN             AO_GAIN_V_0To5
#define DEF_AO_EXT_REF_UNIPOLAR 10
#define DEF_AO_EXT_REF_BIPOLAR  10
#define DEF_AO_INIT_STATE       0

// DIO default values
#define DEF_DO_STATE            0

// CNTR default values
#define DEF_CNTR_CHIP_CLKSRC    SigInternalClock
#define DEF_CNTR_CHIP_LOADVAL   ((1 << CNTR_RES_IN_BIT) - 1)
#define DEF_CNTR_CHIP_OPMODE    0
#define DEF_CNTR_OST_CLKSRC     SigInternalClock
#define DEF_CNTR_OST_DELAYCNT   ((1 << CNTR_RES_IN_BIT) - 1)
#define DEF_CNTR_TMR_DIVISOR    (CNTR_CLK_BASE / 200)
#define DEF_CNTR_FM_PERIOD      0

// ----------------------------------------------------------
// Device private data
// ----------------------------------------------------------
typedef struct _FAI_CONFIG
{
   __u32  XferMode;
   __u32  PhyChanStart;
   __u32  LogChanCount;
   __u32  ConvClkSource;
   double ConvClkRatePerCH;
   __u32  PacerDivider;
   __u32  SectionSize;
   __u32  SampleCount;

} FAI_CONFIG;

typedef struct _FAI_STATUS
{
   __u32  AcqMode;
   __u32  FnState;
   __u32  BufState;
   __u32  BufLength;
   __u32  WPRunBack;
   __u32  WritePos;
   __u32  ReadPos;
   __u32  OvrnOffset;
   __u32  OvrnCount;
} FAI_STATUS;


typedef struct _CNTR_CONFIG
{
   // --------------------------------------------------------
   __u32  ChipClkSource[CNTR_CHL_COUNT];
   __u32  ChipOpMode[CNTR_CHL_COUNT];
   __u32  ChipLoadValue[CNTR_CHL_COUNT];

   // --------------------------------------------------------
   __u32  OstClkSource[CNTR_CHL_COUNT];
   __u32  OstDelayCount[CNTR_CHL_COUNT];
   // --------------------------------------------------------
   __u32  TmrDivisor[CNTR_CHL_COUNT];
   // --------------------------------------------------------
   __u32  FmPeroid[CNTR_CHL_COUNT];
} CNTR_CONFIG;

typedef struct _CNTR_STATE
{
   __u32     Operation;
   __u32     CanRead;
   __u32     AutoAdaptive;

   // ------------------------------------------
   __u32     CheckPeriod;
   __u32     Overflow;
   __u32     PrevValue;
   __u32     SummedValue;
   __s64     PrevTime;
   __u64     TotalTime;
   struct  {
      __u32  Head;
      __u32  Tail;
      __u32  CntrDelta[CNTR_RBUF_DEPTH];
      __u32  TimeDelta[CNTR_RBUF_DEPTH];
   };
} CNTR_STATE;

typedef struct _DEVICE_SHARED
{
   __u32       Size;           // Size of the structure
   __u32       ProductId;      // Device Type
   __u32       DeviceNumber;   // Zero-based device number

   // HW Information
   __u32       BoardId;        // Board dip switch number for the device
   __u32       BusNumber;      // PCI Bus number
   __u32       SlotNumber;     // PCI Slot number
   __u32       BrBase;
   __u32       BrLength;
   __u32       IoBase;
   __u32       IoLength;
   __u32       Irq;
   __u32       InitOnLoad;

   // --------------------------------------------------------
   __u8        AiChanType[AI_CHL_COUNT];
   __u8        AiChanGain[AI_CHL_COUNT];
   __u32       AiLogChanCount;
   FAI_CONFIG  FaiParam;
   FAI_STATUS  FaiStatus;

   // ---------------------------------------------------------
   __u32       AoChanGain[AO_CHL_COUNT];
   double      AoExtRefUnipolar;
   double      AoExtRefBipolar;
   __u16       AoChanState[AO_CHL_COUNT];

   // ---------------------------------------------------------
   __u8        DoPortState[DIO_PORT_COUNT];

   // ---------------------------------------------------------
   CNTR_CONFIG CntrConfig;
   CNTR_STATE  CntrState[CNTR_CHL_COUNT];
   __u32       CntrChkTimerOwner;

   // ---------------------------------------------------------
   __u32       IsEvtSignaled[KrnlSptedEventCount];
} DEVICE_SHARED;

#endif /* KERNEL_MODULE_SHARED_H_ */
