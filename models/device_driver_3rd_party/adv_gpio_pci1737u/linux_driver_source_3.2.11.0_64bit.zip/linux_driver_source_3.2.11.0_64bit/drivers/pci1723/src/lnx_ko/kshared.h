/*
 * kshared.h
 *
 *  Created on: 2016-08
 *      Author: 
 */

#ifndef KERNEL_MODULE_SHARED_H_
#define KERNEL_MODULE_SHARED_H_

#include <linux/types.h>

#define ADVANTECH_VID 0x13fe

#define DRIVER_NAME   "bio1723"

#define DEVICE_NAME_FROM_PID(pid) deviceNameFromPid(pid)
#define DEVICE_ID_FROM_PID(pid)   deviceIdFromPid(pid)

#ifdef __cplusplus
#  define char_const char const
#else
#  define char_const char
#endif
static inline char_const * deviceNameFromPid(int pid)
{   
   char_const *name;
   switch (pid)
   {
   case BD_PCI1723:  name = "PCI-1723"; break;
   case BD_MIC3723:  name = "MIC-3723"; break;
   default:          name = "unknown";  break;
   }
   return name;
}
static inline int deviceIdFromPid(int pid)
{
   int id;
   switch (pid)
   {
   case BD_PCI1723:  id = 0x1723; break;
   case BD_MIC3723:  id = 0x3723; break;
   default:          id = 0xffff; break;
   }
   return id;
}
// ----------------------------------------------------------
// H/W feature and structures.
// ----------------------------------------------------------
#define AO_CHL_COUNT          8
#define AO_CHL_MASK           (AO_CHL_COUNT - 1)
#define AO_RES_IN_BIT         16
#define AO_DATA_SIZE          sizeof(__u16)
#define AO_DATA_MASK          0xffff

#define DIO_PORT_COUNT           2
#define DIO_CHL_COUNT            (DIO_PORT_COUNT * 8)


enum KRNL_EVENT_IDX{
   KdxDevPropChged = 0,
   KrnlSptedEventCount,
};

static inline __u32 GetEventKIndex(__u32 id)
{
   __u32 kdx;
   switch (id)
   {
   case EvtPropertyChanged:  kdx = KdxDevPropChged;  break;
   default: kdx = -1; break;
   }
   return kdx;
}

// -----------------------------------------------------
// default values
// -----------------------------------------------------
#define DEF_INIT_ON_LOAD        1

// AO default values
#define DEF_AO_GAIN             V_Neg10To10
#define DEF_AO_INIT_STATE       0

// DIO default values
#define DEF_DIO_DIR             Input
#define DEF_DO_STATE            0

// ----------------------------------------------------------
// Device private data
// ----------------------------------------------------------
typedef struct _DEVICE_SHARED
{
   __u32       Size;           // Size of the structure
   __u32       ProductId;      // Device Type
   __u32       DeviceNumber;   // Zero-based device number

   // HW Information
   __u32       BoardId;        // Board dip switch number for the device
   __u32       BusNumber;      // PCI Bus number
   __u32       SlotNumber;     // PCI Slot number
   __u32       IoBase;
   __u32       IoLength;
   __u32       Irq;
   __u32       InitOnLoad;

   // --------------------------------------------------------
   __u32       AoChanGain[AO_CHL_COUNT];
   __u16       AoChanState[AO_CHL_COUNT];

   // --------------------------------------------------------
   __u8        DioPortDir[DIO_PORT_COUNT];
   __u8        DoPortState[DIO_PORT_COUNT];

   // --------------------------------------------------------

   // ---------------------------------------------------------
   __u32       IsEvtSignaled[KrnlSptedEventCount];

} DEVICE_SHARED;

#endif /* KERNEL_MODULE_SHARED_H_ */
