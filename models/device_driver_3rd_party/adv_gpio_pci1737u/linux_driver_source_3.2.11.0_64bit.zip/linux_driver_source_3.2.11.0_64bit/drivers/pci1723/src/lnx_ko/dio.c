/*
 * dio.c
 *
 *  Created on: 2016-08
 *      Author: 
 */
#include "kdriver.h"
#include "hw.h"

static
void daq_dio_set_port_dir(DEVICE_SHARED *shared)
{
   DIO_CSR csr = {0};

   csr.DIR_DIO0 = shared->DioPortDir[0] == Input ? PORTDIR_IN : PORTDIR_OUT;
   csr.DIR_DIO1 = shared->DioPortDir[1] == Input ? PORTDIR_IN : PORTDIR_OUT;
   AdxIoOutW(shared->IoBase, DR_DIO_CSR, csr.Value);
}

//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------
void daq_dio_initialize_hw(daq_device_t *daq_dev)
{
   daq_dio_set_port_dir(&daq_dev->shared);
   if (daq_dev->shared.InitOnLoad){
      AdxIoOutW(daq_dev->shared.IoBase, DR_DIO_DATA, *(__u16*)daq_dev->shared.DoPortState);
   }
}

int daq_ioctl_dio_set_port_dir(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED    *shared = &daq_dev->shared;
   DIO_SET_PORT_DIR xbuf;
   __u8             dirs[DIO_PORT_COUNT];
   unsigned         i;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   if (unlikely(xbuf.PortCount > DIO_PORT_COUNT)){
      return -EINVAL;
   }

   if (unlikely(xbuf.PortStart + xbuf.PortCount > DIO_PORT_COUNT)){
      return -EINVAL;
   }

   if (unlikely(copy_from_user(dirs, (void *)xbuf.Dirs, xbuf.PortCount))){
      return -EFAULT;
   }

   for (i = 0; i < xbuf.PortCount; ++i){
      shared->DioPortDir[xbuf.PortStart + i] = dirs[i];
   }
   daq_dio_set_port_dir(shared);

   return 0;
}

int daq_ioctl_di_read_port(daq_device_t *daq_dev, unsigned long arg)
{
   DIO_RW_PORTS xbuf;
   __u8         data[DIO_PORT_COUNT];
   unsigned     i, port;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   xbuf.PortStart %= DIO_PORT_COUNT;
   xbuf.PortCount  = x_min((unsigned)DIO_PORT_COUNT, xbuf.PortCount);
   for (i = 0; i < xbuf.PortCount; ++i){
      port = (xbuf.PortStart + i) % DIO_PORT_COUNT;
      data[i] = AdxIoInB(daq_dev->shared.IoBase, DR_DIO_DATA + port);
   }

   if (unlikely(copy_to_user(xbuf.Data, data, xbuf.PortCount))){
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_do_write_port(daq_device_t *daq_dev, unsigned long arg)
{
   DIO_RW_PORTS xbuf;
   __u8         data[DIO_PORT_COUNT];
   unsigned     i, port;
   union {
      __u16 u16_data;
	  __u8  u8_data[2];
   }do_status;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   xbuf.PortStart %= DIO_PORT_COUNT;
   xbuf.PortCount  = x_min((unsigned)DIO_PORT_COUNT, xbuf.PortCount);
   if (unlikely(copy_from_user(data, (void *)xbuf.Data, xbuf.PortCount))){
      return -EFAULT;
   }

   //Note, the DO port can't be write by byte, 
   //The DO port output status is correct
   //but the followed read back operation will return unexpected value
   do_status.u16_data = AdxIoInW(daq_dev->shared.IoBase, DR_DIO_DATA);
   for (i = 0; i < xbuf.PortCount; ++i){
      port = (xbuf.PortStart + i) % DIO_PORT_COUNT;
	  do_status.u8_data[port] = data[i];
   }
   AdxIoOutW(daq_dev->shared.IoBase, DR_DIO_DATA, do_status.u16_data);
   
   return 0;
}

int daq_ioctl_do_read_port(daq_device_t *daq_dev, unsigned long arg)
{
   // for PCI-1723, this is just the same as read DI port.
   return daq_ioctl_di_read_port(daq_dev, arg);
}

int daq_ioctl_do_write_bit(daq_device_t *daq_dev, unsigned long arg)
{
   DIO_RW_BIT xbuf;
   __u8       data, status;
   unsigned   port, bit;
   unsigned long flags;
   
   union {
      __u16 u16_data;
      __u8  u8_data[2];
   } do_status;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   port = xbuf.Port % DIO_PORT_COUNT;
   bit  = xbuf.Bit;
   data = xbuf.Data;

   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   status = AdxIoInB(daq_dev->shared.IoBase, DR_DIO_DATA + port);
   status = ((data & 0x1) << bit) | (~(1 << bit) & status);
   do_status.u16_data      = AdxIoInW(daq_dev->shared.IoBase, DR_DIO_DATA);
   do_status.u8_data[port] = status;
   AdxIoOutW(daq_dev->shared.IoBase, DR_DIO_DATA, do_status.u16_data);
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
   
   return 0;
}