/*
 * isr.c
 *
 *  Created on: Nov 29, 2011
 *      Author: 
 */
#include "kdriver.h"
#include "hw.h"

// -----------------------------------------------------------------------------
// Must hold the lock when call this function.
static inline
void daq_fai_update_status(FAI_CONFIG *cfg, FAI_STATUS *st, unsigned inc_count)
{
   // check data ready and update write position
   if (st->WritePos + inc_count >= st->BufLength) {
      st->BufState  |=  DAQ_IN_DATAREADY;
      st->WritePos  += inc_count;
      st->WritePos  %= st->BufLength;
      st->WPRunBack += 1;
   } else {
      if ((st->WritePos % cfg->SectionSize) + inc_count >= cfg->SectionSize) {
         st->BufState |= DAQ_IN_DATAREADY;
      }
      st->WritePos += inc_count;
   }

   // check overrun and buffer full
   if (st->WPRunBack) {
      int ovrnOffset = st->ReadPos;
      int ovrnCount  = st->WritePos - ovrnOffset;
      st->BufState |= DAQ_IN_BUF_FULL;

      if (st->WPRunBack > 1 || ovrnCount > 0){
         if (st->WPRunBack > 1) { 
            ovrnCount = st->BufLength;
         }

         st->OvrnCount  = ovrnCount;
         st->OvrnOffset = ovrnOffset;
         st->BufState |= DAQ_IN_BUF_OVERRUN;
      }
   }
}

static inline
void daq_fai_read_fifo(DEVICE_SHARED *shared, __u16 *data_buf, unsigned count)
{
   __u16 * buf_end = data_buf + count;

   for (; data_buf < buf_end; ++data_buf) {
      *data_buf = AdxIoInW(shared->IoBase, DR_AI_DATA);
   }
}

static inline
int daq_fai_read_fifo_probe(DEVICE_SHARED *shared, __u16 *data_buf, unsigned count)
{
#define FIFO_IS_EMPTY(shared) (AdxIoInB(shared->IoBase, DR_DEV_STA) & 0x1)
   __u16 * buf_end = data_buf + count;

   while(!FIFO_IS_EMPTY(shared) && data_buf < buf_end) {
      *data_buf++ = AdxIoInW(shared->IoBase, DR_AI_DATA);
   }
   return count - (__u32)(buf_end - data_buf);
}

void daq_fai_tasklet_func(unsigned long arg)
{
   daq_device_t  *daq_dev   = (daq_device_t *) arg;
   DEVICE_SHARED *shared    = &daq_dev->shared;
   FAI_STATUS    *faiStatus = &shared->FaiStatus;
   unsigned      buf_state;

   if (faiStatus->FnState != DAQ_FN_RUNNING){
      return;
   }

   {
      DEV_STA     sta;
      unsigned    read_count;
      unsigned    sectLen;
      __u16       *data_buf = (__u16*)daq_dev->fai_buffer.kaddr;

      // CacheOverflow !!!!!
      sta.Value = AdxIoInB(shared->IoBase, DR_DEV_STA);
      if (sta.FifoFull) {
         daq_trace((KERN_ERR "fifo full, discard. sta = 0x%x\n", sta.Value));
         AdxIoOutB(shared->IoBase, DR_CLR_FIFO, 0);
         if(!shared->IsEvtSignaled[KdxAiCacheOverflow]) {
            shared->IsEvtSignaled[KdxAiCacheOverflow] = 1;
            daq_device_signal_event(daq_dev, KdxAiCacheOverflow);
         }
         return;
      }

      if (shared->FaiParam.SectionSize < (AI_FIFO_SIZE / 2)) {
         // Only one data available
         /*read_count = 1;
         data_buf[faiStatus->WritePos] = AdxIoInW(shared->IoBase, DR_AI_DATA);*/
         sectLen = x_min(shared->FaiParam.SectionSize / 2, faiStatus->BufLength - faiStatus->WritePos);
         read_count = daq_fai_read_fifo_probe(shared, &data_buf[faiStatus->WritePos], sectLen);
      } else { // FIFO half full
         if (unlikely(!sta.FifoHalf)) {
            return;
         } else {
            sectLen = x_min((unsigned)AI_FIFO_SIZE / 2, faiStatus->BufLength - faiStatus->WritePos);
            daq_fai_read_fifo(shared, &data_buf[faiStatus->WritePos], sectLen);
            read_count = sectLen;

            if ( shared->FaiStatus.AcqMode == DAQ_ACQ_INFINITE )
            {
               sectLen = (AI_FIFO_SIZE / 2) - sectLen;
               if (sectLen) {
                  daq_fai_read_fifo(shared, data_buf, sectLen);
               }
               read_count = (AI_FIFO_SIZE / 2);
            }
         }
      }

      daq_fai_update_status(&shared->FaiParam, faiStatus, read_count);
      buf_state = faiStatus->BufState;
      faiStatus->BufState = 0;
   }

   if ((buf_state & DAQ_IN_BUF_OVERRUN) && !shared->IsEvtSignaled[KdxAiOverrun]) {
     shared->IsEvtSignaled[KdxAiOverrun] = 1;
     daq_device_signal_event(daq_dev, KdxAiOverrun);
   }

   if ((buf_state & DAQ_IN_DATAREADY) && !shared->IsEvtSignaled[KdxAiDataReady]) {
     shared->IsEvtSignaled[KdxAiDataReady] = 1;
     daq_device_signal_event(daq_dev, KdxAiDataReady);
   }

   if (DAQ_IN_MUST_STOP(buf_state, faiStatus->AcqMode)) {
      daq_fai_stop_acquisition(daq_dev, false);
   }
}

irqreturn_t daq_irq_handler(int irq, void *dev_id)
{
   daq_device_t *daq_dev = (daq_device_t *) dev_id;
   DEVICE_SHARED *shared = &daq_dev->shared;
   DEV_STA       sta;

   sta.Value = AdxIoInB(shared->IoBase, DR_DEV_STA);
   if (!sta.IntFlag){
      return IRQ_RETVAL(0);
   }

   tasklet_schedule(&daq_dev->fai_tasklet);

   AdxIoOutB(shared->IoBase, DR_CLR_INTR, 0);

   return IRQ_RETVAL(1);
}
