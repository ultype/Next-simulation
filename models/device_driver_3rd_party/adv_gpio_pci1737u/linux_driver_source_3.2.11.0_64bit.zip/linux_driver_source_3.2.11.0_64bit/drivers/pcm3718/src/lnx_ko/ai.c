/*
 * ai.c
 *
 *  Created on: 2011-11-10
 *      Author: 
 */

#include "kdriver.h"
#include "hw.h"

static inline
__u32 AiThermoCoupleGain2DeviceGain( __u32 ThermoGain )
{
   __u32 deviceGain = 0;
   switch ( ThermoGain )
   {
   case Jtype_Gain:
   case Ktype_Gain:
   case Etype_Gain:
      deviceGain = 10; //-100~100mV
      break;
   case Ttype_Gain:
   case Rtype_Gain:
   case Stype_Gain:
   case Btype_Gain:
      deviceGain = 2; //-50~50mV
      break;
   }
   return deviceGain;
}

static
int daq_ai_configure_channel(DEVICE_SHARED *shared, __u32 chan, __u8 sctype, __u8 gain)
{
   shared->AiChanType[chan] = sctype;
   shared->AiChanGain[chan] = gain;

   if (!(chan > (AI_CHL_COUNT/2 - 1)) || sctype != Differential) {
      AI_CHL_CFG_REG reg = {0};
      if ( gain >= Jtype_Gain )
      {
         reg.GainCode = AiThermoCoupleGain2DeviceGain(gain);
      } else {
         reg.GainCode = gain;
      }

      AdxIoOutB(shared->IoBase, DR_AiMux, (chan << 4 | chan));
      AdxIoOutB(shared->IoBase, DR_AiChlCfg, reg.Value);
   }

   return 0;
}

static
__u32 daq_ai_read_channel(DEVICE_SHARED *shared, unsigned timeout)
{
   AI_STATUS_REG status;
   unsigned long absolute_timeout;

   // Trigger a A/D conversion.
   AdxIoOutB(shared->IoBase, DR_AiData, 1 );

   // use time-out detecting.
   absolute_timeout = jiffies + msecs_to_jiffies(timeout);

   // waiting for data ready
   do {
      status.Value = AdxIoInB(shared->IoBase, DR_AiStatus);
      if (!status.Busy){
         break;
      }
      if (time_is_before_jiffies(absolute_timeout)){
         daq_trace((KERN_ERR "read ai time-out."));
         return -1;
      }
   }while (1);

   return AdxIoInB(shared->IoBase, DR_AiData) + (AdxIoInB(shared->IoBase, DR_AiData + 1) << 8);
}

static
void daq_fai_setup_pacer(DEVICE_SHARED *shared)
{
   I825X_CTL ctl_word;

   // Select counter 1; Read/write LSB first, then MSB; operation mode 2(rate gen); binary counting.
   ctl_word.SC   = 1;
   ctl_word.RW   = 3;
   ctl_word.Mode = 2;
   ctl_word.Bcd  = 0;
   AdxIoOutB(shared->IoBase, DR_CntrCSR, ctl_word.Value);
   AdxIoOutB(shared->IoBase, DR_Cntr1CSR,    shared->FaiParam.PacerDivider);
   AdxIoOutB(shared->IoBase, DR_Cntr1CSR,    shared->FaiParam.PacerDivider >> 8);

   // Select counter 2; Read/write LSB first, then MSB; operation mode 2(rate gen); binary counting.
   ctl_word.SC = 2;
   AdxIoOutB(shared->IoBase, DR_CntrCSR,  ctl_word.Value);
   AdxIoOutB(shared->IoBase, DR_Cntr2CSR,     shared->FaiParam.PacerDivider >> 16);
   AdxIoOutB(shared->IoBase, DR_Cntr2CSR,     shared->FaiParam.PacerDivider >> 24);
}

static
int daq_fai_start_hardware(daq_device_t *daq_dev)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   FAI_CONFIG  *faiParam = &shared->FaiParam;
   FAI_STATUS *faiStatus = &shared->FaiStatus;

   AI_CTRL_REG ctlReg = {0};
   
   // Disable device interrupt
   shared->ClkReg.PacerEn = 1; 
   AdxIoOutB(shared->IoBase, DR_PacerCtrl, shared->ClkReg.Value);

   AdxIoOutB(shared->IoBase, DR_AiCtrl, ctlReg.Value);
   

   // Clear device's AD interrupt and FIFO
   AdxIoOutB(shared->IoBase, DR_ClrIntr, 0);
   AdxIoOutB(shared->IoBase, DR_ClrFifo, 0);

   // Set channel scan range
   {
      unsigned ch_range = daq_ai_calc_phy_chan_range(shared->AiChanType, AI_CHL_COUNT,
                             faiParam->PhyChanStart, faiParam->LogChanCount);
      ch_range = ((ch_range & 0x0f00) >> 4) | (ch_range & 0x0f);
      AdxIoOutB(shared->IoBase, DR_AiMux, ch_range);
   }

   if (faiParam->ConvClkSource == SigExtDigClock) {
      ctlReg.TrigSource = 2;
   } else {
      ctlReg.TrigSource = 3;
   }

   ctlReg.Irql = shared->Irq;
   ctlReg.IntEn = 1;

   // Only PCM-3718HO have FIFO
   if (shared->ProductId == BD_PCM3718HO) {
      if ( shared->EnableFifoOf3718HO && shared->FaiParam.SectionSize >= (AI_FIFO_SIZE / 2) )
      {  
         // enable pacer & interrupt every 512 data
         AdxIoOutB(shared->IoBase, DR_AiFifoCtrl, 1);
         AdxIoOutB(shared->IoBase, DR_ClrFifo, 0);  

         ctlReg.Irql = 0;
      } else {
         AdxIoOutB(shared->IoBase, DR_AiFifoCtrl, 0);
      }
   }

   if (shared->FaiParam.XferMode == DAQ_XFER_DMA && shared->DmaChan) {
      unsigned long flags;
      ctlReg.DmaEn = 1;

      flags = claim_dma_lock();
      disable_dma(shared->DmaChan);
      clear_dma_ff(shared->DmaChan);
      set_dma_mode(shared->DmaChan, (DMA_AUTOINIT | DMA_MODE_READ));
      set_dma_addr(shared->DmaChan, virt_to_bus(daq_dev->fai_common_buffer));
      set_dma_count(shared->DmaChan, DMA_COMN_BUF_SIZE);
      enable_dma(shared->DmaChan);
      release_dma_lock(flags);

      schedule_delayed_work(&daq_dev->dma_work, 1);
   }

   // pacer trigger
   daq_fai_setup_pacer(shared);
   shared->ClkReg.PacerEn = 0; //Enable pacer
   AdxIoOutB(shared->IoBase, DR_PacerCtrl, shared->ClkReg.Value);

   // start AI acquirement
   AdxIoOutB(shared->IoBase, DR_AiCtrl, ctlReg.Value);

   // add the task to wait_queue for sync read
   if (faiStatus->AcqMode == DAQ_ACQ_FINITE_SYNC){
      return wait_event_interruptible(daq_dev->fai_queue, faiStatus->FnState != DAQ_FN_RUNNING);
   }

   return 0;
}

static
void ai_get_actual_sctype(DEVICE_SHARED *shared)
{
   // Read the hardware's actual jumper setting of channel SCType
   AI_STATUS_REG aiStatusReg;
   unsigned      i;
   aiStatusReg.Value = AdxIoInB(shared->IoBase, DR_AiStatus);
   for (i = 0; i < AI_CHL_COUNT; ++i) {
      if (aiStatusReg.SigConnect) {
         shared->AiChanType[ i ] = SingleEnded;
      } else {
         shared->AiChanType[ i ] = Differential; 
      }
   }
}

//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------
void daq_ai_initialize_hw(daq_device_t *daq_dev)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   int i;

   ai_get_actual_sctype(shared);

   for (i = 0; i < AI_CHL_COUNT; ++i) {
      daq_ai_configure_channel(shared, i, shared->AiChanType[i], shared->AiChanGain[i]);
   }
   shared->AiLogChanCount = daq_ai_calc_log_chan_count(shared->AiChanType, AI_CHL_COUNT);
}

void daq_fai_stop_acquisition(daq_device_t *daq_dev, int cleanup)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   FAI_STATUS *faiStatus = &shared->FaiStatus;

   unsigned long flags;

   spin_lock_irqsave(&daq_dev->fai_lock, flags);
   if (faiStatus->FnState != DAQ_FN_RUNNING){
      spin_unlock_irqrestore(&daq_dev->fai_lock, flags);
   } else {
      faiStatus->FnState = DAQ_FN_STOPPED;
      spin_unlock_irqrestore(&daq_dev->fai_lock, flags);

      if (shared->FaiParam.XferMode == DAQ_XFER_DMA && shared->DmaChan) {
         daq_dev->dma_run_flag = 0;
      }

      shared->ClkReg.PacerEn = 1; //Disable pacer
      AdxIoOutB(shared->IoBase, DR_PacerCtrl, shared->ClkReg.Value);

      AdxIoOutB(shared->IoBase, DR_AiCtrl,  0);
      AdxIoOutB(shared->IoBase, DR_ClrIntr, 0); 
      AdxIoOutB(shared->IoBase, DR_AiFifoCtrl, 0); // for PCM-3718HO
      AdxIoOutB(shared->IoBase, DR_ClrFifo, 0); // for PCM-3718HO
      AdxIoOutB(shared->IoBase, 20, 0); // clear interrupt request with FIFO

      daq_device_signal_event(daq_dev, KdxAiStopped);
      wake_up_interruptible(&daq_dev->fai_queue);
   }

   if (cleanup) {
      if (shared->FaiParam.XferMode == DAQ_XFER_DMA && shared->DmaChan) {
         unsigned long flags = claim_dma_lock();
         disable_dma(shared->DmaChan);
         release_dma_lock(flags);
         free_dma(shared->DmaChan);
         if (daq_dev->fai_common_buffer != NULL) {
            kfree(daq_dev->fai_common_buffer);
            daq_dev->fai_common_buffer = NULL;
         }
      }
      daq_umem_unmap(&daq_dev->fai_buffer);

      spin_lock_irqsave(&daq_dev->fai_lock, flags);
      faiStatus->FnState = DAQ_FN_IDLE;
      spin_unlock_irqrestore(&daq_dev->fai_lock, flags);
   }
}

int daq_ioctl_ai_set_channel(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   AI_SET_CHAN   xbuf;
   AI_CHAN_CFG   cfg[AI_CHL_COUNT];
   __u32         i, ch;

   if (unlikely(shared->FaiStatus.FnState == DAQ_FN_RUNNING)){
      return -EBUSY;
   }

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   if (unlikely(xbuf.PhyChanCount > AI_CHL_COUNT)){
      xbuf.PhyChanCount = AI_CHL_COUNT;
   }
   if (unlikely(copy_from_user(cfg, (void *)xbuf.ChanCfg, sizeof(AI_CHAN_CFG) * xbuf.PhyChanCount))){
      return -EFAULT;
   }

   for (i = 0; i < xbuf.PhyChanCount; ++i)
   {
      ch = (xbuf.PhyChanStart + i) & AI_CHL_MASK;
      daq_ai_configure_channel(shared, ch, cfg[i].SCType, cfg[i].Gain);
   }

   shared->AiLogChanCount = daq_ai_calc_log_chan_count(shared->AiChanType, AI_CHL_COUNT);

   return 0;
}

int daq_ioctl_ai_read_sample(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED   *shared = &daq_dev->shared;
   AI_READ_SAMPLES xbuf;
   __u16           sample[AI_CHL_COUNT];
   __u16           *data_ptr;
   __u32           ch_range, result;

   if (unlikely(daq_dev->shared.FaiStatus.FnState == DAQ_FN_RUNNING)){
      return -EBUSY;
   }

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   xbuf.PhyChanStart &= AI_CHL_MASK;
   xbuf.LogChanCount =  x_min(xbuf.LogChanCount, shared->AiLogChanCount);
   ch_range = daq_ai_calc_phy_chan_range(shared->AiChanType, AI_CHL_COUNT, xbuf.PhyChanStart, xbuf.LogChanCount);
   ch_range = ((ch_range & 0x0f00) >> 4) | (ch_range & 0x0f);

   {
      AI_CTRL_REG aiCtrlReg = {0};
      // set channel scan range
      AdxIoOutB(daq_dev->shared.IoBase, DR_AiMux, ch_range);

      // clear interrupt and FIFO
      AdxIoOutB(daq_dev->shared.IoBase, DR_ClrIntr, 0);

      // set the trigger mode
      aiCtrlReg.TrigSource = 0;
      AdxIoOutB(daq_dev->shared.IoBase, DR_AiCtrl, aiCtrlReg.Value);

   }

   // Read samples
   for(data_ptr = sample; data_ptr < sample + xbuf.LogChanCount; ++data_ptr){
      udelay(SAI_DELAY_TIME);
      result = daq_ai_read_channel(shared, SAI_TIMEOUT_VAL);
      if (result == -1){
         return -EIO;
      }
      *data_ptr = (__u16)result;
   }

   if (unlikely(copy_to_user((void *)xbuf.Data, sample, xbuf.LogChanCount * sizeof(__u16)))) {
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_fai_set_param(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;

   FAI_CONFIG    xbuf;
   unsigned long flags;
   int           ret = 0;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   spin_lock_irqsave(&daq_dev->fai_lock, flags);
   if (unlikely(shared->FaiStatus.FnState != DAQ_FN_IDLE)){
      ret = -EBUSY;
   } else {
      shared->FaiParam              = xbuf;
      shared->FaiParam.PhyChanStart = xbuf.PhyChanStart & AI_CHL_MASK;
      shared->FaiParam.LogChanCount = x_min(xbuf.LogChanCount, shared->AiLogChanCount);
   }
   spin_unlock_irqrestore(&daq_dev->fai_lock, flags);

   if (likely(!ret)){
      daq_device_signal_event(daq_dev, KdxDevPropChged);
   }

   return ret;
}

int daq_ioctl_fai_set_buffer(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   FAI_CONFIG  *faiParam = &shared->FaiParam;
   FAI_STATUS *faiStatus = &shared->FaiStatus;

   unsigned long flags;
   int           ret = 0;
   int           use_dma = (shared->FaiParam.XferMode == DAQ_XFER_DMA && shared->DmaChan) ? 1 : 0;

   if (unlikely(!faiParam->SampleCount)) {
      return -EINVAL;
   }

   if (use_dma) {
      daq_dev->fai_common_buffer = (__u16 *)kmalloc(DMA_COMN_BUF_SIZE, (GFP_DMA | GFP_KERNEL));
      if (!daq_dev->fai_common_buffer) {
         return -ENOMEM;
      }

      ret = request_dma(shared->DmaChan, DEVICE_NAME_FROM_PID(shared->ProductId));
      if (unlikely(ret)) {
         kfree(daq_dev->fai_common_buffer);
         return -EBUSY;
      }
   }

   spin_lock_irqsave(&daq_dev->fai_lock, flags);
   if (unlikely(faiStatus->FnState != DAQ_FN_IDLE)){
      ret = -EBUSY;
   } else {
      faiStatus->FnState   = DAQ_FN_READY;
      faiStatus->BufLength = faiParam->SampleCount;
   }
   spin_unlock_irqrestore(&daq_dev->fai_lock, flags);

   do {
      if (unlikely(ret)){
         break;
      }

      ret = daq_umem_map(arg, faiParam->SampleCount * AI_DATA_SIZE, 1, &daq_dev->fai_buffer);
   } while (0);

   if (ret){
      if (use_dma) {
         free_dma(shared->DmaChan);
         kfree(daq_dev->fai_common_buffer);
      }
      daq_umem_unmap(&daq_dev->fai_buffer);
      faiStatus->FnState = DAQ_FN_IDLE;
      return ret;
   }

   return ret;
}

int daq_ioctl_fai_start(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   unsigned long flags;
   int           ret = 0;

   spin_lock_irqsave(&daq_dev->fai_lock, flags);
   do{
      if (shared->FaiStatus.FnState == DAQ_FN_IDLE){
         ret = -EINVAL;
         break;
      }

      if (shared->FaiStatus.FnState == DAQ_FN_RUNNING){
         ret = -EBUSY;
         break;
      }

      memset(shared->IsEvtSignaled, 0, sizeof(shared->IsEvtSignaled));
      memset(&shared->FaiStatus, 0, sizeof(FAI_STATUS));
      shared->FaiStatus.FnState   = DAQ_FN_RUNNING;
      shared->FaiStatus.AcqMode   = (__u32)arg;
      shared->FaiStatus.BufLength = shared->FaiParam.SampleCount;
      daq_dev->dma_run_flag       = 1;
   } while (0);
   spin_unlock_irqrestore(&daq_dev->fai_lock, flags);

   if (ret){
      return ret;
   }

   daq_device_clear_event(daq_dev, KdxAiDataReady);
   daq_device_clear_event(daq_dev, KdxAiOverrun);
   daq_device_clear_event(daq_dev, KdxAiStopped);
   daq_device_clear_event(daq_dev, KdxAiCacheOverflow);

   ret = daq_fai_start_hardware(daq_dev);

   return ret;
}

int daq_ioctl_fai_stop(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;

   if (shared->FaiStatus.FnState == DAQ_FN_IDLE){
      return 0;
   }

   daq_fai_stop_acquisition(daq_dev, arg & FAI_STOP_FREE_RES);

   return 0;
}

