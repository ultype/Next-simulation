/*
 * kshared.h
 *
 *  Created on: 2011-8-30
 *      Author: 
 */

#ifndef KERNEL_MODULE_SHARED_H_
#define KERNEL_MODULE_SHARED_H_

#include <linux/types.h>
#include "hw.h"

#define ADVANTECH_VID 0x13fe
#define DEVICE_ID     0x3718
#define DRIVER_NAME   "bio3718"

#ifdef __cplusplus
#  define char_const char const
#else
#  define char_const char
#endif
static inline char_const * deviceNameFromPid(int pid)
{   
   char_const *name;
   switch (pid)
   {
   case BD_PCM3718:   name = "PCM-3718"; break;
   case BD_PCM3718H:  name = "PCM-3718H"; break;
   case BD_PCM3718HG: name = "PCM-3718HG"; break;
   case BD_PCM3718HO: name = "PCM-3718HO"; break;
   default:           name = "unknown";   break;
   }
   return name;
};

#define DEVICE_NAME_FROM_PID(pid)  deviceNameFromPid(pid)

#define DMA_COMN_BUF_SIZE 0x2000  

// ----------------------------------------------------------
// H/W feature and structures.
// ----------------------------------------------------------
#define AI_CHL_COUNT             16
#define AI_SE_CHL_COUNT          AI_CHL_COUNT
#define AI_DIFF_CHL_COUNT        (AI_CHL_COUNT / 2)
#define AI_CHL_MASK              (AI_CHL_COUNT - 1)   //
#define AI_RES_IN_BIT            12
#define AI_DATA_SIZE             sizeof(__u16)
#define AI_DATA_MASK             0xfff0

#define AI_CLK_BASE_10M          (10*1000*1000)    // 10MHz clock 
#define AI_CLK_BASE_1M           (1*1000*1000)     // 1MHz clock

#define AI_MAX_PACER             (30*1000)         // 30KHz, PCM-3718 max samping rate
#define AI_MAX_PACER_H           (100*1000)        // 100KHz, PCM-3718H,HG,HO max samping rate

#define AI_FIFO_SIZE             1024                 // Ai fifo size in samples.
#define AI_CHK_DMA_PERIOD_MS     5

#define AI_GAIN_V_Neg5To5          0
#define AI_GAIN_V_Neg2pt5To2pt5    1
#define AI_GAIN_V_Neg1pt25To1pt25  2
#define AI_GAIN_mV_Neg625To625     3
#define AI_GAIN_V_Neg10To10        8
#define AI_GAIN_V_0To10            4
#define AI_GAIN_V_0To5             5
#define AI_GAIN_V_0To2pt5          6
#define AI_GAIN_V_0To1pt25         7

// FAI xfer mode, 0 is auto by driver, 1 is DMA, 2 is Interrupt
#define FAI_XFER_AUTO            0
#define FAI_XFER_DMA             1
#define FAI_XFER_INT             2

#define SAI_TIMEOUT_VAL          1000  // 1000ms time-out value for each sample reading.
#define SAI_DELAY_TIME           20    // 10us delay before reading data

#define AO_CHL_COUNT             1
#define AO_CHL_MASK              (AO_CHL_COUNT - 1)
#define AO_RES_IN_BIT            12
#define AO_DATA_SIZE             sizeof(__u16)
#define AO_DATA_MASK             0x0fff
#define AO_EXT_REF_UNIPOLAR      10

#define AO_MAX_PACER       (1000)        // 1KHz
#define AO_MIN_PACER       (0)
#define AO_CLK_BASE        (0)           // no clock 
#define AO_FIFO_SIZE       (0)          

#define AO_GAIN_V_0To5           0
#define AO_GAIN_V_0To10          1
#define AO_GAIN_V_EXTUNIPOLAR    2

#define DIO_PORT_COUNT           2
#define DIO_CHL_COUNT            (DIO_PORT_COUNT * 8)

#define CNTR_CHL_COUNT           1
#define CNTR_RES_IN_BIT          16
#define CNTR_DATA_SIZE           sizeof(__u16)
#define CNTR_MIN_VAL             2
#define CNTR_MAX_VAL             65535
#define CNTR_CLK_BASE            (100 * 1000)
#define CNTR_IDLE                0
#define CNTR_RBUF_DEPTH          16
#define CNTR_RBUF_POSMASK        (CNTR_RBUF_DEPTH -1)
#define CNTR_CHK_PERIOD_NS       10000000UL
#define CNTR_CHK_PERIOD_MAX_NS   625000000UL  // 10000000000UL >> 4
#define CNTR_VAL_THRESHOLD_BASE  10

#define Jtype_Gain   100
#define Ktype_Gain   101
#define Ttype_Gain   102
#define Etype_Gain   103
#define Rtype_Gain   104
#define Stype_Gain   105
#define Btype_Gain   106

enum KRNL_EVENT_IDX{
   KdxDevPropChged = 0,
   KdxAiDataReady,
   KdxAiOverrun,
   KdxAiStopped,
   KdxAiCacheOverflow,
   KrnlSptedEventCount,
};

static inline __u32 GetEventKIndex(__u32 eventType)
{
   __u32 kdx;
   switch ( eventType )
   {
   case EvtPropertyChanged:         kdx = KdxDevPropChged;    break;
   case EvtBufferedAiDataReady:     kdx = KdxAiDataReady;     break;
   case EvtBufferedAiOverrun:       kdx = KdxAiOverrun;       break;
   case EvtBufferedAiStopped:       kdx = KdxAiStopped;       break;
   case EvtBufferedAiCacheOverflow: kdx = KdxAiCacheOverflow; break;
   default: kdx = -1; break;
   }
   return kdx;
}

// -----------------------------------------------------
// default values
// -----------------------------------------------------
#define DEF_INIT_ON_LOAD        1

// AI default values
#define DEF_AI_BASE_CLK         AI_CLK_BASE_1M
#define DEF_AI_USE_FIFO         1  // if card is PCM3817HO, you can choose use FIFO or not
#define DEF_AI_XFER_MODE        FAI_XFER_AUTO  // FAI xfer mode, 0 is auto by driver, 1 is DMA, 2 is Interrupt
#define DEF_TERMBORAD_TYPE      PCLD8115
#define DEF_AI_CHTYPE           0 // single-ended
#define DEF_AI_GAIN             AI_GAIN_V_Neg10To10
#define DEF_FAI_CHSTART         0
#define DEF_FAI_CHCOUNT         1
#define DEF_FAI_CLKSRC          SigInternalClock
#define DEF_FAI_PACERDIVISOR    (100 * 100)
#define DEF_FAI_SECTSIZE        (AI_FIFO_SIZE / 2)
#define DEF_FAI_MODE            0
#define DEF_CJC_CHAN            AI_CHL_COUNT
#define DEF_CJC_FREQ            2
#define DEF_CJC_VAL             25

// AO default values
#define DEF_AO_GAIN             AO_GAIN_V_0To5
#define DEF_AO_EXT_REF_UNIPOLAR 10
#define DEF_AO_INIT_STATE       0

// DIO default values
#define DEF_DO_STATE            0

// CNTR default values
#define DEF_CNTR_CHIP_CLKSRC    SigInternalClock
#define DEF_CNTR_CHIP_LOADVAL   ((1 << CNTR_RES_IN_BIT) - 1)
#define DEF_CNTR_CHIP_OPMODE    0
#define DEF_CNTR_OST_CLKSRC     SigInternalClock
#define DEF_CNTR_OST_DELAYCNT   ((1 << CNTR_RES_IN_BIT) - 1)
#define DEF_CNTR_TMR_DIVISOR    (CNTR_CLK_BASE / 200)
#define DEF_CNTR_FM_PERIOD      0

// ----------------------------------------------------------
// Device private data
// ----------------------------------------------------------
typedef struct _FAI_CONFIG
{
   __u32  XferMode;
   __u32  ScanClkSource;       
   __u32  PhyChanStart;
   __u32  LogChanCount;
   __u32  ConvClkSource;
   double ConvClkRatePerCH;
   __u32  PacerDivider;
   __u32  SectionSize;
   __u32  SampleCount;

} FAI_CONFIG;

typedef struct _FAI_STATUS
{
   __u32  AcqMode;
   __u32  FnState;
   __u32  BufState;
   __u32  BufLength;
   __u32  WPRunBack;
   __u32  WritePos;
   __u32  ReadPos;
   __u32  IsCacheOverflow;
   __u32  DmaComnBufWritePos;  
   __u32  DmaComnBufReadPos;   
   __u32  DmaMapCount;         
   __u32  OvrnOffset;
   __u32  OvrnCount;
} FAI_STATUS;


typedef struct _CNTR_CONFIG
{
   // --------------------------------------------------------
   __u32  ChipClkSource[CNTR_CHL_COUNT];
   __u32  ChipOpMode[CNTR_CHL_COUNT];
   __u32  ChipLoadValue[CNTR_CHL_COUNT];

   // --------------------------------------------------------
   __u32  OstClkSource[CNTR_CHL_COUNT];
   __u32  OstDelayCount[CNTR_CHL_COUNT];
   // --------------------------------------------------------
   __u32  TmrDivisor[CNTR_CHL_COUNT];
   // --------------------------------------------------------
   __u32  FmPeroid[CNTR_CHL_COUNT];
} CNTR_CONFIG;

typedef struct _CNTR_STATE
{
   __u32     Operation;
   __u32     CanRead;
   __u32     AutoAdaptive;

   // ------------------------------------------
   __u32     CheckPeriod;
   __u32     Overflow;
   __u32     PrevValue;
   __u32     SummedValue;
   __s64     PrevTime;
   __u64     TotalTime;
   struct  {
      __u32  Head;
      __u32  Tail;
      __u32  CntrDelta[CNTR_RBUF_DEPTH];
      __u32  TimeDelta[CNTR_RBUF_DEPTH];
   };
} CNTR_STATE;

typedef struct _DEVICE_SHARED
{
   __u32       Size;           // Size of the structure
   __u32       ProductId;      // Device Type
   __u32       DeviceNumber;   // Zero-based device number
   __u32       HardwareVer;

   // HW Information
   __u32       BoardId;        // Board dip switch number for the device
   __u32       IoBase;
   __u32       IoLength;
   __u32       Irq;
   __u32       DeviceRegLen;
   __u32       InterruptConnected;   // if the interrupt connected or not
   __u32       InitOnLoad;
   __u32       DmaChan;        // Dma channel number, set by hardware jumper

   // --------------------------------------------------------
   __u32       AiTimeBase;    // Time base for AI convert clock, 10M or 1M, set by hardware jumper
   __u32       EnableFifoOf3718HO; //Whether use FIFO for PCM-3718HO, 0: do not use, 1: use, set by hardware jumper
   __u32       FAIXferMode; 
   __u8        AiChanType[AI_CHL_COUNT];
   __u8        AiChanGain[AI_CHL_COUNT];
   __u32       AiLogChanCount;
   FAI_CONFIG  FaiParam;
   FAI_STATUS  FaiStatus;

   // ---------------------------------------------------------
   __u32       AoChanGain[AO_CHL_COUNT];
   double      AoExtRefUnipolar;
   __u16       AoChanState[AO_CHL_COUNT];

   __u32       TermBoardType;
   __u32       CjcChan;
   double      CjcValue;
   double      CjcUpdateFreq;
   // ---------------------------------------------------------
   __u8        DoPortState[DIO_PORT_COUNT];

   // ---------------------------------------------------------
   CNTR_CONFIG CntrConfig;
   CNTR_STATE  CntrState[CNTR_CHL_COUNT];
   __u32       CntrChkTimerOwner;

   // ---------------------------------------------------------
   __u32       IsEvtSignaled[KrnlSptedEventCount];

   PACER_CTRL_REG  ClkReg; //The device register can't be read back, save it here to simulate a readable register, to be used for avoiding conflict of FAI & counter
} DEVICE_SHARED;

#endif /* KERNEL_MODULE_SHARED_H_ */
