/*
 * hw.h
 *
 *  Created on: 2013-6-30
 *      Author: 
 */

#ifndef _KERNEL_MODULE_HW_H_
#define _KERNEL_MODULE_HW_H_

// device register : AI Data
#define DR_AI_DATA        0x0
#define DR_AI_SWTRIG      0x0

typedef union _AI_CHL_CTL{
   __u8 Value;
   struct{
      __u8 Gain  : 5;
      __u8 CHType: 1;
      __u8 unused: 2;
   };
}AI_CHL_CTL;
#define DR_AI_CHCTL       0x2

#define DR_AI_MUX         0x4

#define DEV_CTL_SW_TRIG   1

typedef union _DEV_CTL{
   __u8 Value;
   struct{
	   __u8 SwTrig      : 1;
	   __u8 PcrTrig     : 1;
	   __u8 ExtTrig     : 1;
	   __u8 ExtTrigGate : 1;
	   __u8 IrqEn       : 1;
	   __u8 IntHF       : 1;
	   __u8 Cntr0Clk    : 1;
	   __u8 unused1     : 1;
   };
}DEV_CTL;

#define DR_DEV_CTL        0x6

typedef union _DEV_STA{
   __u8 Value;
   struct{
	   __u8 FifoEmpty   : 1;
	   __u8 FifoHalf    : 1;
	   __u8 FifoFull    : 1;
	   __u8 IntFlag     : 1;
	   __u8 unused2     : 4;
   };
}DEV_STA;
#define DR_DEV_STA        0x7

#define DR_CLR_INTR       0x8
#define DR_CLR_FIFO       0x9

#define DR_AO_DATA_BASE   0xA
#define DR_AO_CHAN(ch)    (DR_AO_DATA_BASE + ch * 2)

typedef union _AO_CHL_CSR{
   __u8 Value;
   struct{
      __u8 CH0_Gain : 3;
      __u8 CH0_Gate : 1;
      __u8 unused   : 4;
   };
}AO_CHL_CSR;
#define DR_AO_CHCSR        0xE

#define DR_DI_BASE         0x10
#define DR_DI_PORTX(x)     (DR_DI_BASE + x)

#define DR_DO_BASE         0x10
#define DR_DO_PORTX(x)     (DR_DO_BASE + x)

#define DR_CNTR0           0x18
#define DR_CNTR1           0x1A
#define DR_CNTR2           0x1C
#define DR_CNTR_CTL        0x1E


// For HW ver. >= 0xC100
#define DR_BID             0x14


#endif /* _KERNEL_MODULE_HW_H_ */
