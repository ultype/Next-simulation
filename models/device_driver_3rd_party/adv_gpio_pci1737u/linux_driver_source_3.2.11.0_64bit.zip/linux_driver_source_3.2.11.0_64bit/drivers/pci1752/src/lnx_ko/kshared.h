/*
 * kshared.h
 *
 * Created on: October 7, 2012
 * Author: 
 */

#ifndef KERNEL_MODULE_SHARED_H_
#define KERNEL_MODULE_SHARED_H_

#include <linux/types.h>


#define ADVANTECH_VID 0x13fe
#define DEVICE_ID     0x1752
#define DEVICE_PID    BD_PCI1752
#define DEVICE_NAME   "PCI-1752"
#define DRIVER_NAME   "bio1752"

// ----------------------------------------------------------
// H/W feature and structures.
// ----------------------------------------------------------
#define DIO_PORT_COUNT		   8  // 8 isolated DO
#define DIO_CHL_COUNT         (DIO_PORT_COUNT * 8)


enum KRNL_EVENT_IDX{
   KdxDevPropChged = 0,
   KrnlSptedEventCount,
};

static inline __u32 GetEventKIndex(__u32 eventType)
{
   __u32 kdx;
   switch ( eventType )
   {
   case EvtPropertyChanged: kdx = KdxDevPropChged; break;
   default: kdx = -1; break;
   }
   return kdx;
}


// -----------------------------------------------------
// default values
// -----------------------------------------------------
#define DEF_INIT_ON_LOAD   1

// DIO default values
#define DEF_DO_STATE       0
#define DEF_DO_FRZ_EN      0


// ----------------------------------------------------------
// Device private data
// ----------------------------------------------------------

typedef struct _DEVICE_SHARED
{
   __u32   Size;           // Size of the structure
   __u32   ProductId;      // Device Type
   __u32   DeviceNumber;   // Zero-based device number

   // HW Information
   __u32   BoardId;        // Board dip switch number for the device
   __u32   BusNumber;      // PCI Bus number
   __u32   SlotNumber;     // PCI Slot number
   __u32   IoBase;
   __u32   IoLength;
   __u32   Irq;
   __u32   InitOnLoad;

   // --------------------------------------------------------
   __u32   DoFreezeEn;
   __u8    DoPortState[DIO_PORT_COUNT];

} DEVICE_SHARED;

#endif /* KERNEL_MODULE_SHARED_H_ */
