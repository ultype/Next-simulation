/*
 * usbfunc.c
 *
 *  Created on: 2011-8-31
 *      Author: rocky
 */
#include <linux/usb.h>
#include "kdriver.h"

// -----------------------------------------------------------------------------------------
//
// -----------------------------------------------------------------------------------------
#define DO_CTRL_XFER_LOCKED(daq_dev, _expr_) \
   ({\
      int __xret;\
      mutex_lock(&daq_dev->ctrl_pipe_lock);\
      if (likely(daq_dev->udev)){\
         __xret = _expr_;\
      } else {\
         __xret = -ENODEV;\
      }\
      mutex_unlock(&daq_dev->ctrl_pipe_lock);\
      __xret;\
   })



static inline
int __daq_usb_control_in_index(daq_device_t *daq_dev, __u8 major, __u16 minor, __u16 index, void *data, __u16 size)
{
   int ret;
   if (WARN(size > CTRL_XFER_MAXLEN, "Control transfer length exceeds the limiation")) {
      return -EINVAL;
   }

   ret = usb_control_msg(daq_dev->udev, usb_rcvctrlpipe(daq_dev->udev, 0),
            major, USB_DIR_IN | USB_TYPE_VENDOR | USB_RECIP_DEVICE,
            minor, index, daq_dev->ctrl_xfer_buff, size, USB_CTRL_GET_TIMEOUT);

   if (ret > 0) {
      memcpy(data, daq_dev->ctrl_xfer_buff, size);
   }

   return ret;
}

static inline
int __daq_usb_control_in(daq_device_t *daq_dev, __u8 major, __u16 minor, void *data, __u16 size)
{
   return __daq_usb_control_in_index(daq_dev, major, minor, 0, data, size);
}

static inline
int __daq_usb_control_out_index(daq_device_t *daq_dev, __u8 major, __u16 minor, __u16 index, void *data, __u16 size)
{
   if (WARN(size > CTRL_XFER_MAXLEN, "Control transfer length exceeds the limiation")) {
      return -EINVAL;
   }

   memcpy(daq_dev->ctrl_xfer_buff, data, size);
   return usb_control_msg(daq_dev->udev, usb_sndctrlpipe(daq_dev->udev, 0),
            major, USB_DIR_OUT | USB_TYPE_VENDOR | USB_RECIP_DEVICE,
            minor, index, daq_dev->ctrl_xfer_buff, size,  USB_CTRL_SET_TIMEOUT);
}

static inline
int __daq_usb_control_out(daq_device_t *daq_dev, __u8 major, __u16 minor, void *data, __u16 size)
{
   return __daq_usb_control_out_index(daq_dev, major, minor, 0, data, size);
}

// -----------------------------------------------------------------------------------------
//
// -----------------------------------------------------------------------------------------
int daq_usb_dev_get_firmware_ver(daq_device_t *daq_dev, char ver[], int len)
{
   return DO_CTRL_XFER_LOCKED(daq_dev,
            __daq_usb_control_in(daq_dev, MAJOR_SYSTEM, MINOR_GET_FW_VERSION, ver, len));
}

int daq_usb_dev_init_firmware(daq_device_t *daq_dev, int is_open)
{
   __u32 dummy = 0; // Unused, but firmware required.

   return DO_CTRL_XFER_LOCKED(daq_dev,
            __daq_usb_control_out(daq_dev, MAJOR_SYSTEM,
               is_open ? MINOR_DEVICE_OPEN : MINOR_DEVICE_CLOSE, &dummy, sizeof(dummy)));
}

int daq_usb_dev_locate_device(daq_device_t *daq_dev, __u8 enable)
{
   __u32 dummy = 0;

   return DO_CTRL_XFER_LOCKED(daq_dev,
            __daq_usb_control_out(daq_dev, MAJOR_SYSTEM, MINOR_LOCATE, &dummy, sizeof(dummy)));
}

int daq_usb_dev_get_board_id(daq_device_t *daq_dev, __u32 *id)
{
   int ret = DO_CTRL_XFER_LOCKED(daq_dev,
               __daq_usb_control_in(daq_dev, MAJOR_SYSTEM, MINOR_READ_SWITCHID, id, sizeof(__u32)));
   *id &= 0xf;

   return ret;
}

int daq_usb_dev_set_board_id(daq_device_t *daq_dev, __u32 id)
{
   return DO_CTRL_XFER_LOCKED(daq_dev,
            __daq_usb_control_out(daq_dev, MAJOR_SYSTEM, MINOR_WRITE_SWITCHID, &id, sizeof(__u32)));
}

int daq_usb_read_eeprom(daq_device_t *daq_dev, __u16 addr, __u32 buflen, void *buffer)
{
   return DO_CTRL_XFER_LOCKED(daq_dev,
            __daq_usb_control_in_index(daq_dev, MAJOR_DIRECT_IO, MINOR_DIRECT_READ, addr, buffer, buflen));
}

int daq_usb_write_eeprom(daq_device_t *daq_dev, __u16 addr, __u32 buflen, void *buffer)
{
   return DO_CTRL_XFER_LOCKED(daq_dev,
            __daq_usb_control_out_index(daq_dev, MAJOR_DIRECT_IO, MINOR_DIRECT_WRITE, addr, buffer, buflen));
}

int daq_usb_dev_dbg_input(daq_device_t *daq_dev, __u16 majorCmd, __u16 minorCmd, __u32 dataSize, void *data)
{
   return DO_CTRL_XFER_LOCKED(daq_dev,
             __daq_usb_control_in(daq_dev, majorCmd, minorCmd, data, dataSize));
}

int daq_usb_dev_dbg_output(daq_device_t *daq_dev, __u16 majorCmd, __u16 minorCmd, __u32 dataSize, void *data)
{
   return DO_CTRL_XFER_LOCKED(daq_dev,
             __daq_usb_control_out(daq_dev, majorCmd, minorCmd, data, dataSize));
}

int daq_usb_dev_get_flag(daq_device_t *daq_dev, __u32 *flag)
{
   return DO_CTRL_XFER_LOCKED(daq_dev,
             __daq_usb_control_in(daq_dev, MAJOR_SYSTEM, MINOR_GET_USB_FLAG, flag, sizeof(__u32)));
}

// -----------------------------------------------------------------------------------------
//
// -----------------------------------------------------------------------------------------
int daq_usb_dio_get_port_mode(daq_device_t *daq_dev, __u32 group, DIO_GRP_CTRL_REG *mode)
{
   return daq_usb_read_eeprom(daq_dev, EEAddrDioGrp0Mode + group, sizeof(DIO_GRP_CTRL_REG), mode);
}

int daq_usb_dio_set_port_mode(daq_device_t *daq_dev, __u32 group, DIO_GRP_CTRL_REG *mode)
{
   return daq_usb_write_eeprom(daq_dev, EEAddrDioGrp0Mode + group, sizeof(DIO_GRP_CTRL_REG), mode);
}

int daq_usb_di_read_port(daq_device_t *daq_dev, __u32 start, __u32 count, __u8 *data)
{
   BioUsbDI_TX tx = { 0, sizeof(__u32) };
   BioUsbDI_RX rx = { 0 };
   int ret = 0;
   return DO_CTRL_XFER_LOCKED(daq_dev,\
   ({
      while (count--){
         tx.Channel = start++;
         ret = __daq_usb_control_out(daq_dev, MAJOR_DIO, MINOR_DI_TX, &tx, sizeof(tx));
         if (ret < 0) break;

         ret = __daq_usb_control_in(daq_dev, MAJOR_DIO, MINOR_DI_RX, &rx, sizeof(rx));
         if (ret < 0) break;
         *data++ = (__u8)rx.Data;
         start %= DIO_PORT_COUNT(daq_dev->shared.ProductId);
      }
      ret;
   }));
}

int daq_usb_do_write_port(daq_device_t *daq_dev, __u32 start, __u32 count, __u8 *data)
{
   BioUsbDO tx  = {0, sizeof(__u32)};
   int      ret = 0;

   return DO_CTRL_XFER_LOCKED(daq_dev,\
   ({
      while (count--){
         tx.Channel = start++;
         tx.Data    = *data++;
         ret = __daq_usb_control_out(daq_dev, MAJOR_DIO, MINOR_DO, &tx, sizeof(tx));
         if (ret < 0) break;
         start %= DIO_PORT_COUNT(daq_dev->shared.ProductId);
      }
      ret;
   }));
}

int daq_usb_do_read_port(daq_device_t *daq_dev, __u32 start, __u32 count, __u8 *data)
{
   BioUsbDORead_TX tx = { 0, sizeof(__u32) };
   BioUsbDORead_RX rx = { 0 };
   int             ret= 0;

   return DO_CTRL_XFER_LOCKED(daq_dev,\
   ({
      while (count--){
         tx.Channel = start++;
         ret = __daq_usb_control_out(daq_dev, MAJOR_DIO, MINOR_DO_READ_TX, &tx, sizeof(tx));
         if (ret < 0) break;

         ret = __daq_usb_control_in(daq_dev, MAJOR_DIO, MINOR_DO_READ_RX, &rx, sizeof(rx));
         if (ret < 0) break;
         *data++ = (__u8)rx.Data;
         start %= DIO_PORT_COUNT(daq_dev->shared.ProductId);
      }
      ret;
   }));
}

int daq_usb_enable_hw_event(daq_device_t *daq_dev, __u32 src_idx, int enable, __u8 gate_ctrl, __u8 trig_edge)
{
   if (enable) {
      __u32 curGate, curTrig;
      daq_usb_read_eeprom(daq_dev, EEAddrDioPC0IntMode + src_idx, sizeof(curGate), &curGate);
      daq_usb_read_eeprom(daq_dev, EEAddrDioPC0TrigMode+ src_idx, sizeof(curTrig), &curTrig);

      if (curGate != gate_ctrl) {
         curGate = gate_ctrl;
         daq_usb_write_eeprom(daq_dev, EEAddrDioPC0IntMode + src_idx, sizeof(curGate), &curGate);
      }
      if (curTrig != trig_edge) {
         curTrig = trig_edge;
         daq_usb_write_eeprom(daq_dev, EEAddrDioPC0TrigMode+ src_idx, sizeof(curTrig), &curTrig);
      }
   }

   {
      BioUsbEnableEvent tx = { (__u16)src_idx + FWEvtDIIntr16, (__u16)enable, trig_edge};

      return DO_CTRL_XFER_LOCKED(daq_dev,
               __daq_usb_control_out(daq_dev, MAJOR_EVENT, MINOR_EVENT_ENABLE, &tx, sizeof(tx)));
   }
}

// -----------------------------------------------------------------------------------------
//
// -----------------------------------------------------------------------------------------
int daq_usb_cntr_get_base_clk(daq_device_t *daq_dev, __u32 *baseClk)
{
   return DO_CTRL_XFER_LOCKED(daq_dev,
            __daq_usb_control_in(daq_dev, MAJOR_COUNTER, MINOR_CNT_GET_BASECLK, baseClk, sizeof(__u32)));
}

int daq_usb_cntr_reset(daq_device_t *daq_dev, __u32 counter)
{
   BioUsbCounterReset tx = { (__u16)counter };

   return DO_CTRL_XFER_LOCKED(daq_dev,
            __daq_usb_control_out(daq_dev, MAJOR_COUNTER, MINOR_CNT_RESET, &tx, sizeof(tx)));
}

int daq_usb_cntr_start_event_count(daq_device_t *daq_dev, __u32 counter)
{
   BioUsbCounterEventStart tx = { (__u16)counter };

   return DO_CTRL_XFER_LOCKED(daq_dev,
            __daq_usb_control_out(daq_dev, MAJOR_COUNTER, MINOR_CNT_EVENTSTART, &tx, sizeof(tx)));
}

int daq_usb_cntr_read_event_count(daq_device_t *daq_dev, __u32 counter, __u32 *cntrValue, struct timespec *timeStamp)
{
   BioUsbCounterEventRead_TX tx = { (__u16)counter };
   BioUsbCounterEventRead_RX rx;
   int ret = 0;

   rx.Count = 0;
   return DO_CTRL_XFER_LOCKED(daq_dev,\
   ({
      do{
         ret = __daq_usb_control_out(daq_dev, MAJOR_COUNTER, MINOR_CNT_EVENTREAD_TX, &tx, sizeof(tx));
         if (ret < 0) break;

         ret = __daq_usb_control_in(daq_dev, MAJOR_COUNTER, MINOR_CNT_EVENTREAD_RX, &rx, sizeof(rx));
         if (ret < 0) break;

         *cntrValue = rx.Count;
         getnstimeofday(timeStamp);
      }while(0);
      ret;
   }));
}

int daq_usb_cntr_start_freq_measure(daq_device_t *daq_dev, __u32 counter)
{
   BioUsbFrequencyStart tx = { (__u16)counter, {2000} };

   return DO_CTRL_XFER_LOCKED(daq_dev,
            __daq_usb_control_out(daq_dev, MAJOR_COUNTER, MINOR_CNT_FREQSTART, &tx, sizeof(tx)));

}

int daq_usb_cntr_read_freq_measure(daq_device_t *daq_dev, __u32 counter, BioUsbFrequencyRead_RX *rx)
{
   BioUsbFrequencyRead_TX tx = { (__u16)counter };
   int ret = 0;

   return DO_CTRL_XFER_LOCKED(daq_dev,\
   ({
      do{
         ret = __daq_usb_control_out(daq_dev, MAJOR_COUNTER, MINOR_CNT_FREQ_READ_TX, &tx, sizeof(tx));
         if (ret < 0) break;

         ret = __daq_usb_control_in(daq_dev, MAJOR_COUNTER, MINOR_CNT_FREQ_READ_RX, rx, sizeof(*rx));
      }while(0);
      ret;
   }));
}

int daq_usb_cntr_start_timer_pulse(daq_device_t *daq_dev, __u32 counter, __u32 divisor)
{
   BioUsbPulseStart tx;

   tx.Counter    = (__u16)counter;
   tx.Context[0] = divisor >> 16;
   tx.Context[2] = divisor & 0xffff;
   tx.Context[1] = tx.Context[2] / 2;

   return DO_CTRL_XFER_LOCKED(daq_dev,
             __daq_usb_control_out(daq_dev, MAJOR_COUNTER, MINOR_CNT_PULSESTART, &tx, sizeof(tx)));
}

int daq_usb_cntr_start_pw_modulate(daq_device_t *daq_dev, __u32 counter, __u32 hiDivisor, __u32 loDivisor)
{
   BioUsbPwmSetting tx;
   BioUsbPwmEnable  enable = { counter, {0}};

   __u32 divisor = hiDivisor + loDivisor;
   __u64 upCycle;
   int   ret;

   tx.Counter    = (__u16)counter;
   tx.Context[0] = divisor >> 16;
   if (tx.Context[0] > 255) {
      tx.Context[0] = 255;
   }

   tx.Context[2] = x_max(divisor / (tx.Context[0] + 1), 2U);
   if (tx.Context[2] > 65535) {
      tx.Context[2] = 65535;
   }

   upCycle = (__u64)hiDivisor * tx.Context[2];
   do_div(upCycle, divisor);
   tx.Context[1] = upCycle;

   return DO_CTRL_XFER_LOCKED(daq_dev,\
   ({
      do{
         ret = __daq_usb_control_out(daq_dev, MAJOR_COUNTER, MINOR_CNT_PWMSETTING, &tx, sizeof(tx));
         if (ret < 0) break;

         ret = __daq_usb_control_in(daq_dev, MAJOR_COUNTER, MINOR_CNT_PWMENABLE, &enable, sizeof(enable));
      }while(0);
      ret;
   }));
}



















