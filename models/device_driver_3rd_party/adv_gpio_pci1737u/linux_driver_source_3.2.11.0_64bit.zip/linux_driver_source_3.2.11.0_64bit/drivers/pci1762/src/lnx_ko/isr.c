/*
 * isr.c
 *
 *  Created on: July 7, 2012
 *      Author: rocky
 */
#include "kdriver.h"
#include "hw.h"

// -----------------------------------------------------------------------------
// Must hold the lock when call this function.
void daq_dio_tasklet_func(unsigned long arg)
{
   daq_device_t  *daq_dev = (daq_device_t *) arg;
   DEVICE_SHARED *shared  = &daq_dev->shared;
   unsigned long flags;
   __u32         int_state, ch;

   // Copy the interrupt state to local cache to avoid impose the interrupt handler.
   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   int_state = shared->DiIntState & 0x101;
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

   // check interrupt state
   for (ch = 0; int_state; int_state >>= 8, ++ch) {
      if (int_state & 0x1) {
          if (shared->DiSnapParam[ch].PortCount) {
	      __u32 i;
              for ( i = 0; i < DIO_PORT_COUNT; ++i )
              {
                 shared->DiSnapState[ch].State[i] = AdxIoInB(shared->IoBase, DR_DI_PORTX(i));
              }
          }

          // signal the event if needed.
          if (!shared->IsEvtSignaled[ch + KdxDiBegin]) {
             shared->IsEvtSignaled[ch + KdxDiBegin] = 1;
             daq_device_signal_event(daq_dev, ch + KdxDiBegin);
          }
      }
   }
}

irqreturn_t daq_irq_handler(int irq, void *dev_id)
{
   daq_device_t  *daq_dev = (daq_device_t *) dev_id;
   DEVICE_SHARED *shared  = &daq_dev->shared;

   __u32 int_states = AdxIoInW(shared->IoBase, DR_IntBase);
   if (!(int_states & 0x101)) {
      return IRQ_RETVAL(0);
   }

   spin_lock(&daq_dev->dev_lock);
   shared->DiIntState = int_states;
   spin_unlock(&daq_dev->dev_lock);

   tasklet_schedule(&daq_dev->dio_tasklet);
   // Clear interrupt
   AdxIoOutW(shared->IoBase, DR_IntBase, (__u16)int_states);

   return IRQ_RETVAL(1);
}

