/*
 * kshared.h
 *
 *  Created on: July 7, 2012 
 *      Author: rocky
 */

#ifndef KERNEL_MODULE_SHARED_H_
#define KERNEL_MODULE_SHARED_H_

#include <linux/types.h>


#define ADVANTECH_VID 0x13fe
#define DEVICE_ID     0x1762
#define DEVICE_PID    BD_PCI1762
#define DEVICE_NAME   "PCI-1762"
#define DRIVER_NAME   "bio1762"

// ----------------------------------------------------------
// H/W feature and structures.
// ----------------------------------------------------------
#define DIO_PORT_COUNT		 2 // 2 isolated DI, 2 Relay DO
#define DIO_CHL_COUNT            (DIO_PORT_COUNT * 8)
#define DI_INT_SRC_COUNT         2  // CH#000 & CH#008
#define DI_INT_SRC_CTL_MASK      0x0303
#define DI_SNAP_SRC_COUNT        DI_INT_SRC_COUNT


enum KRNL_EVENT_IDX{
   KdxDevPropChged = 0,
   KdxDiBegin,
   KdxDiintChan0 = KdxDiBegin,
   KdxDiintChan8,
   KdxDiEnd = KdxDiintChan8,
   KrnlSptedEventCount,
};

static inline __u32 GetEventKIndex(__u32 eventType)
{
   __u32 kdx;
   switch ( eventType )
   {
   case EvtPropertyChanged: kdx = KdxDevPropChged; break;
   case EvtDiintChannel000: kdx = KdxDiintChan0; break;
   case EvtDiintChannel008: kdx = KdxDiintChan8; break;
   default: kdx = -1; break;
   }
   return kdx;
}


// -----------------------------------------------------
// default values
// -----------------------------------------------------
#define DEF_INIT_ON_LOAD        1

// DIO default values
#define DEF_DO_STATE            0
#define DEF_DIINT_TRIGEDGE      RisingEdge


// ----------------------------------------------------------
// Device private data
// ----------------------------------------------------------
typedef struct _DI_SNAP_CONFIG
{
   __u8 PortStart;
   __u8 PortCount;
} DI_SNAP_CONFIG;

typedef struct _DI_SNAP_STATE
{
   __u8 State[DIO_PORT_COUNT];
} DI_SNAP_STATE;

typedef struct _DEVICE_SHARED
{
   __u32       Size;           // Size of the structure
   __u32       ProductId;      // Device Type
   __u32       DeviceNumber;   // Zero-based device number

   // HW Information
   __u32       BoardId;        // Board dip switch number for the device
   __u32       BusNumber;      // PCI Bus number
   __u32       SlotNumber;     // PCI Slot number
   __u32       IoBase;
   __u32       IoLength;
   __u32       Irq;
   __u32       InitOnLoad;

   // --------------------------------------------------------
   __u8        DoPortState[DIO_PORT_COUNT];
   __u8        DiintTrigEdge[DI_INT_SRC_COUNT];
   DI_SNAP_CONFIG DiSnapParam[DI_SNAP_SRC_COUNT];
   DI_SNAP_STATE  DiSnapState[DI_SNAP_SRC_COUNT];

   // ---------------------------------------------------------
   __u32       DiIntState;
   __u32       IsEvtSignaled[KrnlSptedEventCount];

} DEVICE_SHARED;

#endif /* KERNEL_MODULE_SHARED_H_ */
