/*
 * hw.h
 *
 *  Created on: 2015-06-10
 *      Author: 
 */

#ifndef _KERNEL_MODULE_HW_H_
#define _KERNEL_MODULE_HW_H_

#define INTERNAL_CLOCK           0
#define EXTERNAL_CLOCK           1

#define RISING_EDGE              0
#define FALLING_EDGE             1

#define PORTDIR_OUT              0  
#define PORTDIR_IN               1    

#define TRG_FN_DISABLED          0
#define TRG_FN_START             1
#define TRG_FN_STOP              2       
#define TRG_FN_PAUSE             3       

#define CONV_CLK_INTERN          0       
#define CONV_CLK_EXTERN          1    

#define SCAN_CLK_INTERN          0       
#define SCAN_CLK_EXT_SCAN        2       
#define SCAN_CLK_EXT_CONV        3       

#define CAL_AI_TRG0_ANA_HYS      0xE
#define CAL_AI_TRG1_ANA_HYS      0xF

#define CAL_AI_TRG0_ANA_THD      0x60
#define CAL_AI_TRG1_ANA_THD      0x61

#define CAL_AI_TRG0_ANA_THD_HEADER  0x1000
#define CAL_AI_TRG1_ANA_THD_HEADER  0x5000

#define CAL_LOAD_RAM_TO_TRIMDAC  0x70
#define CAL_LOAD_EEPROM_TO_RAM   0x71


#define AO_GAIN_0To5V            0
#define AO_GAIN_0To10V           1
#define AO_GAIN_Neg5To5V         2
#define AO_GAIN_Neg10To10V       3
#define AO_GAIN_EXT_UNI          4
#define AO_GAIN_EXT_BI           6


#define CT_GMOD_NOGATE           0       
#define CT_GMOD_LAVEL            1      
#define CT_GMOD_EDGE             2       
#define CT_GMOD_RETRIGGER        3       

#define CT_GSRC_EXTERN           0       
#define CT_GSRC_2KHZ             4       
#define CT_GSRC_200HZ            5       
#define CT_GSRC_20HZ             6       
#define CT_GSRC_2HZ              7       

#define CT_OMD_ACTIVEHIGH        0      
#define CT_OMD_ACTIVELOW         1      
#define CT_OMD_TOGGLELOW         2      
#define CT_OMD_TOGGLEHIGH        3      

#define CT_CLK_EXTERN         0       
#define CT_CLK_20MHZ             4       
#define CT_CLK_2MHz              5       
#define CT_CLK_200KHZ            6       
#define CT_CLK_20KHZ             7       

#define CT_OMD_ACTIVEHIGH        0       
#define CT_OMD_ACTIVELOW         1       
#define CT_OMD_TOGGLELOW         2       
#define CT_OMD_TOGGLEHIGH        3       

#define AI_INT_MASK              0x000000ff
#define AO_INT_MASK              0x0000ff00
#define DI_P0P1_INT_MASK         0x00ff0000
#define CT_INT_MASK              0x11000000
#define CT_X_INT_MASK(ch)       (0x01000000 << ((ch) * 4))

//################################################################
// Common Type Information Registers (BAR0)

typedef struct CARD_VER_R {
   volatile __u32 BID      : 4;
            __u32 ___resv0 : 12;
   volatile __u32 AID      : 8;
   volatile __u32 BARH     : 4;
            __u32 ___resv1 : 4;
   volatile __u32 PCB_VER;
   volatile __u32 PLD_VER;
   volatile __u32 FW_VER;
} CARD_VER_R;

//################################################################
// Common Type Control Registers (BAR1)

typedef union DEV_IF0_R {
   volatile __u32 xval;

   struct {
   //------------------
   volatile __u8 AI_SC   : 1;
   volatile __u8 AI_PC   : 1;
   volatile __u8 AI_EP   : 1;
   volatile __u8 AI_OF   : 1;
   volatile __u8 AI_CF   : 1;
            __u8 ___resv0: 3;

   //------------------
   volatile __u8 AO_SC   : 1;
   volatile __u8 AO_PC   : 1;
            __u8 ___resv1: 1;
   volatile __u8 AO_BE   : 1;
            __u8 ___resv2: 4;

   //------------------
   volatile __u8 DI_p0B0 : 1;
   volatile __u8 DI_p0SC : 1;
   volatile __u8 DI_p0PM : 1;
            __u8 ___resv3: 1;
   volatile __u8 DI_p1B0 : 1;
   volatile __u8 DI_p1SC : 1;
   volatile __u8 DI_p1PM : 1; 
            __u8 ___resv4: 1;

   //------------------
   volatile __u8 CT_CNT0 : 1;
            __u8 ___resv5: 3;
   volatile __u8 CT_CNT1 : 1;
   volatile __u8 ___resv6: 3;
   };
} DEV_IF0_R;


typedef union DEV_IF1_R {
   volatile __u32 xval;

   struct {
   volatile __u8 DI_p2B0  : 1;
   volatile __u8 DI_p2SC  : 1;
   volatile __u8 DI_p2PM  : 1;
   };
} DEV_IF1_R;

typedef union AC_CTL_R {
   volatile __u16 xval;

   struct {
   volatile __u8 EN     : 1;
            __u8 ___resv: 1;
   volatile __u8 CH     : 2;
   volatile __u8 GAIN   : 3;
   volatile __u8 BU     : 1;
   volatile __u8 BUSY   : 1;
   };
} AC_CTL_R;

typedef union AC_IO_R {
   volatile __u32 xval;
   struct {
      volatile __u16 DATA;
      volatile __u8  CMD;
               __u8  ___resv;
   };
} AC_IO_R;

typedef union AI_IE_R {
   volatile __u32 xval;

   struct {
   volatile __u8 SC : 1;
   volatile __u8 PC : 1;
   volatile __u8 EP : 1;
   volatile __u8 OF : 1;
   volatile __u8 CF : 1;
   };
} AI_IE_R;

typedef union AI_CTL_R {
   volatile __u32 xval;
   struct {   
   volatile __u8 POLLEN   : 1;
            __u8 ___resv0 : 3;
   volatile __u8 RTRGEN   : 1;
            __u8 ___resv1 : 3;

   volatile __u8 CCLKSRC  : 1;
            __u8 ___resv2 : 3;
   volatile __u8 SCLKSRC  : 2;
            __u8 ___resv3 : 1;
   volatile __u8 CHSCAN   : 1;

   volatile __u8 DTRG0FN  : 2;
            __u8 ___resv4 : 1;
   volatile __u8 DTRG0EDG : 1;
   volatile __u8 ATRG0FN  : 2;
            __u8 ___resv5 : 1;
   volatile __u8 ATRG0EDG : 1;

   volatile __u8 DTRG1FN  : 2;
            __u8 ___resv6 : 1;
   volatile __u8 DTRG1EDG : 1;
   volatile __u8 ATRG1FN  : 2;
            __u8 ___resv7 : 1;
   volatile __u8 ATRG1EDG : 1;
   };
} AI_CTL_R;

typedef union AI_SWTRG_R {
   volatile __u32 xval;

   struct {
   volatile __u8 SWSTA   : 1;
            __u8 ___resv0: 3;
   volatile __u8 SWSTP   : 1;
            __u8 ___resv1: 3;

   volatile __u8 SWSTAEN : 1;
            __u8 ___resv2: 3;
   volatile __u8 SWSTPEN : 1;
            __u8 ___resv3: 3;
   };
} AI_SWTRG_R;

typedef union AI_CH_R {
   volatile __u8 xval;

   struct {
   volatile __u8 GAIN   : 3;
            __u8 ___resv: 1;
   volatile __u8 BU     : 1;
   volatile __u8 SD     : 1;
   };
} AI_CH_R;

typedef union AO_IE_R {
   volatile __u32 xval;

   struct {
   volatile __u8 SC      : 1;
   volatile __u8 PC      : 1;
            __u8 ___resv0: 1;
   volatile __u8 BE      : 1;
            __u8 ___resv1: 4;

   };
} AO_IE_R;

typedef union AO_CTL_R {
   volatile __u32 xval;

   struct {
            __u8 ___resv0 : 8;

   volatile __u8 CCLKSRC  : 1;
            __u8 ___resv1 : 7;

   volatile __u8 DTRG0FN  : 2;
            __u8 ___resv2 : 1;
   volatile __u8 DTRG0EDG : 1;
   volatile __u8 ATRG0FN  : 2;
            __u8 ___resv3 : 1;
   volatile __u8 ATRG0EDG : 1;

   volatile __u8 DTRG1FN  : 2;
            __u8 ___resv4 : 1;
   volatile __u8 DTRG1EDG : 1;
   volatile __u8 ATRG1FN  : 2;
            __u8 ___resv5 : 1;
   volatile __u8 ATRG1EDG : 1;
   };
} AO_CTL_R;

typedef union AO_SWTRG_R {
   volatile __u32 xval;

   struct {
   volatile __u8 SWSTA   : 1;
            __u8 ___resv0: 3;
   volatile __u8 SWSTP   : 1;
            __u8 ___resv1: 3;

   volatile __u8 SWSTAEN : 1;
            __u8 ___resv2: 3;
   volatile __u8 SWSTPEN : 1;
            __u8 ___resv3: 3;
   };
} AO_SWTRG_R;

typedef struct AO_CH_R {
   volatile __u8 GAIN   : 3;
} AO_CH_R;

typedef struct DIO_CTL_R {
   volatile __u8 DIRL    : 1;
            __u8 ___resv0: 3;
   volatile __u8 DIRH    : 1;
            __u8 ___resv1: 3;
   volatile __u8 B0IE    : 1;
   volatile __u8 SCIE    : 1;
   volatile __u8 PMIE    : 1;
            __u8 ___resv2: 5;
   volatile __u8 LATEN   : 1;
   volatile __u8 B0EDG   : 1;
            __u8 ___resv3: 6;
            __u8 ___resv4;

   volatile __u8 PMVAL;
   volatile __u8 PMDEN;
   volatile __u8 SCDEN;
   volatile __u8 DFEN0   : 1;

   volatile __u8 LATVAL;
            __u8 ___resv5[3];
   
   volatile __u8 DFDUR;
            __u8 ___resv6[3];
} DIO_CTL_R;

typedef union CT_CMN_R {
   volatile __u32 xval;

   struct {
   volatile __u8 RST     : 1;
   volatile __u8 ARM     : 1;
            __u8 ___resv0: 6;
   volatile __u8 DFEN    : 1;
            __u8 ___resv1: 7;
   volatile __u8 DFDUR;
   };
} CT_CMN_R;

typedef union CT_CLK_R {
   volatile __u32 xval;

   struct {
   volatile __u8 SRC     : 3;
            __u8 ___resv0: 4;
   volatile __u8 POL     : 1;
   };
} CT_CLK_R;

typedef union CT_CTM_R {
   volatile __u32 xval;

   struct {
   volatile __u8 GSRC    : 3;
            __u8 ___resv0: 1;
   volatile __u8 GMOD    : 2;
            __u8 ___resv1: 1;
   volatile __u8 GPOL    : 1;
   volatile __u8 ODS     : 2;
            __u8 ___resv2: 2;
   volatile __u8 OMD     : 2;
            __u8 ___resv3: 2;
   volatile __u8 LMOD    : 1;
            __u8 ___resv4: 7;
   volatile __u8 INTEN   : 1;
            __u8 ___resv5: 3;
   volatile __u8 INFEN   : 1;
            __u8 ___resv6: 2;
   volatile __u8 OUTEN   : 1;
   };
} CT_CTM_R;

typedef union CT_FM_R {
   volatile __u32 xval;

   struct {
   volatile __u8 FMUTM   : 3;
            __u8 ___resv0: 5;
   volatile __u8 LOF     : 1;
   volatile __u8 HOF     : 1;
            __u8 ___resv1: 6;
   };
} CT_FM_R;

typedef struct CT_CTL_R {
         CT_CMN_R CMN;
         CT_CLK_R CLK;
            __u32 ___resv0[6];

   //-----------------------------
         CT_CTM_R CTM;
            __u32 ___resv1;

   //-----------------------------
   volatile __u32 VAL;
   volatile __u32 RCCNT;
   volatile __u32 RCNUM;
   volatile __u32 LDH;
   volatile __u32 LDL;
            __u32 ___resv2;

   //-----------------------------
          CT_FM_R FM;
   volatile __u32 FMTSCNT;
   volatile __u32 FMH;
   volatile __u32 FML;

   //-----------------------------
            __u32 ___resv3[44];
} CT_CTL_R;

typedef struct IO_FUNC_R {
        DEV_IF0_R  DEV_IF0;
        DEV_IF1_R  DEV_IF1;
            __u32  ___resv0[14];

   //-------------------------------------------
   volatile __u16  KLS;
         AC_CTL_R  ACC;
          AC_IO_R  ACIO;
            __u32  ___resv1[46];

   //-------------------------------------------
   volatile __u8   AI_CONVEN;
   volatile __u8   AI_DMAEN;
            __u16  ___resv2; 
   volatile __u32  AI_DMAADRL;
   volatile __u32  AI_DMAADRH;
            __u32  ___resv3;
          AI_IE_R  AI_IE;
   volatile __u32  AI_RBSZ;
   volatile __u32  AI_WP;
   volatile __u32  AI_RP;
   volatile __u32  AI_PNUM; 
   volatile __u32  AI_PCNT;
   volatile __u32  AI_SNUM;
   volatile __u32  AI_SCNT;
         AI_CTL_R  AI_CTL;
   volatile __u32  AI_MUX;
   volatile __u32  AI_CSS;
       AI_SWTRG_R  AI_SWTRG;
   volatile __u32  AI_DTRG0DNUM;
   volatile __u32  AI_DTRG0DCNT;
   volatile __u32  AI_ATRG0DNUM;
   volatile __u32  AI_ATRG0DCNT;
   volatile __u32  AI_DTRG1DNUM;
   volatile __u32  AI_DTRG1DCNT;
   volatile __u32  AI_ATRG1DNUM;
   volatile __u32  AI_ATRG1DCNT;
   volatile __u32  AI_ITERNUM;
   volatile __u32  AI_ITERCNT;
   volatile __u32  AI_SCCNT;
            __u32  ___resv4;
   volatile __u32  AI_CCDIV;
   volatile __u32  AI_SCDIV;
            __u32  ___resv5[2];
          AI_CH_R  AI_CH[16];
            __u32  ___resv6[28];

   //-------------------------------------------
   volatile __u32  AO_CONVEN;
            __u32  ___resv7[3];
          AO_IE_R  AO_IE;
   volatile __u32  AO_RBSZ;
   volatile __u32  AO_WP;
   volatile __u32  AO_RP;
   volatile __u32  AO_PNUM; 
   volatile __u32  AO_PCNT;
   volatile __u32  AO_SNUM;
   volatile __u32  AO_SCNT;
         AO_CTL_R  AO_CTL;
   volatile __u32  AO_MUX;
            __u32  ___resv8;
       AO_SWTRG_R  AO_SWTRG;
           __u32   ___resv9[4];
   volatile __u32  AO_CCDIV;
            __u32  ___resva[3];
   volatile __u32  AO_SYNCLD;
   volatile __u32  AO_SYNCEN;
            __u32  ___resvb[2];
          AO_CH_R  AO_CH[2];
             __u8   ___resvc[2];       
   volatile __u32  AO_CHDAT[2];
            __u32  ___resvd[33];

   //-------------------------------------------
   volatile __u8   DIO_DAT[3];
            __u8   ___resve[29];
       DIO_CTL_R   DIO_CTL[3];
           __u32   ___resvf[44];

   //-------------------------------------------
        CT_CTL_R   CT_CTL[2];

} IO_FUNC_R;

#endif /* _KERNEL_MODULE_HW_H_ */
