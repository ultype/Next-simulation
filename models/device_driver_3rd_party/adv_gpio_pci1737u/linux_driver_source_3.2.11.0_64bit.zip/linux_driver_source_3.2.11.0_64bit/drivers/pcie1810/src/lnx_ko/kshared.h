/*
 * kshared.h
 *
 *  Created on: 2015-06-10
 *      Author: 
 */

#ifndef KERNEL_MODULE_SHARED_H_
#define KERNEL_MODULE_SHARED_H_

#include <linux/types.h>

#define PCIBAR_COUNT 4

#define ADVANTECH_VID             0x13fe
#define DEVID_1810               0xE810
#define DEVID_3810               0x0047

#define DRIVER_NAME               "bio1810"

#define DEVICE_NAME_FROM_PID(pid) ((pid) == BD_PCIE1810 ? "PCIe-1810" : "MIOe-3810")
#define DEVICE_ID_FROM_PID(pid)   ((pid) == BD_PCIE1810 ? DEVID_1810 : DEVID_3810)

// ----------------------------------------------------------
// H/W feature and structures.
// ----------------------------------------------------------
#define MAX_VAL_32BIT            4294967295              
#define MAX_VAL_24BIT            16777215              
#define MAX_VAL_16BIT            65535

#define AI_CHL_COUNT             16
#define AI_CHL_MASK              (AI_CHL_COUNT - 1)        // 0xF for 16 channel AI.

#define AI_RES_IN_BIT            12
#define AI_DATA_SIZE             sizeof(__u32)
#define AI_DATA_MASK             0xfff00000

#define AI_CLK_BASE              (100*1000*1000)    // 100MHz clock 
#define AI_MAX_PACER             (800*1000)         // 800K    
#define AI_MIN_PACER             (AI_CLK_BASE / (4294967296.0)) //The clock divisor is 32bit counter, 4.7ms

#define AI_FIFO_SIZE             4096                // Ai fifo size in samples.
#define AI_FIFO_MASK             (AI_FIFO_SIZE - 1)
#define AI_FIFO_XSIZE            (AI_FIFO_SIZE - 1)

#define AI_TRIG_SRC_VRG          V_Neg10To10
#define AI_TRIG_HYS_INDEX_MAX    0.00197
#define AI_TRIG_HYS_INDEX_STEP   256

#define AI_SCL_TBL_RES           32

//----------------------------------------------------------------------
//AO
#define AO_CHL_COUNT             2
#define AO_CHL_MASK              (AO_CHL_COUNT - 1)      // 0x1 for 2 channel AO.
                             
#define AO_RES_IN_BIT            12
#define AO_DATA_SIZE             sizeof(__u32)
#define AO_DATA_MASK             0xfff00000
                             
#define AO_CLK_BASE              (100*1000*1000)       // 100MHz clock 
#define AO_MAX_PACER             (500*1000)            // 500K
#define AO_MIN_PACER             (AO_CLK_BASE / 4294967296.0)
                             
#define AO_FIFO_SIZE             4096            // AO fifo size in samples
#define AO_FIFO_XSIZE            (AO_FIFO_SIZE - 1)
#define AO_FIFO_RBSZ             (AO_FIFO_SIZE - 2)

#define AO_EXT_REF_UNIPOLAR      10   // Default 10V external reference voltage
#define AO_EXT_REF_BIPOLAR       10   // Default 10V external reference voltage 

#define AO_SCL_TBL_RES           32

//----------------------------------------------------------------------
//DIO function definition
#define DIO_PORT_COUNT               3
#define DIO_CHL_COUNT                (DIO_PORT_COUNT * 8)
#define DI_INT_SRC_COUNT             DIO_PORT_COUNT 
#define DI_COS_SRC_COUNT             DIO_PORT_COUNT  
#define DI_PM_SRC_COUNT              DIO_PORT_COUNT
#define DI_SNAP_SRC_COUNT            (DI_INT_SRC_COUNT + DI_COS_SRC_COUNT + DI_PM_SRC_COUNT)

#define DI_PM_VALUE_MIN              0x00
#define DI_PM_VALUE_MAX              0xff

#define DI_FLT_SRC_COUNT             DIO_PORT_COUNT
#define DI_FLT_SMPL_INTVL_US         1                                              // Di filter sampling interval: 1us
#define DI_FLT_SMPL_INTVL_MS         1000                                           // Di filter sampling interval: 1ms
#define DI_FLT_SMPL_INTVL_USMS       0.001                                          // Di filter sampling interval: 0.001ms
#define DI_FLT_TIME_MIN              1
#define DI_FLT_TIME_MAX              255

//----------------------------------------------------------------------
//COUNTER function definition
#define CNTR_CHL_COUNT              2
#define CNTR_RES_IN_BIT             32                                          //Here defined is the hardware resolution
#define CNTR_MIN_VAL                0
#define CNTR_MAX_VAL                0xffffffff                                 //4294967295
#define CNTR_CLK_BASE               (20 * 1000 * 1000)                        //20MHz

#define CNTR_OS_DELAY_MIN_VAL       1
#define CNTR_OS_DELAY_MAX_VAL       0xffffffff                                  //4294967295

#define CNTR_TIMER_PULSE_MAX_FREQ   (5 * 1000 * 1000)
#define CNTR_TIMER_PULSE_MIN_FREQ   0.005
#define CNTR_TIMER_PULSE_MAX_DIV    0xee6b2800
#define CNTR_TIMER_PULSE_MIN_DIV    0x4

#define CNTR_PWMO_RESOLUTION        (50 * 0.001 * 0.001 * 0.001)                        //50us                     
#define CNTR_PWMO_MIN_BIN_VAL       0x1                                       //2
#define CNTR_PWMO_MAX_BIN_VAL       0xffffffff                                 //2^32 - 1   
#define CNTR_PWMO_MIN_VAL           (CNTR_PWMO_MIN_BIN_VAL * CNTR_PWMO_RESOLUTION * 2)   //0.000100
#define CNTR_PWMO_MAX_VAL           (CNTR_PWMO_MAX_BIN_VAL * CNTR_PWMO_RESOLUTION)   //214748.364750

#define CNTR_FLT_SRC_COUNT_MAX      CNTR_CHL_COUNT
#define CNTR_FLT_SMPL_INTVL         1  
#define CNTR_FLT_TIME_RANGE_MIN     1
#define CNTR_FLT_TIME_RANGE_MAX     255

#define CNTR_OP_IDLE                0x00000000
#define CNTR_OP_EVENTCOUNT          0x00000001
#define CNTR_OP_ONESHOT             0x00000002
#define CNTR_OP_TIMERPULSE          0x00000004
#define CNTR_OP_FREQMETER           0x00000008
#define CNTR_OP_PWMIN               0x00000010
#define CNTR_OP_PWMOUT              0x00000020

typedef enum _GATE_MODE
{
   NoGate    = 0x0,
   LevelMode = 0x1,
   EdgeMode  = 0x2,
   EdgeRetriggerMode = 0x3, 
} GATEMODE;

////////////////////////////////////////////////////////////////////////////////////////////
#define INT_SECTION_SIZE_MAX         3
#define EVENT_OVERALL                32
#define FIRMWARE_PAGE_SIZE           4096
#define FPGA_NORMAL_START            0x200000
#define FPGA_FACTORY_START           0x000000
#define NORMAL_FIRMWARE_SIZE_MAX     2048*1024 //2048KB
#define MAX_CUSTOMER_DATA_COUNT      32

enum KRNL_EVENT_IDX{
   KdxDevPropChged = 0,

   KdxAiDataReady,
   KdxAiOverrun,
   KdxAiStopped,
   KdxAiCacheOverflow,

   KdxAoDataTransed,
   KdxAoUnderrun,
   KdxAoTransStopped,
   KdxAoStopped,
   KdxAoCacheEmptied,

   KdxDiBegin,
   KdxDiintChan0 = KdxDiBegin,
   KdxDicosPort0,
   KdxDipmPort0,

   KdxDiintChan8,
   KdxDicosPort1,
   KdxDipmPort1,

   KdxDiintChan16,
   KdxDicosPort2,
   KdxDipmPort2,
   KdxDiEnd = KdxDipmPort2,

   KdxCntOneShot0,
   KdxCntOneShot1,
   KdxCntTimer0,
   KdxCntTimer1,

   KrnlSptedEventCount,
};

static inline __u32 GetEventKIndex(__u32 eventType)
{
   __u32 kdx;
   switch (eventType)
   {
   case EvtPropertyChanged:           kdx = KdxDevPropChged;      break;

   case EvtBufferedAiDataReady:       kdx = KdxAiDataReady;       break;
   case EvtBufferedAiOverrun:         kdx = KdxAiOverrun;         break;
   case EvtBufferedAiStopped:         kdx = KdxAiStopped;         break;
   case EvtBufferedAiCacheOverflow:   kdx = KdxAiCacheOverflow;   break;

   case EvtBufferedAoDataTransmitted: kdx = KdxAoDataTransed;     break;
   case EvtBufferedAoUnderrun:        kdx = KdxAoUnderrun;        break;
   case EvtBufferedAoTransStopped:    kdx = KdxAoTransStopped;    break;
   case EvtBufferedAoStopped:         kdx = KdxAoStopped;         break;
   case EvtBufferedAoCacheEmptied:    kdx = KdxAoCacheEmptied;    break;

   case EvtDiintChannel000:           kdx = KdxDiintChan0;        break;
   case EvtDiCosintPort000:           kdx = KdxDicosPort0;        break;
   case EvtDiPmintPort000:            kdx = KdxDipmPort0;         break;

   case EvtDiintChannel008:           kdx = KdxDiintChan8;        break;
   case EvtDiCosintPort001:           kdx = KdxDicosPort1;        break;
   case EvtDiPmintPort001:            kdx = KdxDipmPort1;         break;

   case EvtDiintChannel016:           kdx = KdxDiintChan16;       break;
   case EvtDiCosintPort002:           kdx = KdxDicosPort2;        break;
   case EvtDiPmintPort002:            kdx = KdxDipmPort2;         break;

   case EvtCntOneShot0:               kdx = KdxCntOneShot0;       break;
   case EvtCntOneShot1:               kdx = KdxCntOneShot1;       break;

   case EvtCntTimer0:                 kdx = KdxCntTimer0;         break;
   case EvtCntTimer1:                 kdx = KdxCntTimer1;         break;

   default:                           kdx = -1;                   break;
   }
   return kdx;
}

// -----------------------------------------------------
// default values
// -----------------------------------------------------
#define DEF_INIT_ON_LOAD        1

// AI default values
#define DEF_AI_CHTYPE           0 // single-ended
#define DEF_AI_GAIN             0 // +/- 5V
#define DEF_FAI_CHSTART         0
#define DEF_FAI_CHCOUNT         1
#define DEF_FAI_CLKSRC          SigInternalClock
#define DEF_FAI_PACERDIVISOR    5000
#define DEF_FAI_SCANSRC         SignalNone
#define DEF_FAI_SCANCNT         1 

#define DEF_FAI_MODE            0
#define DEF_FAI_SECTSIZE        (AI_FIFO_SIZE / 2)

#define DEF_FAI_TRIG_ACT        DelayToStart
#define DEF_FAI_TRIG_SRC        SignalNone
#define DEF_FAI_TRIG_EDGE       RisingEdge
#define DEF_FAI_TRIG_LEVEL      5.0
#define DEF_FAI_TRIG_DLYCNT     0
#define DEF_FAI_TRIG_HYSTIDX    (AI_TRIG_HYS_INDEX_MAX / 2)

#define DEF_FAI_TRIG1_ACT       DelayToStop
#define DEF_FAI_TRIG1_SRC       SignalNone
#define DEF_FAI_TRIG1_EDGE      RisingEdge
#define DEF_FAI_TRIG1_LEVEL     5.0
#define DEF_FAI_TRIG1_DLYCNT    0
#define DEF_FAI_TRIG1_HYSTIDX   (AI_TRIG_HYS_INDEX_MAX / 2)

// AO default values
#define DEF_AO_GAIN             V_0To5
#define DEF_AO_EXT_REF_BIPOLAR  AO_EXT_REF_BIPOLAR
#define DEF_AO_EXT_REF_UNIPOLAR AO_EXT_REF_UNIPOLAR
#define DEF_AO_INIT_STATE       0

#define DEF_FAO_CHSTART         0
#define DEF_FAO_CHCOUNT         1
#define DEF_FAO_CLKSRC          SigInternalClock
#define DEF_FAO_PACERDIVISOR    5000
#define DEF_FAO_SECTSIZE        AO_FIFO_SIZE
#define DEF_FAO_MODE            DAQ_XFER_INT

#define DEF_FAO_TRIG_ACT        DelayToStart
#define DEF_FAO_TRIG_SRC        SignalNone
#define DEF_FAO_TRIG_EDGE       RisingEdge
#define DEF_FAO_TRIG_DLYCNT    0

#define DEF_FAO_TRIG1_ACT       DelayToStart
#define DEF_FAO_TRIG1_SRC       SignalNone
#define DEF_FAO_TRIG1_EDGE      RisingEdge
#define DEF_FAO_TRIG1_DLYCNT    0

// DIO default values
#define DEF_DIO_DIR             Input
#define DEF_DI_INT_TRIGEDGE     RisingEdge

#define DEF_DO_STATE            0xff

// CNTR default values
#define DEF_EC_CLKPOL        Positive
#define DEF_EC_GATEPOL       Positive
#define DEF_EC_GATEEN        0

#define DEF_OST_CLKSRC(ch)   (SigCntClk0 + ch)
#define DEF_OST_CLKPOL       Positive
#define DEF_OST_GATESRC(ch)  (SigCntGate0 + ch)  
#define DEF_OST_GATEPOL      Positive
#define DEF_OST_OUTSIG       PositivePulse
#define DEF_OST_DELAYCNT     1000

#define DEF_TMR_GATEPOL      Positive
#define DEF_TMR_GATEEN       0
#define DEF_TMR_OUTSIG       PositivePulse
#define DEF_TMR_DIVISOR      CNTR_TIMER_PULSE_MAX_DIV

#define DEF_PO_GATEEN        0
#define DEF_PO_OUTSIG        PositivePulse
#define DEF_PO_HIPERIOD      1600000
#define DEF_PO_LOPERIOD      400000


// ----------------------------------------------------------
// Device private data
// ----------------------------------------------------------
typedef struct _FAI_CONFIG
{
   __u32  XferMode;
   __u32  PhyChanStart;
   __u32  LogChanCount;
   __u32  SampleCount;
   __u32  SectionSize;

   __u32  ConvClkSource;
   double ConvClkRatePerCH;
   __u32  PacerDivider;

   __u32  ScanClkSource;         
   double ScanClkRate;           
   __u32  ScanClkDivider;        
   __u32  ScanCount;        

   __u32  TrigAction;    
   __u32  TrigSource;          
   __u32  TrigEdge;              
   __u32  TrigDelayCount;       
   __u32  TrigLevelBin;   
   __u32  TrigHystIndexBin;
   double TrigHystIndex;
   double TrigLevel;           

   __u32  Trig1Action;            
   __u32  Trig1Source;          
   __u32  Trig1Edge;              
   __u32  Trig1DelayCount;       
   __u32  Trig1LevelBin;   
   __u32  Trig1HystIndexBin;
   double Trig1Level;           
   double Trig1HystIndex;   
} FAI_CONFIG;

typedef struct _FAI_STATUS
{
   __u32  AcqMode;
   __u32  FnState;
   __u32  BufState;
   __u32  BufLength;
   __u32  WritePos;
   __u32  ReadPos;
   __u32  WPRunBack;
   __u32  WPRunBack_TDtp;    
   __u32  OvrnOffset;
   __u32  OvrnCount;   
} FAI_STATUS;

typedef struct _FAO_CONFIG
{
   __u32  XferMode;             
   __u32  ChanStart;  
   __u32  ChanCount;  
   __u32  SectionSize;
   __u32  SampleCount; 

   __u32  ConvClkSource;          
   double ConvClkRatePerCH;       
   __u32  PacerDivider;          
   __u32  RealyTpValue; 

   __u32  TrigAction;            
   __u32  TrigSource;           
   __u32  TrigEdge;  
   __u32  TrigDelayCount;

   __u32  Trig1Action;            
   __u32  Trig1Source;           
   __u32  Trig1Edge;  
   __u32  Trig1DelayCount;

} FAO_CONFIG;

typedef struct _FAO_STATUS
{
   __u32 AcqMode;        
   __u32 FnState;             
   __u32 BufState;             

   __u32 BufLength;          
   __u32 WritePos;            
   __u32 ReadPos;             
   __u32 WPRunBack;       

   __u32 DataLeft;
} FAO_STATUS;

typedef struct _RBUF_STATUS
{
   __u32 SCValue;    
   __u32 PPValue;
   __u32 TPValue;
   __u32 RPValue;    
   __u32 WPValue;   

} RBUF_STATUS;

//----------------------------------------------------------------------
//DIO function definition
typedef struct _DI_SNAP_CONFIG
{
   __u8 PortStart;
   __u8 PortCount;
} DI_SNAP_CONFIG;

typedef struct _DI_SNAP_STATUS
{
   __u8 State[DIO_PORT_COUNT];
   __u8 ___resv;
} DI_SNAP_STATUS;

//----------------------------------------------------------------------
//COUNTER function definition
typedef struct _CNTR_CONFIG
{
   // Common
   __u32 CntrClkFltChEnabled [CNTR_CHL_COUNT];  // Counter 'digital filter' enabled channels.
   __u32 CntrClkFltTime[CNTR_CHL_COUNT];        // Counter 'digital filter' time range.

   // Event Count
   __u32 EcClkPolarity[ CNTR_CHL_COUNT ];
   __u32 EcGatePolarity[ CNTR_CHL_COUNT ];
   __u32 EcGateEnabled[ CNTR_CHL_COUNT ];

   // One-shot
   __u32 OsClkSource[ CNTR_CHL_COUNT ];
   __u32 OsClkPolarity[ CNTR_CHL_COUNT ];
   __u32 OsGateSource[ CNTR_CHL_COUNT ];
   __u32 OsGatePolarity[ CNTR_CHL_COUNT ];
   __u32 OsOutSigType[ CNTR_CHL_COUNT ];
   __u32 OsDelayCount[ CNTR_CHL_COUNT ];

   // Timer/Pulse
   __u32 TmrGatePolarity[ CNTR_CHL_COUNT ];
   __u32 TmrGateEnabled[ CNTR_CHL_COUNT ];
   __u32 TmrOutSigType[ CNTR_CHL_COUNT ];
   __u32 TmrDivisor[ CNTR_CHL_COUNT ];

   // Frequency measurement
   __u32 FmPeroid[ CNTR_CHL_COUNT ]; 
   __u32 FmMethod[ CNTR_CHL_COUNT ]; 

   // PwmIn 
   __u32 PiClkSource[ CNTR_CHL_COUNT ]; 

   // PWMOut
   __u32 PoHiPeriod[ CNTR_CHL_COUNT ]; 
   __u32 PoLoPeriod[ CNTR_CHL_COUNT ]; 
   __u32 PoGatePolarity[ CNTR_CHL_COUNT ];
   __u32 PoGateEnabled[ CNTR_CHL_COUNT ];
   __u32 PoSignalType[CNTR_CHL_COUNT ];
} CNTR_CONFIG;

typedef struct _CNTR_STATE
{
   __u32 Operation;  
} CNTR_STATE;


typedef struct _DEVICE_SHARED
{
   __u32          Size;           // Size of the structure
   __u32          ProductId;      // Device Type
   __u32          DeviceNumber;   // Zero-based device number

   // HW Information
   __u32          BoardId;        // Board dip switch number for the device
   __u32          BusNumber;      // PCI Bus number
   __u32          SlotNumber;     // PCI Slot number
   __u64          BarPhyBase[PCIBAR_COUNT];
   __u32          BarLength[PCIBAR_COUNT];
   __u32          KernPageSize;
   __u32          Irq;
   __u32          InitOnLoad;
               
   __u32          PcbVer;         // PCB Version
   __u32          PldVer;         // Programmable Logic Device Version
   __u32          FwVer;    // Firmware version

   // --------------------------------------------------------
   __u8           AiChanType[AI_CHL_COUNT];
   __u8           AiChanGain[AI_CHL_COUNT];
   __u32          AiLogChanCount;
               
   double         SaiClkRate;            
   __u32          SaiClkDiv;            
   __u32          SaiCHStart;         
   __u32          SaiCHCount;          
               
   FAI_CONFIG     FaiParam;
   FAI_STATUS     FaiStatus;
   RBUF_STATUS    AiRBufStatus;

   // ---------------------------------------------------------
   __u32          AoChanGain[AO_CHL_COUNT];    
   double         AoExtRefUnipolar;             
   double         AoExtRefBipolar;           
   __u32          AoChanState[AO_CHL_COUNT]; 
               
   FAO_CONFIG     FaoParam;      
   FAO_STATUS     FaoStatus;      
   RBUF_STATUS    AoRBufStatus;

   // ---------------------------------------------------------
   __u8           DioPortDir[DIO_PORT_COUNT];
   __u8           DiInversePort[DIO_PORT_COUNT];
   __u8           DoPortState[DIO_PORT_COUNT];
   __u8           DiintTrigEdge[DI_INT_SRC_COUNT];

   __u8           DiCosChEnabled[DI_COS_SRC_COUNT];   
   __u8           DiPmChEnabled [DI_PM_SRC_COUNT];    
   __u8           DiPmValue[DI_PM_SRC_COUNT];    
   __u8           DiFltChEnabled [DI_FLT_SRC_COUNT];  
   __u32          DiFltBlockTime;                         
   DI_SNAP_CONFIG DiSnapParam[DI_SNAP_SRC_COUNT];
   DI_SNAP_STATUS DiSnapState[DI_SNAP_SRC_COUNT];

   // ---------------------------------------------------------
   CNTR_CONFIG    CntrConfig;
   CNTR_STATE     CntrState[CNTR_CHL_COUNT];

   // ---------------------------------------------------------
   __u32          IsEvtSignaled[KrnlSptedEventCount];

} DEVICE_SHARED;

#endif /* KERNEL_MODULE_SHARED_H_ */
