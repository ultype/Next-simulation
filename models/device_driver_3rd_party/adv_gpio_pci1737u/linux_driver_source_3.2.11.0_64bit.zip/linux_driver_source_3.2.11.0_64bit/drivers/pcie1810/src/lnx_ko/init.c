/*
* init.c
*
*  Created on: 2015-06-10
*      Author: 
*/
#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/interrupt.h>
#include "kdriver.h"
#include "hw.h"

// device supported
static struct pci_device_id daq_device_ids[] = {
   { PCI_DEVICE(ADVANTECH_VID, DEVID_1810) },
   { PCI_DEVICE(ADVANTECH_VID, DEVID_3810) },
   { 0, }
};
MODULE_DEVICE_TABLE(pci, daq_device_ids);

/************************************************************************
* FILE OPERATIONS
************************************************************************/
static struct file_operations daq_fops = {
   .owner    = THIS_MODULE,
   .open     = daq_file_open,
   .release  = daq_file_close,
   .mmap     = daq_file_mmap,
   .unlocked_ioctl = daq_file_ioctl,
};

/************************************************************************
* device settings
************************************************************************/
static void daq_device_load_setting(daq_device_t  *daq_dev)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   int i;
   // AI
   for (i = 0; i < AI_CHL_COUNT; ++i){
      shared->AiChanType[i] = DEF_AI_CHTYPE;
      shared->AiChanGain[i] = DEF_AI_GAIN;
   }

   shared->SaiCHStart = 0;
   shared->SaiCHCount = 1;
   shared->SaiClkRate = AI_CLK_BASE / 5000;
   shared->SaiClkDiv  = 5000;

   shared->FaiParam.PhyChanStart     = DEF_FAI_CHSTART;
   shared->FaiParam.LogChanCount     = DEF_FAI_CHCOUNT;
   shared->FaiParam.SectionSize      = DEF_FAI_SECTSIZE;

   shared->FaiParam.ConvClkSource    = DEF_FAI_CLKSRC;
   shared->FaiParam.ConvClkRatePerCH = AI_CLK_BASE / DEF_FAI_PACERDIVISOR;
   shared->FaiParam.PacerDivider     = DEF_FAI_PACERDIVISOR;

   shared->FaiParam.ScanClkSource    = DEF_FAI_SCANSRC;
   shared->FaiParam.ScanClkRate      = AI_CLK_BASE / DEF_FAI_PACERDIVISOR;
   shared->FaiParam.ScanClkDivider   = DEF_FAI_PACERDIVISOR;
   shared->FaiParam.ScanCount        = DEF_FAI_SCANCNT;

   shared->FaiParam.TrigAction       = DEF_FAI_TRIG_ACT;
   shared->FaiParam.TrigSource       = DEF_FAI_TRIG_SRC;
   shared->FaiParam.TrigEdge         = DEF_FAI_TRIG_EDGE;
   shared->FaiParam.TrigLevel        = DEF_FAI_TRIG_LEVEL;
   shared->FaiParam.TrigDelayCount   = DEF_FAI_TRIG_DLYCNT;
   shared->FaiParam.TrigHystIndex    = DEF_FAI_TRIG_HYSTIDX;

   shared->FaiParam.Trig1Action      = DEF_FAI_TRIG1_ACT;
   shared->FaiParam.Trig1Source      = DEF_FAI_TRIG1_SRC;
   shared->FaiParam.Trig1Edge        = DEF_FAI_TRIG1_EDGE;
   shared->FaiParam.Trig1Level       = DEF_FAI_TRIG1_LEVEL;
   shared->FaiParam.Trig1DelayCount  = DEF_FAI_TRIG1_DLYCNT;
   shared->FaiParam.Trig1HystIndex   = DEF_FAI_TRIG1_HYSTIDX;

   // AO
   for (i = 0; i < AO_CHL_COUNT; ++i){
      shared->AoChanGain[i]  = DEF_AO_GAIN;
   }
   shared->AoExtRefUnipolar = DEF_AO_EXT_REF_UNIPOLAR;
   shared->AoExtRefBipolar  = DEF_AO_EXT_REF_BIPOLAR;

   shared->FaoParam.ChanStart        = DEF_FAO_CHSTART;
   shared->FaoParam.ChanCount        = DEF_FAO_CHCOUNT;
   shared->FaoParam.SectionSize      = DEF_FAO_SECTSIZE;

   shared->FaoParam.ConvClkSource    = DEF_FAO_CLKSRC;
   shared->FaoParam.ConvClkRatePerCH = AO_CLK_BASE / DEF_FAO_PACERDIVISOR;
   shared->FaoParam.PacerDivider     = DEF_FAO_PACERDIVISOR;

   shared->FaoParam.TrigAction       = DEF_FAO_TRIG_ACT;
   shared->FaoParam.TrigSource       = DEF_FAO_TRIG_SRC;
   shared->FaoParam.TrigEdge         = DEF_FAO_TRIG_EDGE;
   shared->FaoParam.TrigDelayCount   = DEF_FAO_TRIG_DLYCNT;

   shared->FaoParam.Trig1Action      = DEF_FAO_TRIG1_ACT;
   shared->FaoParam.Trig1Source      = DEF_FAO_TRIG1_SRC;
   shared->FaoParam.Trig1Edge        = DEF_FAO_TRIG1_EDGE;
   shared->FaoParam.TrigDelayCount   = DEF_FAO_TRIG1_DLYCNT;

   // DIO
   for (i = 0; i < DIO_PORT_COUNT; ++i){
      shared->DioPortDir[i] = DEF_DIO_DIR;
      shared->DoPortState[i]= DEF_DO_STATE;
   }
   for (i = 0; i < DI_INT_SRC_COUNT; ++i) {
      shared->DiintTrigEdge[i] = DEF_DI_INT_TRIGEDGE;
   }

   // Counter
   for (i = 0; i < CNTR_CHL_COUNT; ++i){
      //EventCount
      shared->CntrConfig.EcClkPolarity[i]  = DEF_EC_CLKPOL;
      shared->CntrConfig.EcGatePolarity[i] = DEF_EC_GATEPOL;
      shared->CntrConfig.EcGateEnabled[i]  = DEF_EC_GATEEN; 

      // One-shot
      shared->CntrConfig.OsClkSource[i]    = DEF_OST_CLKSRC(i); 
      shared->CntrConfig.OsClkPolarity[i]  = DEF_OST_CLKPOL;     
      shared->CntrConfig.OsGateSource[i]   = DEF_OST_GATESRC(i);
      shared->CntrConfig.OsGatePolarity[i] = DEF_OST_GATEPOL;   
      shared->CntrConfig.OsOutSigType[i]   = DEF_OST_OUTSIG;     
      shared->CntrConfig.OsDelayCount[i]   = DEF_OST_DELAYCNT;   

      // Timer/Pulse
      shared->CntrConfig.TmrGatePolarity[i] = DEF_TMR_GATEPOL;
      shared->CntrConfig.TmrGateEnabled[i]  = DEF_TMR_GATEEN;
      shared->CntrConfig.TmrOutSigType[i]   = DEF_TMR_OUTSIG;
      shared->CntrConfig.TmrDivisor[i]      = DEF_TMR_DIVISOR;   

      // Frequency measurement
      shared->CntrConfig.FmMethod[i] = AutoAdaptive;
      shared->CntrConfig.FmPeroid[i] = 0;

      // PwmIn
      shared->CntrConfig.PiClkSource[i] = SigInternalClock;

      // PwmOut
      shared->CntrConfig.PoGateEnabled[i]= DEF_PO_GATEEN;  
      shared->CntrConfig.PoSignalType[i] = DEF_PO_OUTSIG;
      shared->CntrConfig.PoHiPeriod[i]   = DEF_PO_HIPERIOD; 
      shared->CntrConfig.PoLoPeriod[i]   = DEF_PO_LOPERIOD;
   }
}

static void daq_device_load_cali_data(daq_device_t  *daq_dev, __u16 cmd, __u16 data)
{
   AC_IO_R ac_io = {0};

   while (IOREGS->ACC.BUSY) {;}

   // Fix bug#10569
   // The following two register: data & cmd must be written together.
   ac_io.DATA = data;
   ac_io.CMD  = cmd;
   IOREGS->ACIO.xval = ac_io.xval;
}

/************************************************************************
* sysfs support routines
************************************************************************/
#include <biosysfshelper.h>

// ------------------------------------------------------------------
// Device initialize/de-initailize
// ------------------------------------------------------------------
static int __devinit daq_device_probe(struct pci_dev *dev, const struct pci_device_id *id)
{
   dev_t         devid;
   daq_device_t  *daq_dev;
   DEVICE_SHARED *shared;
   struct device *sysfs_dev;
   size_t        mem_size;
   int           ret, res_idx = 0;
   __u8          AID;

#define CHK_RESULT(_ok_, err, err_label)   if (!(_ok_)) { ret = err; goto err_label; }

   if ((ret = pci_enable_device(dev)) != 0) {
      daq_trace((KERN_ERR": pci_enable_device failed\n"));
      return ret;
   }
   pci_set_master(dev);   /* enable bus-master */

   // allocate private data structure
   mem_size = (sizeof(daq_device_t) + PAGE_SIZE - 1) & PAGE_MASK;
   daq_dev = (daq_device_t*)kzalloc(mem_size, GFP_KERNEL);
   CHK_RESULT(daq_dev, -ENOMEM, err_alloc_dev)

   // initialize the private data in the device
   shared               = &daq_dev->shared;
   shared->Size         = sizeof(*shared);
   shared->DeviceNumber = -1; // unknown
   shared->BusNumber    = dev->bus->number;
   shared->SlotNumber   = PCI_SLOT(dev->devfn);
   shared->Irq          = dev->irq;
   shared->InitOnLoad   = DEF_INIT_ON_LOAD;
   
   switch(dev->device)
   {
   case DEVID_1810:
      shared->ProductId = BD_PCIE1810;
      break;
   case DEVID_3810:
      shared->ProductId = BD_MIOe3810;
      break;
   default:
      ret = -ENODEV;
      goto err_no_res_mem;
   }

   /* request IO resource */   
   for (res_idx = 0; res_idx < PCIBAR_COUNT; ++res_idx) {
      /* request memory region*/
      shared->BarPhyBase[res_idx] = dev->resource[res_idx].start & ~1UL;
      shared->BarLength[res_idx]  = dev->resource[res_idx].end - shared->BarPhyBase[res_idx] + 1;
      if (!request_mem_region(shared->BarPhyBase[res_idx], shared->BarLength[res_idx], DRIVER_NAME)) {
         shared->BarPhyBase[res_idx] = 0;
         CHK_RESULT(0, -EBUSY, err_no_res_mem);
      }

      /* mapping to memory space */
      daq_dev->iomem_base[res_idx] = ioremap(shared->BarPhyBase[res_idx], shared->BarLength[res_idx]);
      CHK_RESULT(daq_dev->iomem_base[res_idx], -EBUSY, err_no_res_mem);
   }

   /*test whether we got the memory resource in right order or not*/
   AID = CVREGS->AID;
   if (AID != 0xA5 && AID != 0x5A) {
      daq_trace((KERN_ERR "Bar order is wrong:1, aid = 0x%x\n", (unsigned int)AID));
      CHK_RESULT(0, -EINVAL, err_no_res_mem);
   }
   if ((__u8)~AID != CVREGS->AID) {
      daq_trace((KERN_ERR "Bar order is wrong:2\n"));
      CHK_RESULT(0, -EINVAL, err_no_res_mem);
   }

   /* request irq */
   ret = request_irq(shared->Irq, (daq_irq_handler_t)daq_irq_handler, IRQF_SHARED, DRIVER_NAME, daq_dev);
   CHK_RESULT(ret == 0, ret, err_irq);

   /* initialize daq_dev structures*/
   spin_lock_init(&daq_dev->dev_lock);
   tasklet_init(&daq_dev->dev_tasklet, daq_device_tasklet_func, (unsigned long)daq_dev);

   INIT_LIST_HEAD(&daq_dev->file_ctx_list);
   daq_dev->file_ctx_pool_size = (mem_size - sizeof(daq_device_t)) / sizeof(daq_file_ctx_t);
   if (daq_dev->file_ctx_pool_size){
      daq_dev->file_ctx_pool = (daq_file_ctx_t *)(daq_dev + 1);
   } else {
      daq_dev->file_ctx_pool = NULL;
   }

   spin_lock_init(&daq_dev->fai_lock);
   init_waitqueue_head(&daq_dev->fai_queue);

   spin_lock_init(&daq_dev->fao_lock);
   init_waitqueue_head(&daq_dev->fao_queue);
   DAQ_INIT_DELAYED_WORK(&daq_dev->fao_fifo_chk_work, daq_fao_fifo_check_work_func);

   spin_lock_init(&daq_dev->cntr_lock);

   /* get device information */
   shared->BoardId = CVREGS->BID;
   shared->PcbVer  = CVREGS->PCB_VER;
   shared->PldVer  = CVREGS->PLD_VER;
   shared->FwVer   = CVREGS->FW_VER;
   shared->KernPageSize = PAGE_SIZE;

   daq_trace((KERN_INFO "BoardID: %x, PcbVer: %x, PldVer: %x, Fw: %x\n",\
      shared->BoardId, shared->PcbVer, shared->PldVer, shared->FwVer));

   /*Get dynamic device number*/
   devid = daq_devid_alloc();
   CHK_RESULT(devid > (dev_t)0, -ENOSPC, err_no_devid)

   /*register our device into kernel*/
   cdev_init(&daq_dev->cdev, &daq_fops);
   daq_dev->cdev.owner = THIS_MODULE;
   ret = cdev_add(&daq_dev->cdev, devid, 1);
   CHK_RESULT(ret == 0, ret, err_cdev_add)

   /* register our own device in sysfs, and this will cause udev to create corresponding device node */
   sysfs_dev = DAQ_SYSFS_INITIALIZE(devid, daq_dev);
   CHK_RESULT(!IS_ERR(sysfs_dev), PTR_ERR(sysfs_dev), err_sysfs_reg)

   // link the info into the other structures
   daq_dev->pdev = dev;
   pci_set_drvdata(dev, daq_dev);
   SetPageReserved(virt_to_page((unsigned long)daq_dev));

   // initialize the device
   daq_device_load_setting(daq_dev);
   shared->InitOnLoad = !IOREGS->KLS;

   // load AI/AO calibration data     
   daq_device_load_cali_data(daq_dev, CAL_LOAD_EEPROM_TO_RAM, 0);
   udelay(200);
   daq_device_load_cali_data(daq_dev, CAL_LOAD_RAM_TO_TRIMDAC, 0);

   daq_ai_initialize_hw(daq_dev);
   daq_ao_initialize_hw(daq_dev);
   daq_dio_initialize_hw(daq_dev);

   // Winning horn
   daq_trace((KERN_INFO "Add %s: major:%d, minor:%d\n", 
      DEVICE_NAME_FROM_PID(shared->ProductId), MAJOR(devid), MINOR(devid)));
   daq_trace((KERN_INFO "dev base addr:[0x%p, %d], bid:%d\n",\
      daq_dev->iomem_base[0], shared->BarLength[0], shared->BoardId));

   return 0;

err_sysfs_reg:
   cdev_del(&daq_dev->cdev);

err_cdev_add:
   daq_devid_free(devid);

err_no_devid:
   free_irq(shared->Irq, daq_dev);

err_irq:
err_no_res_mem:
   if (res_idx >= PCIBAR_COUNT) { 
      --res_idx; 
   }

   for (; res_idx >= 0; --res_idx) {
      if (daq_dev->iomem_base[res_idx]) {
         iounmap(daq_dev->iomem_base[res_idx]);
      }
      if (shared->BarPhyBase[res_idx]) {
         release_mem_region(shared->BarPhyBase[res_idx], shared->BarLength[res_idx]);
      }
   }

   kfree(daq_dev);

err_alloc_dev:
   pci_disable_device(dev);

   daq_trace((KERN_ERR "Add failed. error = %d\n", ret));
   return ret;
}

void daq_device_cleanup(daq_device_t * daq_dev)
{
   // Delete device node under /dev
   cdev_del(&daq_dev->cdev);
   daq_devid_free(daq_dev->cdev.dev);
   device_destroy(daq_class_get(), daq_dev->cdev.dev);

   // Free the device information structure
   ClearPageReserved(virt_to_page((unsigned long)daq_dev));
   kfree(daq_dev);
}

static void __devexit daq_device_remove(struct pci_dev *dev)
{
   daq_device_t  *daq_dev = pci_get_drvdata(dev);
   DEVICE_SHARED *shared  = &daq_dev->shared;
   int i;

   daq_trace((KERN_INFO"Device removed!\n"));

   free_irq(shared->Irq, daq_dev);

   for (i = 0; i < PCIBAR_COUNT; ++i) {
      iounmap(daq_dev->iomem_base[i]);
      release_mem_region(shared->BarPhyBase[i], shared->BarLength[i]);
   }

   pci_set_drvdata(dev, NULL);
   pci_disable_device(dev);

   {
      unsigned long flags;
      spin_lock_irqsave(&daq_dev->dev_lock, flags);
      if (list_empty(&daq_dev->file_ctx_list)){
         spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
         daq_device_cleanup(daq_dev);
      } else {
         daq_dev->remove_pending = 1;
         spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
      }
   }
}

// ------------------------------------------------------------------
// Driver initialize/de-initailize
// ------------------------------------------------------------------
static struct pci_driver pci_driver = {
   .name     = DRIVER_NAME,
   .probe    = daq_device_probe,
   .remove   = __devexit_p(daq_device_remove),
   .id_table = daq_device_ids,
};

static int __init daq_driver_init(void)
{
   return pci_register_driver(&pci_driver);
}

static void __exit daq_driver_exit(void)
{
   pci_unregister_driver(&pci_driver);
}

module_init(daq_driver_init);
module_exit(daq_driver_exit);

MODULE_LICENSE("GPL");
