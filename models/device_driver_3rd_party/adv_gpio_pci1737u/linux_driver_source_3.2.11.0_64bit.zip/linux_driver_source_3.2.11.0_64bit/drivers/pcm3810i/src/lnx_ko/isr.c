/*
 * isr.c
 *
 *  Created on: Nov 29, 2011
 *      Author: 
 */
#include "kdriver.h"
#include "hw.h"

// -----------------------------------------------------------------------------
// Must hold the lock when call this function.
static inline
void daq_fai_update_status(FAI_CONFIG *cfg, FAI_STATUS *st, unsigned inc_count)
{
   // check running time status: overrun, data ready
   st->BufState = 0;

   // check data ready and update write position
   if (st->WritePos + inc_count >= st->BufLength) {
      st->BufState  |=  DAQ_IN_DATAREADY;
      st->WritePos  += inc_count;
      st->WritePos  %= st->BufLength;
      st->WPRunBack += 1;
   } else {
      if ((st->WritePos % cfg->SectionSize) + inc_count >= cfg->SectionSize) {
         st->BufState |= DAQ_IN_DATAREADY;
      }
      st->WritePos += inc_count;
   }

   // check overrun and buffer full
   if (st->WPRunBack) {
      int ovrnOffset = st->ReadPos;
      int ovrnCount  = st->WritePos - ovrnOffset;
      st->BufState |= DAQ_IN_BUF_FULL;

      if (st->WPRunBack > 1 || ovrnCount > 0){
         if (st->WPRunBack > 1) { 
            ovrnCount = st->BufLength;
         }

         st->OvrnCount  = ovrnCount;
         st->OvrnOffset = ovrnOffset;
         st->BufState |= DAQ_IN_BUF_OVERRUN;
      }
   }
}

static inline
void daq_fai_read_fifo(daq_device_t *daq_dev, __u32 readyDataCount, __u32 *destPos, __u32 * aiRingBufReadPos)
{
   __u32         *data_buf = (__u32*)daq_dev->fai_buffer.kaddr;
   __u32         length;
   DEVICE_SHARED *shared = &daq_dev->shared;

   while( readyDataCount )
   {
      length = readyDataCount;
      if (((*destPos + length) >= shared->FaiStatus.BufLength) || ((*aiRingBufReadPos + length) >= AI_FIFO_SIZE))
      {
         length = x_min(shared->FaiStatus.BufLength - *destPos, AI_FIFO_SIZE - *aiRingBufReadPos);
      }
      readyDataCount -= length;
      memcpy(data_buf + *destPos, (__u32 *)(shared->BarMemBase[2] + *aiRingBufReadPos * AI_DATA_SIZE), length * AI_DATA_SIZE);
      *destPos += length;
      *destPos %= shared->FaiStatus.BufLength; //Must be %=, because the SampleCount might not be 2^n
      *aiRingBufReadPos += length;
      *aiRingBufReadPos %= AI_FIFO_SIZE; //If the mask is 2^n, can use &= to replace %= for performance
   }
}

void daq_fai_tasklet_func(unsigned long arg)
{
   daq_device_t  *daq_dev   = (daq_device_t *) arg;
   DEVICE_SHARED *shared    = &daq_dev->shared;
   FAI_STATUS    *FaiStatus = &shared->FaiStatus;
   unsigned      buf_state;
   unsigned long flags;
   __u8          aiIntFlag =  shared->AiIntFlag;

   {
      if (aiIntFlag & INTF_OP_BIT) {
         daq_trace((KERN_ERR "fifo full, discard. sta = 0x%x\n", sta.Value));
         if(!shared->IsEvtSignaled[KdxAiCacheOverflow]) {
            shared->IsEvtSignaled[KdxAiCacheOverflow] = 1;
            daq_device_signal_event(daq_dev, KdxAiCacheOverflow);
         }
      }
      spin_lock_irqsave(&daq_dev->fai_lock, flags);
      buf_state = shared->FaiStatus.BufState;
      shared->FaiStatus.BufState = 0;
      spin_unlock_irqrestore(&daq_dev->fai_lock, flags);

      if ((buf_state & DAQ_IN_BUF_OVERRUN) && !shared->IsEvtSignaled[KdxAiOverrun]) {
        shared->IsEvtSignaled[KdxAiOverrun] = 1;
        daq_device_signal_event(daq_dev, KdxAiOverrun);
      }

      if ((buf_state & DAQ_IN_DATAREADY) && !shared->IsEvtSignaled[KdxAiDataReady]) {
        shared->IsEvtSignaled[KdxAiDataReady] = 1;
        daq_device_signal_event(daq_dev, KdxAiDataReady);
      }

      if (DAQ_IN_MUST_STOP(buf_state, FaiStatus->AcqMode) &&
         (shared->FaiParam.TrigAction != DelayToStop || shared->FaiParam.TrigSource == SignalNone)) {
         daq_fai_stop_acquisition(daq_dev, false);
      }

      if (aiIntFlag & INTF_AP_BIT)
      {
         daq_fai_stop_acquisition(daq_dev, false); // The hardware is stopped, call this function to reset the device to polling mode
      }
   }
}

static inline
void daq_fao_update_status(FAO_CONFIG *cfg, FAO_STATUS *st, unsigned inc_count)
{
   // check data transmitted and update write position
   if (st->ReadPos + inc_count >= st->BufLength) {
      st->BufState  |=  DAQ_OUT_TRANSMITTED;
      st->ReadPos   += inc_count;
      st->ReadPos   %= cfg->SampleCount;
      st->WPRunBack  = 0;
   } else {
      if ((st->ReadPos % cfg->SectionSize) + inc_count >= cfg->SectionSize) {
         st->BufState |= DAQ_OUT_TRANSMITTED;
      }
      st->ReadPos += inc_count;
   }

   // check underrun
   if (st->ReadPos > st->WritePos && !st->WPRunBack) {
      st->BufState |= DAQ_OUT_BUF_UNDERRUN;
   }
}

void daq_fao_tasklet_func(unsigned long arg)
{
   daq_device_t  *daq_dev   = (daq_device_t *) arg;
   DEVICE_SHARED *shared    = &daq_dev->shared;
   FAO_STATUS    *faoStatus = &shared->FaoStatus;
   __u8          aoIntFlag =  shared->AoIntFlag;
   unsigned      buf_state;
   unsigned long flags;

   if (faoStatus->FnState != DAQ_FN_RUNNING)
   {
      return;
   }
   
   spin_lock_irqsave(&daq_dev->fao_lock, flags);
   buf_state = shared->FaoStatus.BufState;
   shared->FaoStatus.BufState = 0;
   spin_unlock_irqrestore(&daq_dev->fao_lock, flags);

   if ( aoIntFlag & INTF_OP_BIT )
   {
      if (shared->FaoStatus.AcqMode != FAO_MODE_INFINITE)
      {
         daq_fao_stop_acquisition(daq_dev, 0);
      }else {
         daq_trace(("@AO @@ hardware underrun\n"));
         buf_state |= DAQ_OUT_BUF_UNDERRUN;
      }
   }

   if ((buf_state & DAQ_OUT_BUF_UNDERRUN) && !shared->IsEvtSignaled[KdxAoUnderrun]) {
     shared->IsEvtSignaled[KdxAoUnderrun] = 1;
     daq_device_signal_event(daq_dev, KdxAoUnderrun);
   }

   if ((buf_state & DAQ_OUT_TRANSMITTED) && !shared->IsEvtSignaled[KdxAoDataTransed]) {
     shared->IsEvtSignaled[KdxAoDataTransed] = 1;
     daq_device_signal_event(daq_dev, KdxAoDataTransed);
   }

   if ((buf_state & DAQ_OUT_TRANSSTOPPED)) {
     daq_fao_stop_acquisition(daq_dev, 0);
   }
}

void daq_cntr_tasklet_func(unsigned long arg)
{
   daq_device_t  *daq_dev   = (daq_device_t *) arg;
   DEVICE_SHARED *shared    = &daq_dev->shared;
   int i;
   __u8 cntrIntFlag = shared->CntrIntFlag;

   //
   // Counter interrupt
   //////////////////////////////////////////////////////////////////////////
   for (i = 0; cntrIntFlag; ++i, cntrIntFlag >>= 1)
   {
      if (cntrIntFlag & 1)
      {
         if (shared->CntrState[i].Operation == TimerPulse)
         {
            if(!shared->IsEvtSignaled[KdxCntTimer0 + i])
            {
               shared->IsEvtSignaled[KdxCntTimer0 + i] = 1;
               daq_device_signal_event(daq_dev, KdxCntTimer0 + i);
            }
         } else if ( shared->CntrState[i].Operation == Primary )
         {
            if(!shared->IsEvtSignaled[KdxCntTerminalCount0 + i])
            {
               shared->IsEvtSignaled[KdxCntTerminalCount0 + i] = 1;
               daq_device_signal_event(daq_dev, KdxCntTerminalCount0 + i);
            }
         }
      }
   }
}

irqreturn_t daq_irq_handler(int irq, void *dev_id)
{
   daq_device_t *daq_dev = (daq_device_t *) dev_id;
   DEVICE_SHARED *shared = &daq_dev->shared;
   FAI_STATUS    *faiStatus = &shared->FaiStatus;
   FAO_STATUS    *faoStatus = &shared->FaoStatus;


   __u8 aiIntFlag = 0;
   __u8 aoIntFlag = 0;
   __u8 cntrIntFlag = 0;

   //
   // Read the Interrupt Flag register (INTF)
   aiIntFlag = AdxMemInB(shared->BarMemBase[1], REG_AD_INTERRUPT_FLAG) & AI_INTF_MASK;
   shared->AiIntFlag = aiIntFlag;

   aoIntFlag = AdxMemInB(shared->BarMemBase[1], REG_DA_INTERRUPT_FLAG) & AO_INTF_MASK;
   shared->AoIntFlag = aoIntFlag;

   cntrIntFlag = AdxMemInB(shared->BarMemBase[1], REG_COUNTER_INTERRUPT_FLAG) & CNTR_INTF_MASK;
   shared->CntrIntFlag = cntrIntFlag;

   if ( !( aiIntFlag  || aoIntFlag || cntrIntFlag ) )
   {
      return IRQ_RETVAL(0);
   }

   //
   //AI Interrupt
   //////////////////////////////////////////////////////////////////////////
   if ( aiIntFlag )
   {
      RING_BUFFER_STATUS *aiRingBufStatus = &shared->AiRingBufStatus;
      __u32  readyDataCount;
      __u32  aiRingBufReadPos; //ring buffer read position, set by HW
      __u32  destPos;    //User buffer destination position

      if (aiIntFlag & INTF_PP_BIT)
      {
         faiStatus->ReadyDataCount = aiRingBufStatus->PPValue;
         
         aiRingBufReadPos = shared->AiRingBufStatus.ReadPointer;
         destPos = faiStatus->WritePos;// user buffer pointer  
         readyDataCount = faiStatus->ReadyDataCount;

         // Finite Mode, only copy data till the end of the buffer
         if ( shared->FaiStatus.AcqMode != DAQ_ACQ_INFINITE )
         {
            readyDataCount = x_min(readyDataCount, shared->FaiStatus.BufLength - shared->FaiStatus.WritePos);
         }
         daq_fai_read_fifo(daq_dev, readyDataCount, &destPos, &aiRingBufReadPos);

         // update FAI buffer status and HW ring buffer status
         spin_lock(&daq_dev->fai_lock);
         shared->AiRingBufStatus.ReadPointer = aiRingBufReadPos;
         daq_fai_update_status( &shared->FaiParam, &shared->FaiStatus, readyDataCount );
         spin_unlock(&daq_dev->fai_lock);
      }
      if ( aiIntFlag & INTF_AP_BIT ) // For About Trigger: copy data to user buffer
      {
         __u32 aiRingBufWritePos = AdxMemInW(shared->BarMemBase[1], REG_AD_WRITTIEN_POINTER);
         aiRingBufReadPos = shared->AiRingBufStatus.ReadPointer;
         destPos = shared->FaiStatus.WritePos;// user buffer pointer
         readyDataCount = ( aiRingBufWritePos >= aiRingBufReadPos ) ? ( aiRingBufWritePos - aiRingBufReadPos) : ( aiRingBufWritePos - aiRingBufReadPos + AI_FIFO_SIZE );
         daq_fai_read_fifo(daq_dev, readyDataCount, &destPos, &aiRingBufReadPos);

         // update FAI buffer status and HW ring buffer status
         spin_lock(&daq_dev->fai_lock);
         shared->AiRingBufStatus.ReadPointer = aiRingBufReadPos;
         daq_fai_update_status( &shared->FaiParam, &shared->FaiStatus, readyDataCount );
         spin_unlock(&daq_dev->fai_lock);
      }

      tasklet_schedule(&daq_dev->fai_tasklet);
      //
      // clear interrupt
      // and Ring Buffer flag
      //
      AdxMemOutB(shared->BarMemBase[1], REG_AD_INTERRUPT_FLAG, aiIntFlag);
      AdxMemOutB(shared->BarMemBase[1], REG_AD_RING_BUFFER_FLAG, aiIntFlag);
      daq_trace(( "*** ISR status: AI %x\n", aiIntFlag));
   }

   if ( aoIntFlag )
   {
      RING_BUFFER_STATUS *aoRingBufStatus = &shared->AoRingBufStatus;

      daq_trace(( "*** ISR status: AO %x  FIFO RP=%d, FIFO WP=%d\n", aoIntFlag, 
                 AdxMemInD(shared->BarMemBase[1], REG_DA_READ_POINTER),
                 AdxMemInD(shared->BarMemBase[1], REG_DA_WRITE_POINTER)));

      if (aoIntFlag & INTF_PP_BIT)
      {
         faoStatus->DataCopyCount = aoRingBufStatus->PPValue;
      }

      if (!(shared->FaoStatus.BufState & DAQ_OUT_TRANSSTOPPED) && faoStatus->DataLeft > 0)
      {
         __u32 aoRingBufWritePointer = ( shared->AoRingBufStatus.WritePointer ) & AO_FIFO_MASK;
         __u32 aoSourcePointer = shared->FaoStatus.ReadPos; // user buffer start position
         __u32 incCount =  faoStatus->DataCopyCount;  //Fill the FIFO using the calculated transmitted count
         __u16         *data_buf = (__u16*)daq_dev->fao_buffer.kaddr;
         __u32 i;

         if (shared->FaoStatus.AcqMode != FAO_MODE_INFINITE)
         {
            incCount = faoStatus->DataLeft < incCount ? faoStatus->DataLeft : incCount;
            faoStatus->DataLeft -= incCount;
         }

         daq_trace(("Before =====================    ReadPos= %d, aoRingBufWritePointer=%d incCount=%d\n", faoStatus->ReadPos, aoRingBufWritePointer, incCount));
         for (i = 0; i < incCount; ++i )
         {
            AdxMemOutW(shared->BarMemBase[2], AO_RING_BUFFER_OFFSET + 4*aoRingBufWritePointer + 2, data_buf[aoSourcePointer]<<4 );
            aoSourcePointer++;
            aoSourcePointer %= (faoStatus->BufLength);
            aoRingBufWritePointer++;
            aoRingBufWritePointer &= AO_FIFO_MASK;     //If the mask is 2^n -1(all bit are 1), can use &= to replace %= for performance
         }
         daq_trace(("before update RP=%d, WP=%d, WPRunBack=%d; FIFO WP=%d\n", faoStatus->ReadPos, faoStatus->WritePos, faoStatus->WPRunBack, shared->AoRingBufStatus.WritePointer));
         spin_lock(&daq_dev->fao_lock);
         daq_fao_update_status( &shared->FaoParam, &shared->FaoStatus, incCount );
         shared->FaoStatus.ReadPos = aoSourcePointer;
         shared->AoRingBufStatus.WritePointer = aoRingBufWritePointer;
         spin_unlock(&daq_dev->fao_lock);
      }
 
      tasklet_schedule(&daq_dev->fao_tasklet);
      //
      // Clear specific Interrupt Flag, and Ring Buffer flag
      //
      AdxMemOutB(shared->BarMemBase[1], REG_DA_INTERRUPT_FLAG, aoIntFlag);
      AdxMemOutB(shared->BarMemBase[1], REG_DA_RING_BUFFER_FLAG, aoIntFlag);
   }

   //
   // Counter Interrupt
   //////////////////////////////////////////////////////////////////////////
   if ( cntrIntFlag )
   {
      daq_trace(( "*** ISR status: Counter %x\n", cntrIntFlag));
      tasklet_schedule(&daq_dev->cntr_tasklet);
      AdxMemOutB(shared->BarMemBase[1], REG_COUNTER_INTERRUPT_FLAG, cntrIntFlag);
   }

   return IRQ_RETVAL(1);
}
