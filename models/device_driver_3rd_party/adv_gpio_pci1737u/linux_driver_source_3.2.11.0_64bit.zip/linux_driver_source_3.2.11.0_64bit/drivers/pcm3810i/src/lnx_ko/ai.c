/*
 * ai.c
 *
 *  Created on: 2011-11-10
 *      Author: 
 */

#include "kdriver.h"
#include "hw.h"

static
unsigned daq_ai_calc_phy_chanrange(unsigned char *chType, unsigned  phyStart, unsigned logCount)
{
   unsigned nextChan;

   if (chType[phyStart] == Differential) {
      phyStart &= ~0x1;
   }

   nextChan = phyStart;
   while (logCount--) {
      if (chType[nextChan] == Differential) {
         nextChan += 2;
      } else {
         ++nextChan;
      }
      nextChan &= AI_CHL_MASK;
   }

   return (((nextChan - 1) & AI_CHL_MASK) << 16) | phyStart;
}


static
int daq_ai_configure_channel(daq_device_t *daq_dev) 
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   __u32 i;

   // Stop AD
   AD_CONTROL_REG adCtrl = {0};
   AdxMemOutD(shared->BarMemBase[1], REG_AD_CONTROL, adCtrl.Value);

   // Channel connection
   {
      __u8 curSd = AdxMemInB(shared->BarMemBase[1], REG_SINGLE_END_DIFFERENTIAL);
      __u8 setSd = 0;
      for ( i = 0; i < AI_CHL_COUNT/2; ++i )
      {
         if ( shared->AiChanType[2*i] ) //Each bit stand for 2 channels  
         {
            setSd |= (1<<i);
         }
      }
      if ( curSd != setSd )
      {
         AdxMemOutB(shared->BarMemBase[1], REG_SINGLE_END_DIFFERENTIAL, setSd);
      }

      shared->AiLogChanCount = daq_ai_calc_log_chan_count( shared->AiChanType, AI_CHL_COUNT );
   }

   // Gain
   {
      __u8 curChGain[AI_CHL_COUNT];
      for ( i = 0; i < AI_CHL_COUNT; ++i )
      {
         curChGain[i] = AdxMemInB(shared->BarMemBase[1], REG_AD_RANGE_SETTING + i * REG_STEP );
         if ( curChGain[i] != shared->AiChanGain[i] )
         {
            AdxMemOutB(shared->BarMemBase[1], REG_AD_RANGE_SETTING + i * REG_STEP, shared->AiChanGain[i]);
         }
      }
   }

   // Set Polling Mode
   adCtrl.ConvEn = 1;
   adCtrl.PollEn = 1;
   AdxMemOutD(shared->BarMemBase[1], REG_AD_CONTROL, adCtrl.Value);

   return 0;
}

static 
void daq_ai_calc_section(DEVICE_SHARED *shared)
{
   FAI_CONFIG  *faiParam  = &shared->FaiParam;
   RING_BUFFER_STATUS *aiRingBufStatus = &shared->AiRingBufStatus;
   __u16       halfFifo = AI_FIFO_SIZE/2;
   
   if (faiParam->SectionSize >= halfFifo)
   {
      aiRingBufStatus->PPValue = halfFifo;
   }else
   {
      aiRingBufStatus->PPValue = faiParam->SectionSize;
   }
   aiRingBufStatus->ReadPointer = 0;
   daq_trace(("AI SampleCount=%d, SectionSize=%d,SectionReadyCount=%d PPValue is %d ModSectSP is %d\n", faiParam->SampleCount, faiParam->SectionSize, faiStatus->SectionReadyCount, aiRingBufStatus->PPValue, aiRingBufStatus->ModSectSP));

}

static
int daq_fai_start_hardware(daq_device_t *daq_dev)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   FAI_CONFIG  *faiParam = &shared->FaiParam;
   FAI_STATUS *faiStatus = &shared->FaiStatus;
   AD_CLOCK_SOURCE_CONTROL_REG adClkSrc = {0};
   AD_CONTROL_REG adCtrl = {0}; //Disable Polling Mode, adCtrl.PollEn = 0
   __u32 ch_range, scanClkDiv, scanCount;

   // Register setup ----------------------------------------------
   // Stop A/D (Set as Static Mode) and Disable Interrupt
   AdxMemOutD( shared->BarMemBase[1], REG_AD_CONTROL, 0 );
   AdxMemOutD( shared->BarMemBase[1], REG_AD_INTERRUPT_FLAG, 0 );

   // Clear Ring Buffer and W/R Flag
   AdxMemOutD( shared->BarMemBase[1], REG_AD_RING_BUFFER_FLAG, 0x1F );
   AdxMemOutD( shared->BarMemBase[1], REG_AD_WRITTIEN_POINTER, 0 );

   // reset trigger 
   AdxMemOutD( shared->BarMemBase[1], REG_CLOCK_SOURCE_CONTROL, 0 );
   AdxMemOutD( shared->BarMemBase[1], REG_AD_TRIGGER_COUNTER, 0 );

   // Set Multiplexer Control
   ch_range = daq_ai_calc_phy_chanrange(shared->AiChanType, faiParam->PhyChanStart, faiParam->LogChanCount );
   AdxMemOutD( shared->BarMemBase[1], REG_MULTIPLEXER_CONTROL, ch_range );
   daq_trace(("CHScanRange=0x%x\n", ch_range));

   // Set Pacer Divisor
   AdxMemOutD( shared->BarMemBase[1], REG_AD_PACER_DIVISOR, shared->FaiParam.PacerDivider );
   // Set Scan Clock divisor
   scanClkDiv = (shared->FaiParam.ScanClkSource == SignalNone) ? shared->FaiParam.PacerDivider : shared->FaiParam.ScanClkDivider;
   AdxMemOutD( shared->BarMemBase[1], REG_AD_SCAN_CLK_DIVISOR, scanClkDiv );

   // Set Iteration counter/Scan count
   scanCount = (shared->FaiParam.ScanClkSource == SignalNone) ? 1 : shared->FaiParam.ScanCount; //Scan Count can't be set as 0
   AdxMemOutD( shared->BarMemBase[1], REG_AD_ITERATION_COUNTER, scanCount );

   // Set AD clock source
   adClkSrc.Value = AdxMemInD( shared->BarMemBase[1], REG_CLOCK_SOURCE_CONTROL );
   adClkSrc.AdConv = shared->FaiParam.ConvClkSource == SigInternalClock ? 0 : 1;

   if ( shared->FaiParam.ScanClkSource == SignalNone )
   {
      // Do not use scan clock function, however the hardware sampling need ConvertClock and ScanClock 
      // Set the ScanClock source according to the Convert Clock source
      adClkSrc.AdScan = ( shared->FaiParam.ConvClkSource == SigInternalClock ) ? AI_SCAN_CLK_SRC_INTERNAL : AI_SCAN_CLK_SRC_EXT_CONV_CLK;
   } else {
      adClkSrc.AdScan = ( shared->FaiParam.ScanClkSource == SigInternalClock ) ? AI_SCAN_CLK_SRC_INTERNAL : AI_SCAN_CLK_SRC_EXTERNAL;
   }

   daq_trace(("ConvClkDiv = %d, ScanClkDiv = %d. ScanCount = %d\n", shared->FaiParam.PacerDivider, scanClkDiv, shared->FaiParam.ScanCount ));

   // Set Channel scanner switch method
   //0: Channel scanner will jump to next channel while AD_CONV_CLK arrives
   //1: Channel scanner will jump to next channel while AD_SCAN_CLK arrives
   adClkSrc.ChScanSel = 0;

   if ( shared->FaiParam.TrigSource == SignalNone
      || shared->FaiParam.TrigAction == ActionNone ) //do not use trigger, work as PacerMode
   {
      adCtrl.TrgEn = 0;
   } else {
      adCtrl.TrgEn = 1;
      if ( shared->FaiParam.TrigAction == DelayToStart )
      {
         adClkSrc.AdTrgMode = 0;
      } else if ( shared->FaiParam.TrigAction == DelayToStop ) {
         adClkSrc.AdTrgMode = 1;
         adCtrl.ApIntEn = 1;    //Enable AP for about trigger
      }
      adClkSrc.AdTrgSource = ( shared->FaiParam.TrigSource == SigExtDigTrigger0 ) ? 0 : 1; //0: Digital Trig, 1: Analog Trig
      adClkSrc.AdTrgEdge = (shared->FaiParam.TrigEdge == RisingEdge ) ? 0 : 1;

      //Set the trigVoltage
      if ( shared->FaiParam.TrigSource == SigExtAnaTrigger )
      {
         ANALOG_CALIBRATION_REG anaCal = {0};

         AdxMemOutD( shared->BarMemBase[1], REG_AD_CONTROL, adCtrl.Value );
         AdxMemOutD( shared->BarMemBase[1], REG_CLOCK_SOURCE_CONTROL, adClkSrc.Value );

         //By set the Analog calibration command and data register
         anaCal.Cmd = CAL_AD_TRG_VOLT_ADJ;
         anaCal.Data = shared->FaiParam.TrigLevelBin;
         AdxMemOutD( shared->BarMemBase[1], REG_ANALOG_CALIBRATION, anaCal.Value );
         daq_trace(("Analog Trigger Volatge: TrigBinary%d\n",shared->FaiParam.TrigLevelBin ));
      }
   }

   adClkSrc.AdPauseGatePriority = (shared->FaiParam.AiPauseGatePolarity == 0) ? 0 : 1;

   daq_trace(("adClkSrc.Value= 0x%x\n", adClkSrc.Value));
   AdxMemOutD( shared->BarMemBase[1], REG_CLOCK_SOURCE_CONTROL, adClkSrc.Value );

   //Reset W/R pointer
   AdxMemOutW( shared->BarMemBase[1], REG_AD_WRITTIEN_POINTER, 0 );
   AdxMemOutW(shared->BarMemBase[1], REG_AD_PERIODIC_POINTER, shared->AiRingBufStatus.PPValue);
   // Set Ring buffer specific pointer
   adCtrl.OpIntEn = 1;
   adCtrl.PpIntEn = 1;
   AdxMemOutD(shared->BarMemBase[1], REG_AD_CONTROL, adCtrl.Value);

   //The delay Count must be set after the PP Int enabled and before AI start
   //Set Trigger delay Count
   if ( !( shared->FaiParam.TrigSource == SignalNone || shared->FaiParam.TrigAction == ActionNone ) )
   {
      shared->FaiParam.ActualDelayCount = shared->FaiParam.TrigDelayCount;
      if ( shared->FaiParam.ScanCount != 0 ) // use Scan Clock
      {
         //shared->FaiParam.ActualDelayCount = shared->FaiParam.TrigDelayCount / ( shared->FaiParam.ScanCount );
         //if ( shared->FaiParam.TrigDelayCount % ( shared->FaiParam.ScanCount ) )
         //{
         //   shared->FaiParam.ActualDelayCount++;
         //}
         daq_trace(("Set DelayCount=%d, ChanCount=%d, ScanCount=%d, ActualDelayCount=%d\n", shared->FaiParam.TrigDelayCount, shared->FaiParam.LogChanCount, shared->FaiParam.ScanCount, shared->FaiParam.ActualDelayCount));
      }
      AdxMemOutD( shared->BarMemBase[1], REG_AD_TRIGGER_COUNTER, shared->FaiParam.ActualDelayCount / shared->FaiParam.LogChanCount );
   }

   // Set Pacer Mode to start A/D
   adCtrl.ConvEn = 1;
   if ( shared->FaiParam.AiPauseGateEn )
   {
      adCtrl.GateEn = 1; //Enable pause gate
   }

   AdxMemOutD(shared->BarMemBase[1], REG_AD_CONTROL, adCtrl.Value);

   daq_trace(("adCtrl.Value = 0x%x\n", adCtrl.Value));
   daq_trace(("ConvClkSrc:0x%x\n", shared->FaiParam.ConvClkSource));
   daq_trace(("ScanClkSrc:0x%x\n", shared->FaiParam.ScanClkSource));

   // add the task to wait_queue for sync read
   if (faiStatus->AcqMode == DAQ_ACQ_FINITE_SYNC){
      return wait_event_interruptible(daq_dev->fai_queue, faiStatus->FnState != DAQ_FN_RUNNING);
   }

   return 0;
}

//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------
void daq_ai_initialize_hw(daq_device_t *daq_dev)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   __u32         saiScanRange;
   int           i;
   AD_CONTROL_REG adCtrl = {0};
   AD_CLOCK_SOURCE_CONTROL_REG adClkSrcCtrl = {0};
   __u8 sdCfg = 0;


   // Stop AD
   AdxMemOutD( shared->BarMemBase[1], REG_AD_CONTROL, adCtrl.Value );

   // Stop Interrupt
   AdxMemOutB( shared->BarMemBase[1], REG_AD_INTERRUPT_FLAG, 0 );

   // Reset WP, RP of ring buffer
   AdxMemOutD( shared->BarMemBase[1], REG_AD_RING_BUFFER_FLAG, AI_INTF_MASK );
   AdxMemOutD( shared->BarMemBase[1], REG_AD_WRITTIEN_POINTER, 0 );

   // Set Single-end/Differential setting
   for ( i = 0; i < AI_CHL_COUNT/2; ++i )
   {
      if ( shared->AiChanType[2*i] )
      {
         sdCfg |= ( 1 << i );
      }
   }
   AdxMemOutB( shared->BarMemBase[1], REG_SINGLE_END_DIFFERENTIAL, sdCfg );

   // Set Multiplexer Control
   saiScanRange = daq_ai_calc_phy_chanrange( shared->AiChanType, shared->SaiAutoConvChStart, shared->SaiAutoConvChCount );
   AdxMemOutD( shared->BarMemBase[1], REG_MULTIPLEXER_CONTROL, saiScanRange );

   //Set the FIFO size
   AdxMemOutB( shared->BarMemBase[1], REG_AD_RING_BUFFER_SIZE, AI_RING_BUFFER_COUNT - 1 );

   // Set Pacer divisor setting
   // Calculate the SAI Auto convert clock divider etc.. here, because the registry setting maybe different with the initial value
   // Note: DO NOT touch floating-point!
   if ( shared->SaiAutoConvClkDiv < AI_CLK_BASE / AI_MAX_PACER)
   {
      shared->SaiAutoConvClkDiv = AI_CLK_BASE / AI_MAX_PACER;
   }
   AdxMemOutD( shared->BarMemBase[1], REG_AD_PACER_DIVISOR, shared->SaiAutoConvClkDiv );

   // Set A/D channels range setting
   for( i = 0; i < AI_CHL_COUNT; i++ )
   {
      AdxMemOutB( shared->BarMemBase[1], REG_AD_RANGE_SETTING + (i * 4), shared->AiChanGain[i] );
   }

   // Set Scan Clock divisor
   AdxMemOutD( shared->BarMemBase[1], REG_AD_SCAN_CLK_DIVISOR, shared->SaiAutoConvClkDiv );

   // Set Scan counter, always set 1 for SAI mode
   AdxMemOutD( shared->BarMemBase[1], REG_AD_ITERATION_COUNTER, 1 );

   // Set Internal Clock Source
   adClkSrcCtrl.AdConv = INTERNAL_CLOCK;
   adClkSrcCtrl.AdPauseGatePriority = 0;
   adClkSrcCtrl.AdScan = INTERNAL_CLOCK;
   adClkSrcCtrl.AdTrgEdge = RISING_EDGE;
   adClkSrcCtrl.AdTrgMode = DELAY_TRIGGER;
   adClkSrcCtrl.AdTrgSource = TTL_TRIG;
   adClkSrcCtrl.AioCal = NORMAL;
   adClkSrcCtrl.ChScanSel = 0;//AD_SCAN_CLK here should always set as internal, because the driver start up with SAI mode
   adClkSrcCtrl.TimeBaseSrc = INTERNAL_CLOCK;
   AdxMemOutD( shared->BarMemBase[1], REG_CLOCK_SOURCE_CONTROL, adClkSrcCtrl.Value );

   // Set Polling Mode
   adCtrl.ConvEn = 1;
   adCtrl.PollEn = 1;
   AdxMemOutD( shared->BarMemBase[1], REG_AD_CONTROL, adCtrl.Value );

   shared->AiLogChanCount = daq_ai_calc_log_chan_count(shared->AiChanType, AI_CHL_COUNT);
}

void daq_fai_stop_acquisition(daq_device_t *daq_dev, int cleanup)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   FAI_STATUS *faiStatus = &shared->FaiStatus;

   AD_CONTROL_REG adCtrl = {0};
   AD_CLOCK_SOURCE_CONTROL_REG adClkSrc = {0};
   __u32  saiScanRange;
   unsigned long flags;

   spin_lock_irqsave(&daq_dev->fai_lock, flags);
   if (faiStatus->FnState != DAQ_FN_RUNNING){
      spin_unlock_irqrestore(&daq_dev->fai_lock, flags);
   } else {
      faiStatus->FnState = DAQ_FN_STOPPED;
      spin_unlock_irqrestore(&daq_dev->fai_lock, flags);

      // Stop hardware
      AdxMemOutD( shared->BarMemBase[1], REG_AD_CONTROL, adCtrl.Value );

      // Reset A/D Clock Source Control to be Internal
      AdxMemOutB( shared->BarMemBase[1], REG_CLOCK_SOURCE_CONTROL, (__u8)adClkSrc.Value);

      // Clear Interrupt Flag
      AdxMemOutB( shared->BarMemBase[1], REG_AD_INTERRUPT_FLAG, AI_INTF_MASK );

      // Clear Ring Buffer W/R Flag
      AdxMemOutB( shared->BarMemBase[1], REG_AD_RING_BUFFER_FLAG, AI_INTF_MASK );

      // Reset Ring Buffer W/R Pointer      
      AdxMemOutB( shared->BarMemBase[1], REG_AD_WRITTIEN_POINTER, 0 );

      // Set Multiplexer Control
      saiScanRange = daq_ai_calc_phy_chanrange( shared->AiChanType, shared->SaiAutoConvChStart, shared->SaiAutoConvChCount );
      AdxMemOutD( shared->BarMemBase[1], REG_MULTIPLEXER_CONTROL, saiScanRange );

      // Set Pacer divisor setting
      AdxMemOutD( shared->BarMemBase[1], REG_AD_PACER_DIVISOR, shared->SaiAutoConvClkDiv );

      // Set Scan Clock divisor
      AdxMemOutD( shared->BarMemBase[1], REG_AD_SCAN_CLK_DIVISOR, shared->SaiAutoConvClkDiv );

      // Set Scan counter, always set 1 for SAI mode
      AdxMemOutD( shared->BarMemBase[1], REG_AD_ITERATION_COUNTER, 1 );

      // Start SAI
      adCtrl.PollEn = 1;
      adCtrl.ConvEn = 1;
      AdxMemOutD( shared->BarMemBase[1], REG_AD_CONTROL, adCtrl.Value );

      if ( (shared->FaiParam.TrigAction == DelayToStop) && (shared->FaiParam.TrigSource != SignalNone) )
      {
         __u32 availDataStart = 0;
         __u32 availDataCount = 0;
         __u32 triggerPos = 0;
		 __u32 TrigDelayCount = shared->FaiParam.TrigDelayCount * shared->FaiParam.ScanCount;
         if ( TrigDelayCount > shared->FaiParam.SampleCount )
         {
            triggerPos = 0;
            availDataStart = 0;
            availDataCount = shared->FaiParam.SampleCount;
         } else {
/*            if ( shared->FaiStatus.WritePos > shared->FaiParam.TrigDelayCount )
            {
               triggerPos = shared->FaiStatus.WritePos - shared->FaiParam.TrigDelayCount + 1;
               availDataStart = 0;
               availDataCount = shared->FaiStatus.WritePos;
            } else {
               triggerPos = shared->FaiParam.SampleCount - (shared->FaiParam.TrigDelayCount - shared->FaiStatus.WritePos) + 1;
               availDataStart = shared->FaiStatus.WritePos;
               availDataCount = shared->FaiParam.SampleCount;
            }
            triggerPos %= shared->FaiStatus.BufLength;*/
            if ( shared->FaiStatus.WritePos >= TrigDelayCount )
            {
               triggerPos = shared->FaiStatus.WritePos - TrigDelayCount + 1;
               if ( shared->FaiStatus.WPRunBack )//Case0
               {
                  availDataStart = shared->FaiStatus.WritePos;
                  availDataCount = shared->FaiParam.SampleCount;
               } else {//Case1                
                  availDataStart = 0;
                  availDataCount = shared->FaiStatus.WritePos;
               }

            } else {
               triggerPos = shared->FaiParam.SampleCount - ( TrigDelayCount - shared->FaiStatus.WritePos ) + 1;
               if ( shared->FaiStatus.WPRunBack )//Case2
               {
                  availDataStart = shared->FaiStatus.WritePos;
                  availDataCount = shared->FaiParam.SampleCount;
               }
               else //case3
               {
                  availDataStart = 0;
                  availDataCount = shared->FaiStatus.WritePos;
               }
            }
            triggerPos %= shared->FaiStatus.BufLength;
         }

         if ( availDataCount == shared->FaiParam.SampleCount )
         {
            shared->FaiStatus.WPRunBack ++;
            shared->FaiStatus.WPRunBack_TDtp++;
/*            ((int32*)&shared->FaiStatus.WPRunBack) += 1;
            ((int32*)&shared->FaiStatus.WPRunBack_TDtp) += 1;*/
         }

         //Adjust the RP(to indicate the max available data)
         if ( shared->FaiStatus.ReadPos <= availDataStart )
         {
            shared->FaiStatus.ReadPos = availDataStart;
         }
         daq_trace(("RP=%d, WP=%d, WPRunBack=%d; TrigPos=%d, TrigEnd=%d, AvailDataStart=%d, AvailDataCount=%d, 1stAvailData=0x%x, 1stTrgData=0x%x\n",
            shared->FaiStatus.ReadPos, shared->FaiStatus.WritePos, shared->FaiStatus.WPRunBack, triggerPos, shared->FaiStatus.WritePos, availDataStart, availDataCount, userBuffer[availDataStart], userBuffer[triggerPos]));
      }

      if (!shared->IsEvtSignaled[KdxAiStopped]) {
         shared->IsEvtSignaled[KdxAiStopped] = 1;
         daq_device_signal_event(daq_dev, KdxAiStopped);
      }
      wake_up_interruptible(&daq_dev->fai_queue);
   }

   if (cleanup) {
      daq_umem_unmap(&daq_dev->fai_buffer);

      spin_lock_irqsave(&daq_dev->fai_lock, flags);
      faiStatus->FnState = DAQ_FN_IDLE;
      spin_unlock_irqrestore(&daq_dev->fai_lock, flags);
   }
}

int daq_ioctl_ai_set_channel(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   AI_SET_CHAN   xbuf;
   AI_CHAN_CFG   cfg[AI_CHL_COUNT];
    __u32 phyCH;
  __u32         i;

   if (unlikely(shared->FaiStatus.FnState == DAQ_FN_RUNNING)){
      return -EBUSY;
   }

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   if (unlikely(xbuf.PhyChanCount > AI_CHL_COUNT)){
      xbuf.PhyChanCount = AI_CHL_COUNT;
   }
   if (unlikely(copy_from_user(cfg, (void *)xbuf.ChanCfg, sizeof(AI_CHAN_CFG) * xbuf.PhyChanCount))){
      return -EFAULT;
   }


   // check the channel's new setting and set the hardware if possible.
   for (i = 0; i < xbuf.PhyChanCount; ++i )
   {
      // save the current device configuration
      phyCH = (xbuf.PhyChanStart + i) & AI_CHL_MASK;
      if (xbuf.SetWhich & AI_SET_CHSCTYPE )
      {
         shared->AiChanType[ phyCH ] = cfg[i].SCType;
      }
      if (xbuf.SetWhich & AI_SET_CHGAIN)
      {
         shared->AiChanGain[ phyCH ] = cfg[i].Gain;
      }
   }

   daq_ai_configure_channel(daq_dev);

   // Re-calculate the logical channel count
   shared->AiLogChanCount = daq_ai_calc_log_chan_count( shared->AiChanType, AI_CHL_COUNT );
   return 0;
}

int daq_ioctl_fai_set_param(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;

   FAI_CONFIG    xbuf;
   unsigned long flags;
   int           ret = 0;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   spin_lock_irqsave(&daq_dev->fai_lock, flags);
   if (unlikely(shared->FaiStatus.FnState != DAQ_FN_IDLE)){
      ret = -EBUSY;
   } else {
      shared->FaiParam              = xbuf;
      shared->FaiParam.PhyChanStart = xbuf.PhyChanStart & AI_CHL_MASK;
      shared->FaiParam.LogChanCount = x_min(xbuf.LogChanCount, shared->AiLogChanCount);
   }
   spin_unlock_irqrestore(&daq_dev->fai_lock, flags);

   if (likely(!ret)){
      daq_device_signal_event(daq_dev, KdxDevPropChged);
   }

   return ret;
}

int daq_ioctl_fai_set_buffer(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   FAI_CONFIG  *faiParam = &shared->FaiParam;
   FAI_STATUS *faiStatus = &shared->FaiStatus;

   unsigned long flags;
   int           ret = 0;

   if (unlikely(!faiParam->SampleCount)) {
      return -EINVAL;
   }

   spin_lock_irqsave(&daq_dev->fai_lock, flags);
   if (unlikely(faiStatus->FnState != DAQ_FN_IDLE)){
      ret = -EBUSY;
   } else {
      faiStatus->FnState   = DAQ_FN_READY;
      faiStatus->BufLength = faiParam->SampleCount;
   }
   spin_unlock_irqrestore(&daq_dev->fai_lock, flags);

   do {
      if (unlikely(ret)){
         break;
      }

      ret = daq_umem_map(arg, faiParam->SampleCount * AI_DATA_SIZE, 1, &daq_dev->fai_buffer);
   } while (0);

   if (ret){
      daq_umem_unmap(&daq_dev->fai_buffer);
      faiStatus->FnState = DAQ_FN_IDLE;
   }

   return ret;
}

int daq_ioctl_fai_start(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   unsigned long flags;
   int           ret = 0;

   spin_lock_irqsave(&daq_dev->fai_lock, flags);
   do{
      if (shared->FaiStatus.FnState == DAQ_FN_IDLE){
         ret = -EINVAL;
         break;
      }

      if (shared->FaiStatus.FnState == DAQ_FN_RUNNING){
         ret = -EBUSY;
         break;
      }

      memset(shared->IsEvtSignaled, 0, sizeof(shared->IsEvtSignaled));
      memset(&shared->FaiStatus, 0, sizeof(FAI_STATUS));
      shared->FaiStatus.FnState   = DAQ_FN_RUNNING;
      shared->FaiStatus.AcqMode   = (__u32)arg;
      shared->FaiStatus.BufLength = shared->FaiParam.SampleCount;
   } while (0);
   spin_unlock_irqrestore(&daq_dev->fai_lock, flags);

   if (ret){
      return ret;
   }

   daq_device_clear_event(daq_dev, KdxAiDataReady);
   daq_device_clear_event(daq_dev, KdxAiOverrun);
   daq_device_clear_event(daq_dev, KdxAiStopped);
   daq_device_clear_event(daq_dev, KdxAiCacheOverflow);
   
   daq_ai_calc_section(shared);
   ret = daq_fai_start_hardware(daq_dev);

   return ret;
}

int daq_ioctl_fai_stop(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;

   if (shared->FaiStatus.FnState == DAQ_FN_IDLE){
      return 0;
   }

   daq_fai_stop_acquisition(daq_dev, arg & FAI_STOP_FREE_RES);

   return 0;
}

