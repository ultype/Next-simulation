/*
 * hw.h
 *
 *  Created on: 2011-10-19
 *      Author: 
 */

#ifndef _KERNEL_MODULE_HW_H_
#define _KERNEL_MODULE_HW_H_

#define REG_BID_BAR_INDICATOR    0x00
#define REG_PCB_VERSION          0x04
#define REG_PLD_VERSION          0x08
#define REG_FIRMWARE_VERSION     0x0C

#define REG_STEP  4   //Register offset of Ch n+1 - Ch n

#define INTERNAL_CLOCK  0x0
#define EXTERNAL_CLOCK  0x1


/////////////////////////////////////////////
// AI
// Control Register (BAR1+0x00)
#define REG_AD_CONTROL              0x00
// Mode setting
//#define STATIC_MODE              0x0
//#define POLLING_MODE             0x1
//#define PACER_MODE               0x2
// Bit value
#define POLL_EN         0x1
#define CONV_EN         0x2
#define TRG_EN          0x10
#define GATE_EN         0x20
typedef union _AD_CONTROL_REG{
   __u32 Value;
   struct{
      __u32 PollEn : 1;
      __u32 ConvEn : 1;
      __u32 Reserved1 : 2;

      __u32 TrgEn  : 1;
      __u32 GateEn : 1;
      __u32 Reserved2 : 10;

      __u32 SpIntEn : 1;
      __u32 PpIntEn : 1;
      __u32 EpIntEn : 1;
      __u32 OpIntEn : 1;
      __u32 ApIntEn : 1;
      __u32 Reserved3 : 11;
   };
}AD_CONTROL_REG;

// Interrupt Flag
#define INTF_SP_BIT                     0x01
#define INTF_PP_BIT                     0x02
#define INTF_EP_BIT                     0x04
#define INTF_OP_BIT                     0x08
#define INTF_AP_BIT        0x10
#define AI_INTF_MASK       0x1F
// Interrupt Flag (BAR1+0x04)
#define REG_AD_INTERRUPT_FLAG       0x04

// Ring Buffer Periodic Pointer (BAR1+0x08)
#define REG_AD_PERIODIC_POINTER     0x08

// Ring Buffer Specific Pointer (BAR1+0x0C)
#define REG_AD_SPECIFIC_POINTER     0x0C

// Ring Buffer flag (BAR1+0x10)
#define REG_AD_RING_BUFFER_FLAG     0x10

// Ring Buffer Written Pointer (BAR1+0x14)
#define REG_AD_WRITTIEN_POINTER     0x14

// 12bit
#define REG_AD_RING_BUFFER_SIZE     0x18

// 32bit,change from 24 bit to 32 bit
#define REG_AD_TRIGGER_COUNTER      0x20

// 16bit
#define REG_AD_ITERATION_COUNTER    0x24

// 16bit
#define REG_AD_SCAN_COUNTER         0x28

// 32bit
#define REG_AD_PACER_DIVISOR        0x30

// 32bit
#define REG_AD_SCAN_CLK_DIVISOR     0x34

// Multiplexer Control (BAR1+0x40)
#define REG_MULTIPLEXER_CONTROL     0x40
typedef union _AD_MUX_REG{
   __u32 Value;
   struct{
      __u32 StartChan : 4;
      __u32 Reserved1 : 12;
      __u32 StopChan  : 4;
      __u32 Reserved2 : 12;
   };
}AD_MUX_REG;

// AD Source Selection 
#define REG_CLOCK_SOURCE_CONTROL     0x44
typedef union _AD_CLOCK_SOURCE_CONTROL_REG{
   __u32 Value;
   struct{
      __u32 AdConv : 1; 
      __u32 AdScan : 2; 
      __u32 ChScanSel : 1; 
      __u32 Reserved1 : 3;
      __u32 AioCal : 1; 

      __u32 AdTrgMode : 1; 
      __u32 Reserved2 : 1; 
      __u32 AdTrgSource  : 1; 
      __u32 AdTrgEdge  : 1; 
      __u32 Reserved3 : 4;  

      __u32 AdPauseGatePriority : 1; 
      __u32 Reserved4 : 7;

      __u32 TimeBaseSrc : 1; 
      __u32 Reserved5 : 7;
   };
}AD_CLOCK_SOURCE_CONTROL_REG;


#define  AI_SCAN_CLK_SRC_INTERNAL 0
#define  AI_SCAN_CLK_SRC_EXTERNAL 2
#define  AI_SCAN_CLK_SRC_EXT_CONV_CLK 3

//#define HIGH_LEVEL 0
//#define LOW_LEVEL  1

#define RISING_EDGE  0
#define FALLING_EDGE 1

#define DELAY_TRIGGER  0
#define ABOUT_TRIGGER  1

#define TTL_TRIG   0
#define ANA_TRIG   1

#define NORMAL     0
#define ANA_CAL    1

// Single-ended/Differential Setting
// 8bit
#define REG_SINGLE_END_DIFFERENTIAL 0x50

// A/D Channel Range Setting (BAR1+0x60 ~ 0x9C)
#define REG_AD_RANGE_SETTING        0x60

//////////////////////////////////////////////////////////////////////////
// Below register are for Examination of Engineer Sample Only, 
// not available in finial MP Version
//____________________________________________
// 12bit
#define REG_AD_READ_POINTER         0xA0

// 12bit
#define REG_AD_PERIODIC_POINTER_COUNTER 0xA4

// 24bit
#define REG_AD_TRIGGER_COUNTER_READ_BACK 0xA8
//____________________________________________
//////////////////////////////////////////////////////////////////////////

//################################################################
// AO
//
// 12bit
#define REG_DA_CH0_DATA                 0x100

#define REG_DA_CH1_DATA                 0x104

#define AO_INTF_MASK                    0xF
#define REG_DA_INTERRUPT                0x110
typedef union _DA_INTERRUPT_REG{
   __u32 Value;
   struct{
      __u32 ConvEn : 1;
      __u32 Reserevd1 : 3;

      __u32 TrgEn : 1;
      __u32 Reserevd2 : 11;

      __u32 SpIntEn : 1;
      __u32 PpIntEn : 1;
      __u32 EpIntEn : 1;
      __u32 UnIntEn : 1;

      __u32 Reserved2 : 12;
   };
}DA_INTERRUPT_REG;

#define REG_DA_INTERRUPT_FLAG         0x114
typedef union _DA_INTERUPT_FALG_REG{
   __u32 Value;
   struct{
      __u32 Sp : 1;
      __u32 Pp : 1;
      __u32 Ep : 1;
      __u32 Un : 1;
      __u32 Reserved : 28;
   };
}DA_INTERRUPT_FLAG_REG;

// 12bit
#define REG_DA_PERIODIC_POINTER       0x118

// 12bit
#define REG_DA_SPECIFIC_POINTER       0x11C

#define REG_DA_RING_BUFFER_FLAG       0x120
typedef union _DA_RING_BUFFER_FALG_REG{
   __u32 Value;
   struct{
      __u32 Sp : 1;
      __u32 Pp : 1;
      __u32 Ep : 1;
      __u32 Un : 1;
      __u32 Reserved : 28;
   };
}DA_RING_BUFFER_FALG_REG;

// 12bit
#define REG_DA_READ_POINTER         0x124

// 12bit 
#define REG_DA_RING_BUFFER_SIZE     0x128

// 32bit
#define REG_DA_CONV_CLK_DIVISOR     0x130

#define REG_DA_MUX                  0x140
typedef union _DA_MUX_REG{
   __u32 Value;
   struct{
      __u32 StartCh   : 1;
      __u32 Reserved1 : 15;
      __u32 StopCh    : 1;
      __u32 Reserved2 : 15;
   };
}DA_MUX_REG;

#define REG_DA_MSI_CONTROL             0x144
typedef union _DA_MSI_CONTROL_REG{
   __u32 Value;
   struct{
      __u32 DaConv : 1;
      __u32 Reserved1 : 5;
      __u32 DaInfinite : 1;
      __u32 DaSyn : 1;
      __u32 DaTrgEdge : 1;
      __u32 Reserved2 : 23;
   };
}DA_MSI_CONTROL_REG;

#define REG_ANALOG_CALIBRATION        0x150
typedef union _ANALOG_CALIBRATION_REG{
   __u32 Value;
   struct{
      __u32 Data : 8;
      __u32 Cmd  : 4;
      //0 0 0 0 A/D bipolar offset adjustment
      //0 0 0 1 A/D unipolar offset adjustment
      //0 0 1 0 A/D gain adjustment
      //0 0 1 1 Analog threshold voltage adjustment
      //0 1 0 0 D/A channel 0 gain adjustment
      //0 1 0 1 D/A channel 0 offset adjustment
      //0 1 1 0 D/A channel 1 gain adjustment
      //0 1 1 1 D/A channel 1 offset adjustment

      __u32 Reserved : 20;
   };
}ANALOG_CALIBRATION_REG;
//Command define
#define CAL_AD_BI_OFFSET      0
#define CAL_AD_UNI_OFFSET     1
#define CAL_AD_GAIN           2
#define CAL_AD_TRG_VOLT_ADJ   3
#define CAL_DA_CH0_GAIN       4
#define CAL_DA_CH0_OFFSET     5
#define CAL_DA_CH1_GAIN       6
#define CAL_DA_CH1_OFFSET     7  


typedef union _ANALOG_CALIBRATION_STATUS_REG{
   __u32 Value;
   struct{
      __u32 AcBusy : 1;
      __u32 Reserved : 31;
   };
}ANALOG_CALIBRATION_STATUS_REG;

#define REG_DA_CH0_CONTROL            0x160
#define REG_DA_CH1_CONTROL            0x164
typedef union _DA_CONTROL_REG{
   __u32 Value;
   struct{
      __u32 RefVol : 1; //0: 5V, 1: 10V
      __u32 RefSrc : 1; //0: Internal, 1: External
      __u32 Type   : 1; //0: Unipolar, 1: Bipolar
   };
}DA_CONTROL_REG;

//////////////////////////////////////////////////////////////////////////
// Below register are for Examination of Engineer Sample Only, 
// not available in finial MP Version
//____________________________________________
// 12bit
#define REG_DA_WRITE_POINTER            0x170

// 12bit
#define REG_DA_PERIODIC_POINTER_COUNTER 0x174
//____________________________________________
//////////////////////////////////////////////////////////////////////////

#define REG_DA_TRIG_START          0x170

//////////////////////////////////////////////////////
#define REG_DIO_DATA                     0x200

#define REG_DIO_CONFIG                  0x204
typedef union _DIO_CONFIG_REG{
   __u32 Value;
   struct{
      __u32 LowByteDir : 1; 
      __u32 Reserved1  : 3;
      __u32 HighByteDir: 1; 
      __u32 Reserved2  : 3;
      __u32 Reserved   : 24;
   };
}DIO_CONTROL_REG;

// Counter
#define REG_COUNTER_STEP                0x10   
#define REG_COUNTER0_CONTROL            0x300
#define REG_COUNTER1_CONTROL            0x310
#define REG_COUNTER2_CONTROL            0x320
typedef union _COUNTER_CONTROL_REG{
   __u32 Value;
   struct{
      __u32 CM0_DirMode      : 1; 
      __u32 CM1_EdgeMode     : 1; 
      __u32 CM2_Repetitive   : 1; 
      __u32 CM3_ReloadMode   : 1; 
      __u32 COM_OutputMode   : 2; 
      __u32 Reserved1        : 1;
      __u32 COE_OutputEn     : 1; 

      __u32 CS_SrcSelect     : 4; 
      __u32 Reserved2        : 4;

      __u32 GM_GateMode      : 2; 
      __u32 Reserved3        : 2;
      __u32 GP_GatePolarity  : 1;
      __u32 Reserved4        : 3;

      __u32 GS_GateSource    : 3;
      __u32 Reserved5        : 5;
   };
}COUNTER_CONTROL_REG;

#define CLK_SRC_CLK_N      0
#define CLK_SRC_CLK_N_M1   1
#define CLK_SRC_OUT_N_M1   2
#define CLK_SRC_GATE_N     3
#define CLK_SRC_20MHz      4
#define CLK_SRC_2MHz       5
#define CLK_SRC_200KHz     6
#define CLK_SRC_20KHz      7
#define CLK_SRC_2KHz       8
#define CLK_SRC_200Hz      9
#define CLK_SRC_20Hz      10
#define CLK_SRC_2Hz       11

//Gate Mode
#define GATE_MODE_NONE    0
#define GATE_MODE_LEVEL   1
#define GATE_MODE_EDGE    2
#define GATE_MODE_PULSE   3

//Output Mode
#define OUT_MODE_POSITIVE_PULSE    0
#define OUT_MODE_NEGATIVE_PULSE    1
#define OUT_MODE_TOGGLE_FROM_HIGH  3
#define OUT_MODE_TOGGLE_FROM_LOW   2

//Gate Source
#define GATE_SRC_GATE_N     0
#define GATE_SRC_GATE_N_M1  1
#define GATE_SRC_OUT_N_M1   2

//Freq Measure Gate Source
#define GATE_SRC_2KHz       4
#define GATE_SRC_200Hz      5
#define GATE_SRC_20Hz       6
#define GATE_SRC_2Hz        7

#define REG_COUNTER0_LOAD              0x304
#define REG_COUNTER1_LOAD              0x314
#define REG_COUNTER2_LOAD              0x324
//24bit counter

#define REG_COUNTER0_HOLD              0x308
#define REG_COUNTER1_HOLD              0x318
#define REG_COUNTER2_HOLD              0x328

#define REG_COUNTER0_CMD               0x30C
#define REG_COUNTER1_CMD               0x31C
#define REG_COUNTER2_CMD               0x32C
//define Bit for Command
#define COUNTER_DISARM 0
#define LOAD_FROM_LOAD 1
#define SAVE_TO_HOLD   2
#define COUNTER_STEP   3
#define COUNTER_ARM    4
#define COUNTER_RESET  7

#define REG_COUNTER_CMD_ENABLE          0x330

#define CNTR_INTF_MASK                  0x7
#define REG_COUNTER_INTERRUPT_CONTROL   0x334
#define REG_COUNTER_INTERRUPT_FLAG      0x338

#define REG_COUNTER0_DATA  0x340
#define REG_COUNTER1_DATA  0x344
#define REG_COUNTER2_DATA  0x348

//To compatible with PCI1780
#define DR_CntrMode( x ) ( REG_COUNTER0_CONTROL + REG_COUNTER_STEP * (x) )
#define DR_CntrLoad( x ) ( REG_COUNTER0_LOAD + REG_COUNTER_STEP * (x) )
#define DR_CntrHold( x ) ( REG_COUNTER0_HOLD + REG_COUNTER_STEP * (x) )
#define DR_CntrCmd( x )  ( REG_COUNTER0_CMD  + REG_COUNTER_STEP * (x) )

#define DR_CntrData( x ) ( REG_COUNTER0_DATA + 4 * (x) )

// Ring buffer data count
#define AI_RING_BUFFER_COUNT        4096
// Sample data size
#define AI_SAMPLE_DATA_SIZE         4
#define AI_FIFO_MASK               (AI_RING_BUFFER_COUNT - 1)
#define AI_FIFO_BITS                12

// Ring buffer length, in byte
#define AI_RING_BUFFER_LENGTH       (AI_RING_BUFFER_COUNT * AI_SAMPLE_DATA_SIZE)

#define AO_RING_BUFFER_OFFSET      0x4000
#define AO_RING_BUFFER_COUNT       4096
#define AO_FIFO_MASK               (AO_RING_BUFFER_COUNT - 1)
#define AO_SAMPLE_DATA_SIZE        4


// For HW ver. >= 0xC100
#define DR_BID             0x14


#endif /* _KERNEL_MODULE_HW_H_ */
