/*
 * counter.c
 *
 *  Created on: 2011-10-24
 *      Author: 
 */
#include "kdriver.h"
#include "hw.h"

CLK_INFO const s_freqGateSrc[] = {
   { 2,        GATE_SRC_2Hz  },
   { 20,       GATE_SRC_20Hz },
   { 200,      GATE_SRC_200Hz},
   { 2000,     GATE_SRC_2KHz }, 
}; 

CLK_INFO const s_clkSrcInfo[] = {
   { 0, SigInternal20MHz },
   { 1, SigInternal2MHz  },
   { 2, SigInternal200KHz},
   { 3, SigInternal20KHz },
   { 4, SigInternal2KHz  },
   { 5, SigInternal20Hz  },
   { 6, SigInternal20Hz  },
   { 7, SigInternal2Hz   }
}; 

static
inline __u32 ClockIdx2SigType(__u32 idx)
{ 
   __u32 sigType = SigInternal20MHz;
   __u32 i;
   for ( i = 0; i < 8; ++i )
   {
      if ( s_clkSrcInfo[i].ClkValue == idx )
      {
         sigType = s_clkSrcInfo[i].ClkId;
         break;
      }
   }
   return sigType;
}


static 
inline void load_arm_counter(daq_device_t *daq_dev, __u32 start)
{
   DEVICE_SHARED  *shared = &daq_dev->shared;

   // Load initial value
   __u8 cmd = LOAD_FROM_LOAD;
   AdxMemOutB(shared->BarMemBase[1], DR_CntrCmd(start), cmd);
   cmd = 1 << start;
   AdxMemOutB(shared->BarMemBase[1], REG_COUNTER_CMD_ENABLE, cmd);

   // Arm counter 
   cmd = COUNTER_ARM;
   AdxMemOutB(shared->BarMemBase[1], DR_CntrCmd(start), cmd);
   cmd = 1 << start;
   AdxMemOutB(shared->BarMemBase[1], REG_COUNTER_CMD_ENABLE, cmd);
}

static 
inline __u32 AdjustFreqMeasGateSource(__u32  gateSrc)
{     
   if ( gateSrc > GATE_SRC_2Hz )
   {     
      gateSrc = GATE_SRC_2Hz;
   } else if ( gateSrc < GATE_SRC_2KHz ) {
      gateSrc = GATE_SRC_2KHz;
   }     
   return gateSrc;
}        
         
static
inline __u32 AdjustCheckPeriod(__u32  checkPeriod)
{        
   if (checkPeriod > CNTR_CHK_PERIOD_MAX_NS)
   {     
      checkPeriod = CNTR_CHK_PERIOD_MAX_NS;
   } else if (checkPeriod < CNTR_CHK_PERIOD_NS) {
      checkPeriod = CNTR_CHK_PERIOD_NS;
   }     
   return checkPeriod;
}  

static
int daq_cntr_start_primary(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED  *shared = &daq_dev->shared;
   unsigned long  flags;
   COUNTER_CONTROL_REG cntrCtrl = {0};

   if( start >= CNTR_CHL_COUNT || count > CNTR_CHL_COUNT ){
      return -EINVAL;
   }

   while (count--) {
      spin_lock_irqsave(&daq_dev->dev_lock, flags);
      if (shared->CntrState[start].Operation == CNTR_IDLE) {
         memset(&shared->CntrState[start], 0, sizeof(CNTR_STATE));
         shared->CntrState[start].Operation = Primary;
      } else {
         spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
         return -EBUSY;
      }
      spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

      // Select counter 'start'; 
      if (shared->CntrConfig.ChipSigCntType[start] == UpCount)
      {
         cntrCtrl.CM0_DirMode = 1;   //Count Up
      }

      switch ( shared->CntrConfig.ChipClkSource[start] )
      {
      case SigCntClk0:
      case SigCntClk1:
      case SigCntClk2:
         cntrCtrl.CS_SrcSelect = ( ( shared->CntrConfig.ChipClkSource[start] - SigCntClk0 ) != start ) ? CLK_SRC_CLK_N_M1 : CLK_SRC_CLK_N;
         break;
      case SigCntGate0:
      case SigCntGate1:
      case SigCntGate2:
         cntrCtrl.CS_SrcSelect = CLK_SRC_GATE_N;
         break;
      case SigCntOut0:
      case SigCntOut1:
      case SigCntOut2:
         cntrCtrl.CS_SrcSelect = CLK_SRC_OUT_N_M1;
         break;
      case SigInternalClock:
      case SigInternal20MHz:
         cntrCtrl.CS_SrcSelect = CLK_SRC_20MHz;
         break;
      case SigInternal2MHz:
         cntrCtrl.CS_SrcSelect = CLK_SRC_2MHz;
         break;
      case SigInternal200KHz:
         cntrCtrl.CS_SrcSelect = CLK_SRC_200KHz;
         break;
      case SigInternal20KHz:
         cntrCtrl.CS_SrcSelect = CLK_SRC_20KHz;
         break;
      case SigInternal2KHz:
         cntrCtrl.CS_SrcSelect = CLK_SRC_2KHz;
         break;
      case SigInternal200Hz:
         cntrCtrl.CS_SrcSelect = CLK_SRC_200Hz;
         break;
      case SigInternal20Hz:
         cntrCtrl.CS_SrcSelect = CLK_SRC_20Hz;
         break;
      case SigInternal2Hz:
         cntrCtrl.CS_SrcSelect = CLK_SRC_2Hz;
         break;
      }

      switch ( shared->CntrConfig.ChipGateSource[start] )
      {
      case SignalNone:
         cntrCtrl.GM_GateMode = GATE_MODE_NONE; // No Gate
         break;
      case SigCntGate0:
      case SigCntGate1:
      case SigCntGate2:
         cntrCtrl.GS_GateSource = ( ( shared->CntrConfig.ChipGateSource[start] - SigCntGate0 ) != start ) ? GATE_SRC_GATE_N_M1 : GATE_SRC_GATE_N;
         break;
      case SigCntOut0:
      case SigCntOut1:
      case SigCntOut2:
         cntrCtrl.GS_GateSource = GATE_SRC_OUT_N_M1;
         break;
      case SigInternal2KHz:
         cntrCtrl.GS_GateSource = GATE_SRC_2KHz;
         break;
      case SigInternal200Hz:
         cntrCtrl.GS_GateSource = GATE_SRC_200Hz;
         break;
      case SigInternal20Hz:
         cntrCtrl.GS_GateSource = GATE_SRC_20Hz;
         break;
      case SigInternal2Hz:
         cntrCtrl.GS_GateSource = GATE_SRC_2Hz;
         break;
      }

      switch ( shared->CntrConfig.ChipOpMode[start] )
      {
      case C1780_MA:
         cntrCtrl.CM2_Repetitive = 0;
         cntrCtrl.CM3_ReloadMode = 0;
         cntrCtrl.GM_GateMode = GATE_MODE_NONE;
         break;
      case C1780_MB:
         cntrCtrl.CM2_Repetitive = 0;
         cntrCtrl.CM3_ReloadMode = 0;
         cntrCtrl.GM_GateMode = GATE_MODE_LEVEL;
         break;
      case C1780_MC:
         cntrCtrl.CM2_Repetitive = 0;
         cntrCtrl.CM3_ReloadMode = 0;
         cntrCtrl.GM_GateMode = GATE_MODE_EDGE;
         break;

      case C1780_MD:
         cntrCtrl.CM2_Repetitive = 1;
         cntrCtrl.CM3_ReloadMode = 0;
         cntrCtrl.GM_GateMode = GATE_MODE_NONE;
         break;
      case C1780_ME:
         cntrCtrl.CM2_Repetitive = 1;
         cntrCtrl.CM3_ReloadMode = 0;
         cntrCtrl.GM_GateMode = GATE_MODE_LEVEL;
         break;
      case C1780_MF:
         cntrCtrl.CM2_Repetitive = 1;
         cntrCtrl.CM3_ReloadMode = 0;
         cntrCtrl.GM_GateMode = GATE_MODE_EDGE;
         break;

      case C1780_MG:
         cntrCtrl.CM2_Repetitive = 0;
         cntrCtrl.CM3_ReloadMode = 1;
         cntrCtrl.GM_GateMode = GATE_MODE_NONE;
         break;
      case C1780_MH:
         cntrCtrl.CM2_Repetitive = 0;
         cntrCtrl.CM3_ReloadMode = 1;
         cntrCtrl.GM_GateMode = GATE_MODE_LEVEL;
         break;
      case C1780_MI:
         cntrCtrl.CM2_Repetitive = 0;
         cntrCtrl.CM3_ReloadMode = 1;
         cntrCtrl.GM_GateMode = GATE_MODE_EDGE;
         break;

      case C1780_MJ:
         cntrCtrl.CM2_Repetitive = 1;
         cntrCtrl.CM3_ReloadMode = 1;
         cntrCtrl.GM_GateMode = GATE_MODE_NONE;
         break;
      case C1780_MK:
         cntrCtrl.CM2_Repetitive = 1;
         cntrCtrl.CM3_ReloadMode = 1;
         cntrCtrl.GM_GateMode = GATE_MODE_LEVEL;
         break;
      case C1780_ML:
         cntrCtrl.CM2_Repetitive = 1;
         cntrCtrl.CM3_ReloadMode = 1;
         cntrCtrl.GM_GateMode = GATE_MODE_EDGE;
         break;
      }

      if ( shared->CntrConfig.ChipClkPolarity[start] == Negative )
      {
         cntrCtrl.CM1_EdgeMode = 1;
      }
      if ( shared->CntrConfig.ChipGatePolarity[start] == Negative )
      {
         cntrCtrl.GP_GatePolarity = 1;
      }

      cntrCtrl.COE_OutputEn = 1; // Enable Output

      switch ( shared->CntrConfig.ChipOutSigType[start] )
      {
      case NegativePulse:
         cntrCtrl.COM_OutputMode = OUT_MODE_NEGATIVE_PULSE;
         break;
      case ToggledFromLow:
         cntrCtrl.COM_OutputMode = OUT_MODE_TOGGLE_FROM_LOW;
         break;
      case ToggledFromHigh:
         cntrCtrl.COM_OutputMode = OUT_MODE_TOGGLE_FROM_HIGH;
         break;
      case PositivePulse:
         cntrCtrl.COM_OutputMode = OUT_MODE_POSITIVE_PULSE;
         break;
      case SignalNone:
      default:
         cntrCtrl.COE_OutputEn = 0; // Disable Output
         break;
      }

      daq_trace(("CounterCtrl Reg=0x%x\n", cntrCtrl.Value));

      AdxMemOutD(shared->BarMemBase[1], DR_CntrMode(start), cntrCtrl.Value);

      // set counter's initial value
      AdxMemOutD(shared->BarMemBase[1], DR_CntrLoad(start), shared->CntrConfig.ChipLoadValue[start]);

      //EnableCounterInterrupt
      {
         __u32 kdx;
         __u8 cntrInt;
         if (shared->CntrState[start].Operation == TimerPulse) {
            kdx = KdxCntTimer0 + start;
         }else {
            kdx = KdxCntTerminalCount0 + start;
         }  
         shared->IsEvtSignaled[kdx] = 0;

         cntrInt = AdxMemInB(shared->BarMemBase[1], REG_COUNTER_INTERRUPT_CONTROL);
         cntrInt &= ~(1<<start);
         cntrInt |= (1<<start);
         AdxMemOutB(shared->BarMemBase[1], REG_COUNTER_INTERRUPT_CONTROL, cntrInt);
      }
      load_arm_counter(daq_dev, start);

      ++start;
      start %= CNTR_CHL_COUNT;
   }

   return 0;
}

static
int daq_cntr_start_one_shot(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED  *shared = &daq_dev->shared;
   unsigned long  flags;
   COUNTER_CONTROL_REG cntrCtrl = {0};

   if( start >= CNTR_CHL_COUNT || count > CNTR_CHL_COUNT ){
      return -EINVAL;
   }


   while (count--) {
      spin_lock_irqsave(&daq_dev->dev_lock, flags);
      if (shared->CntrState[start].Operation == CNTR_IDLE) {
         memset(&shared->CntrState[start], 0, sizeof(CNTR_STATE));
         shared->CntrState[start].Operation = OneShot;
      } else {
         spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
         return -EBUSY;
      }
      spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

      // Select counter 'start'; 
      cntrCtrl.CM0_DirMode = 0;   //Count Down
      cntrCtrl.CM2_Repetitive = 1;//repetitive

      if (shared->CntrConfig.OsGatePolarity[start] == Negative)
      {
         cntrCtrl.GP_GatePolarity = 1; //Low Level for level active, falling edge for edge active
      }

      if (shared->CntrConfig.OsClkPolarity[start] == Negative)
      {
         cntrCtrl.CM1_EdgeMode = 1; //Count on falling edge
      }

      cntrCtrl.COE_OutputEn = 1; // Enable Output
      switch (shared->CntrConfig.OsOutSigType[start])
      {
      case NegativePulse:
         cntrCtrl.COM_OutputMode = OUT_MODE_NEGATIVE_PULSE;
         break;
      case ToggledFromLow:
         cntrCtrl.COM_OutputMode = OUT_MODE_TOGGLE_FROM_LOW;
         break;
      case ToggledFromHigh:
         cntrCtrl.COM_OutputMode = OUT_MODE_TOGGLE_FROM_HIGH;
         break;
      case PositivePulse:
      default:
         cntrCtrl.COM_OutputMode = OUT_MODE_POSITIVE_PULSE;
         break;
      }

      switch (shared->CntrConfig.OsClkSource[start])
      {
      case SigCntClk0:
      case SigCntClk1:
      case SigCntClk2:
         cntrCtrl.CS_SrcSelect = ((shared->CntrConfig.OsClkSource[start] - SigCntClk0) != start) ? CLK_SRC_CLK_N_M1 : CLK_SRC_CLK_N;
         break;
      case SigCntGate0:
      case SigCntGate1:
      case SigCntGate2:
         cntrCtrl.CS_SrcSelect = CLK_SRC_GATE_N;
         break;
      case SigCntOut0:
      case SigCntOut1:
      case SigCntOut2:
         cntrCtrl.CS_SrcSelect = CLK_SRC_OUT_N_M1;
         break;
      case SigInternalClock:
      case SigInternal20MHz:
         cntrCtrl.CS_SrcSelect = CLK_SRC_20MHz;
         break;
      case SigInternal2MHz:
         cntrCtrl.CS_SrcSelect = CLK_SRC_2MHz;
         break;
      case SigInternal200KHz:
         cntrCtrl.CS_SrcSelect = CLK_SRC_200KHz;
         break;
      case SigInternal20KHz:
         cntrCtrl.CS_SrcSelect = CLK_SRC_20KHz;
         break;
      case SigInternal2KHz:
         cntrCtrl.CS_SrcSelect = CLK_SRC_2KHz;
         break;
      case SigInternal200Hz:
         cntrCtrl.CS_SrcSelect = CLK_SRC_200Hz;
         break;
      case SigInternal20Hz:
         cntrCtrl.CS_SrcSelect = CLK_SRC_20Hz;
         break;
      case SigInternal2Hz:
         cntrCtrl.CS_SrcSelect = CLK_SRC_2Hz;
         break;
      }

      cntrCtrl.GM_GateMode = GATE_MODE_EDGE;
      switch (shared->CntrConfig.OsGateSource[start])
      {
      case SignalNone:
         cntrCtrl.GM_GateMode = GATE_MODE_NONE; // No Gate, this case should not be accessed because the OneShot always need a gate
         break;
      case SigCntGate0:
      case SigCntGate1:
      case SigCntGate2:
         cntrCtrl.GS_GateSource = ((shared->CntrConfig.OsGateSource[start] - SigCntGate0) != start) ? GATE_SRC_GATE_N_M1 : GATE_SRC_GATE_N;
         break;
      case SigCntOut0:
      case SigCntOut1:
      case SigCntOut2:
         cntrCtrl.GS_GateSource = 2;
         break;
      case SigInternal2KHz:
         cntrCtrl.GS_GateSource = GATE_SRC_2KHz;
         break;
      case SigInternal200Hz:
         cntrCtrl.GS_GateSource = GATE_SRC_200Hz;
         break;
      case SigInternal20Hz:
         cntrCtrl.GS_GateSource = GATE_SRC_20Hz;
         break;
      case SigInternal2Hz:
         cntrCtrl.GS_GateSource = GATE_SRC_2Hz;
         break;
      }

      daq_trace(("ClkSrc=0x%x, GateSrc=0x%x, GateMode=0x%x\n", cntrCtrl.CS_SrcSelect, cntrCtrl.GS_GateSource, cntrCtrl.GM_GateMode ));

      AdxMemOutD(shared->BarMemBase[1], DR_CntrMode(start), cntrCtrl.Value);

      // set counter's initial value
      AdxMemOutD(shared->BarMemBase[1], DR_CntrLoad(start), shared->CntrConfig.OsDelayCount[start]);

      load_arm_counter(daq_dev, start);

      ++start;
      start %= CNTR_CHL_COUNT;
   }

   return 0;
}

static
int daq_cntr_start_event_count(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED  *shared = &daq_dev->shared;
   COUNTER_CONTROL_REG cntrCtrl = {0};
   unsigned long  flags;

   if( start >= CNTR_CHL_COUNT || count > CNTR_CHL_COUNT ){
      return -EINVAL;
   }

   while (count--) {
      spin_lock_irqsave(&daq_dev->dev_lock, flags);
      if (shared->CntrState[start].Operation == CNTR_IDLE) {
         memset(&shared->CntrState[start], 0, sizeof(CNTR_STATE));
         shared->CntrState[start].Operation = InstantEventCount;
      } else {
         spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
         return -EBUSY;
      }
      spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

      cntrCtrl.CM0_DirMode = 1;   //Count Up
      cntrCtrl.CM2_Repetitive = 1;//repetitive

      if (shared->CntrConfig.EcGatePolarity[start] == Negative)
      {
         cntrCtrl.GP_GatePolarity = 1; //Low Level for level active, falling edge for edge active
      }

      if (shared->CntrConfig.EcClkPolarity[start] == Negative)
      {
         cntrCtrl.CM1_EdgeMode = 1; //Count on falling edge
      }

      cntrCtrl.CS_SrcSelect = CLK_SRC_CLK_N;

      if ( shared->CntrConfig.EcGateEnabled[start] )
      {
         cntrCtrl.GM_GateMode = GATE_MODE_LEVEL;
         cntrCtrl.GS_GateSource = GATE_SRC_GATE_N;
      } else {
         cntrCtrl.GM_GateMode = GATE_MODE_NONE; // No Gate
      }
      AdxMemOutD(shared->BarMemBase[1], DR_CntrMode(start), cntrCtrl.Value);
      daq_trace(("CounterMode=0x%x\n", cntrCtrl.Value));

      // set counter's initial value to 0
      AdxMemOutD(shared->BarMemBase[1], DR_CntrLoad(start), 0);

      load_arm_counter(daq_dev, start);

      // start the overflow checker timer after we had configured the HW
      shared->CntrChkTimerOwner |= 0x1 << start;
      schedule_delayed_work(&daq_dev->cntr_work, 1);

      ++start;
      start %= CNTR_CHL_COUNT;
   }

   return 0;
}

static
int daq_cntr_start_timer_pulse(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED       *shared = &daq_dev->shared;
   COUNTER_CONTROL_REG cntrCtrl = {0};
   __u32               clkSrc;  
   __u32               divisor;
   unsigned long  flags;

   if( start >= CNTR_CHL_COUNT || count > CNTR_CHL_COUNT ){
      return -EINVAL;
   }

   while (count--) {
      spin_lock_irqsave(&daq_dev->dev_lock, flags);
      if (shared->CntrState[start].Operation == CNTR_IDLE) {
         memset(&shared->CntrState[start], 0, sizeof(CNTR_STATE));
         shared->CntrState[start].Operation = TimerPulse;
      } else {
         spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
         return -EBUSY;
      }
      spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

      cntrCtrl.CM0_DirMode = 0;   //Count down
      cntrCtrl.CM2_Repetitive = 1;//repetitive
      if (shared->CntrConfig.TmrGateEnabled[start])
      {
         cntrCtrl.GS_GateSource = GATE_SRC_GATE_N;
         if (shared->CntrConfig.TmrGatePolarity[start] == Negative)
         {
            cntrCtrl.GP_GatePolarity = 1; //Low Level for level active, falling edge for edge active
         }
         cntrCtrl.GM_GateMode = GATE_MODE_LEVEL;
      } else {
         cntrCtrl.GM_GateMode = GATE_MODE_NONE;
      }

      //Set the clock source
      clkSrc = shared->CntrConfig.TmrDivisor[start] >> CNTR_RES_IN_BIT;
      clkSrc = ClockIdx2SigType(clkSrc);
      divisor = shared->CntrConfig.TmrDivisor[start] & CNTR_DATA_MASK;
      divisor -= 1; //The counter need a pulse to reload the initialize value
      switch(clkSrc)
      {
      case SigInternal2KHz:
         cntrCtrl.CS_SrcSelect = CLK_SRC_2KHz;
         break;
      case SigInternal20KHz:
         cntrCtrl.CS_SrcSelect = CLK_SRC_20KHz;
         break;
      case SigInternal200KHz:
         cntrCtrl.CS_SrcSelect = CLK_SRC_200KHz;
         break;
      default:
         cntrCtrl.CS_SrcSelect = CLK_SRC_20MHz;
         break;
      }
      daq_trace(("CLKSrc=%d, divisor=%d\n", cntrCtrl.CS_SrcSelect, divisor));

      cntrCtrl.COE_OutputEn = 1; // Enable Output
      switch (shared->CntrConfig.TmrOutSigType[start])
      {
      case NegativePulse:
         cntrCtrl.COM_OutputMode = OUT_MODE_NEGATIVE_PULSE;
         break;
      case PositivePulse:
         cntrCtrl.COM_OutputMode = OUT_MODE_POSITIVE_PULSE;
         break;
      case ToggledFromHigh:
         cntrCtrl.COM_OutputMode = OUT_MODE_TOGGLE_FROM_HIGH;
         break;
      case ToggledFromLow:
      default:
         cntrCtrl.COM_OutputMode = OUT_MODE_TOGGLE_FROM_LOW;
         break;
      }

      AdxMemOutD(shared->BarMemBase[1], DR_CntrMode(start), cntrCtrl.Value);
      daq_trace(("Mode:0x%x\n", cntrCtrl.Value));

      AdxMemOutD(shared->BarMemBase[1], DR_CntrLoad(start), divisor );
      daq_trace(("Divisor:0x%x\n", shared->CntrConfig.TmrDivisor[start]));

      //EnableCounterInterrupt
      {
         __u32 kdx;
         __u8 cntrInt;
         if (shared->CntrState[start].Operation == TimerPulse) {
            kdx = KdxCntTimer0 + start;
         }else {
            kdx = KdxCntTerminalCount0 + start;
         }
         shared->IsEvtSignaled[kdx] = 0;

         cntrInt = AdxMemInB(shared->BarMemBase[1], REG_COUNTER_INTERRUPT_CONTROL);
         cntrInt &= ~(1<<start);
         cntrInt |= (1<<start);
         AdxMemOutB(shared->BarMemBase[1], REG_COUNTER_INTERRUPT_CONTROL, cntrInt);
      }
      load_arm_counter(daq_dev, start);

      ++start;
      start %= CNTR_CHL_COUNT;
   }

   return 0;
}

static
int daq_cntr_start_freq_measure(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED       *shared = &daq_dev->shared;
   __u8                cmd;
   COUNTER_CONTROL_REG counterCtrl = {0};
   struct timespec     tm_now;
   unsigned long       flags;

   if( start >= CNTR_CHL_COUNT || count > CNTR_CHL_COUNT ){
      return -EINVAL;
   }

   while (count--) {
      spin_lock_irqsave(&daq_dev->dev_lock, flags);
      if (shared->CntrState[start].Operation == CNTR_IDLE) {
         memset(&shared->CntrState[start], 0, sizeof(CNTR_STATE));
         shared->CntrState[start].Operation = InstantFreqMeter;
      } else {
         spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
         return -EBUSY;
      }
      spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

      shared->CntrState[start].GateFreq = 2;
      shared->CntrState[start].Chan = start;

      daq_trace(("FmPeroid=%d\n", shared->CntrConfig.FmPeroid[start]));
      daq_trace(("AutoAdaptive\n"));
      // Select counter 'start'; 
      cmd = 0;
      //Disable interrupt
      //Read the current interrupt config, avoid to affect the other counter
      cmd = AdxMemInB(shared->BarMemBase[1], REG_COUNTER_INTERRUPT_CONTROL);
      cmd &= ~(1 << start);
      AdxMemOutB(shared->BarMemBase[1], REG_COUNTER_INTERRUPT_CONTROL, cmd);
      //Clear interrupt flag
      cmd = 1 << start;
      AdxMemOutB(shared->BarMemBase[1], REG_COUNTER_INTERRUPT_FLAG, cmd);

      {
         //Reset counter
         __u8 cmd = COUNTER_RESET;
         AdxMemOutB(shared->BarMemBase[1], DR_CntrCmd(start), cmd);
         cmd = 1 << start;
         AdxMemOutB(shared->BarMemBase[1], REG_COUNTER_CMD_ENABLE, cmd);
      }

      counterCtrl.CM0_DirMode  = 0;   //Down counter
      counterCtrl.CM3_ReloadMode = 1; //Reload from Load or Hold registers
      counterCtrl.CM2_Repetitive = 1; //Repetitive
      counterCtrl.CS_SrcSelect = CLK_SRC_GATE_N;    //Clock Source, from pin GateN
      counterCtrl.GM_GateMode = GATE_MODE_PULSE;    //pulse width measure mode
      counterCtrl.GS_GateSource = GATE_SRC_2Hz;          //internal source
      AdxMemOutD(shared->BarMemBase[1], DR_CntrMode(start), counterCtrl.Value);
      daq_trace(("CntrStartFreqMeasure: GateSource=%d\n", gateSrc));
      load_arm_counter(daq_dev, start);

      tm_now = current_kernel_time();
      shared->CntrState[start].PrevTime = timespec_to_ns(&tm_now);
      shared->CntrChkTimerOwner |= 0x1 << start;
      schedule_delayed_work(&daq_dev->cntr_work, 1);

      ++start;
      start %= CNTR_CHL_COUNT;
   }

   return 0;
}

static
int daq_cntr_start_pwm_in(daq_device_t *daq_dev, __u32 start, __u32 groupCount)
{
   DEVICE_SHARED       *shared = &daq_dev->shared;
   __u8                cmd;
   COUNTER_CONTROL_REG cntrCtrl = {0};
   unsigned long       flags;

   if( start >= CNTR_CHL_COUNT || groupCount > CNTR_CHL_COUNT ){
      return -EINVAL;
   }

   while (groupCount--) {
      spin_lock_irqsave(&daq_dev->dev_lock, flags);
      if (shared->CntrState[start].Operation == CNTR_IDLE) {
         memset(&shared->CntrState[start], 0, sizeof(CNTR_STATE));
         shared->CntrState[start].Operation = InstantPwmIn;
      } else {
         spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
         return -EBUSY;
      }
      spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

      shared->CntrState[start].HoldValue = 0;

      //Reset Counter
      cmd = COUNTER_RESET;
      AdxMemOutB(shared->BarMemBase[1], DR_CntrCmd(start), cmd);
      AdxMemOutB(shared->BarMemBase[1], REG_COUNTER_CMD_ENABLE, (1 << start));

      cmd = 0;
      //Disable interrupt
      cmd = AdxMemInB(shared->BarMemBase[1], REG_COUNTER_INTERRUPT_CONTROL);
      cmd &= ~(1 << start);
      AdxMemOutB(shared->BarMemBase[1], REG_COUNTER_INTERRUPT_CONTROL, cmd);
      //Clear interrupt flag
      cmd = 1 << start;
      AdxMemOutB(shared->BarMemBase[1], REG_COUNTER_INTERRUPT_FLAG, cmd);

      switch (shared->CntrConfig.PiClkSource[start] )
      {
      case SigInternal2KHz:
         cntrCtrl.CS_SrcSelect = CLK_SRC_2KHz;
         break;
      case SigInternal20KHz:
         cntrCtrl.CS_SrcSelect = CLK_SRC_20KHz;
         break;
      case SigInternal200KHz:
         cntrCtrl.CS_SrcSelect = CLK_SRC_200KHz;
         break;
      case SigInternal2MHz:
         cntrCtrl.CS_SrcSelect = CLK_SRC_2MHz;
         break;
      case SigInternalClock://20MHz
      default:
         cntrCtrl.CS_SrcSelect = CLK_SRC_20MHz;
         break;
     }
     cntrCtrl.CM0_DirMode = 0;    //count down
     cntrCtrl.CM3_ReloadMode = 1; //Reload from Load or Hold registers
     cntrCtrl.CM2_Repetitive = 1; //Repetitive
     cntrCtrl.GM_GateMode = GATE_MODE_PULSE;
     cntrCtrl.GS_GateSource = GATE_SRC_GATE_N;
     AdxMemOutD(shared->BarMemBase[1], DR_CntrMode(start), cntrCtrl.Value);
     daq_trace(("PwmInConfig: mode=0x%x\n", cntrCtrl.Value));

     // Arm counter 
     cmd = COUNTER_ARM;
     AdxMemOutB(shared->BarMemBase[1], DR_CntrCmd(start), cmd);
     AdxMemOutB(shared->BarMemBase[1], REG_COUNTER_CMD_ENABLE, (1<<start));

     ++start;
     start %= CNTR_CHL_COUNT;
   }

   return 0;
}

static
int daq_cntr_start_pwm_out(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED       *shared = &daq_dev->shared;
   unsigned long       flags;
   COUNTER_CONTROL_REG cntrCtrl = {0};
   __u32               baseClock;

   if( start >= CNTR_CHL_COUNT || count > CNTR_CHL_COUNT ){
      return -EINVAL;
   }

   while (count--) {
      spin_lock_irqsave(&daq_dev->dev_lock, flags);
      if (shared->CntrState[start].Operation == CNTR_IDLE) {
         memset(&shared->CntrState[start], 0, sizeof(CNTR_STATE));
         shared->CntrState[start].Operation = InstantPwmOut;
      } else {
         spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
         return -EBUSY;
      }
      spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

      daq_trace(("PwmOut: Ch[%d], High=0x%x, low=0x%x\n", start, shared->CntrConfig.PoHiPeriod[start], shared->CntrConfig.PoLoPeriod[start]));

      cntrCtrl.COE_OutputEn   = 1;   //Enable Output
      cntrCtrl.COM_OutputMode = OUT_MODE_TOGGLE_FROM_HIGH;

      if (shared->CntrConfig.PoGateEnabled[start])
      {
         cntrCtrl.GS_GateSource = GATE_SRC_GATE_N;
         if (shared->CntrConfig.PoGatePolarity[start] == Negative)
         {
            cntrCtrl.GP_GatePolarity = 1; //Low Level for level active, falling edge for edge active
         }
         cntrCtrl.GM_GateMode = GATE_MODE_LEVEL;
      } else {
         cntrCtrl.GM_GateMode = GATE_MODE_NONE;
      }

      baseClock = shared->CntrConfig.PoHiPeriod[start] >> CNTR_RES_IN_BIT;
      baseClock = ClockIdx2SigType(baseClock);
      switch ( baseClock )
      {
      case SigInternal2KHz:
         cntrCtrl.CS_SrcSelect = CLK_SRC_2KHz;
         break;
      case SigInternal200KHz:
         cntrCtrl.CS_SrcSelect = CLK_SRC_200KHz;
         break;
      case SigInternalClock://20MHz
      default:
         cntrCtrl.CS_SrcSelect = CLK_SRC_20MHz;;
         break;
      }

      cntrCtrl.CM2_Repetitive = 1; //count repetitively
      cntrCtrl.CM3_ReloadMode = 1; //Load from Load and hold register
      daq_trace(("CounterMode=0x%x\n", cntrCtrl.Value));
      AdxMemOutD(shared->BarMemBase[1], DR_CntrMode(start), cntrCtrl.Value);

      AdxMemOutD(shared->BarMemBase[1], DR_CntrLoad(start), shared->CntrConfig.PoHiPeriod[start] & CNTR_DATA_MASK);
      AdxMemOutD(shared->BarMemBase[1], DR_CntrHold(start), shared->CntrConfig.PoLoPeriod[start] & CNTR_DATA_MASK);
      load_arm_counter(daq_dev, start);

      ++start;
      start %= CNTR_CHL_COUNT;
   }

   return 0;
}

static inline
void daq_cntr_check_overflow_state(daq_device_t *daq_dev, CNTR_STATE *cntr, __u32 cntr_val, __u32 dummy, __s64 *tm_stamp)
{
   if ( cntr->PrevVal > cntr_val )
   {
      ++cntr->Overflow;
   }     
   cntr->PrevVal = cntr_val;
}

static
void daq_cntr_update_fm_state(daq_device_t *daq_dev, CNTR_STATE *cntr, __u32 hold_val, __u32 load_val, __s64 *tm_stamp)
{
   DEVICE_SHARED  *shared = &daq_dev->shared;
   __u32  tm_delta;
   __u32  pulseWidth      = hold_val + load_val;
   __u32  maxHalf         = x_max(hold_val, load_val);

   tm_delta = (__u32)(*tm_stamp - cntr->PrevTime);

   if (cntr->CheckPeriod <= tm_delta)
   {
      COUNTER_CONTROL_REG counterCtrl;
      __u32               gateSrc;
      __u32               i;

      counterCtrl.Value = AdxMemInD(shared->BarMemBase[1], DR_CntrMode(cntr->Chan));
      gateSrc = counterCtrl.GS_GateSource;
      if (pulseWidth < 2)
      {
         // Adjust the check period
         cntr->CheckPeriod *= 5;
         cntr->CheckPeriod = AdjustCheckPeriod(cntr->CheckPeriod);
         // Adjust the Gate Source
         gateSrc++;
         gateSrc = AdjustFreqMeasGateSource(gateSrc);
         counterCtrl.GS_GateSource = gateSrc;
         AdxMemOutD(shared->BarMemBase[1], DR_CntrMode(cntr->Chan), counterCtrl.Value);
         load_arm_counter(daq_dev, cntr->Chan);
         daq_trace(("### enlarge Check Period, enlarge Gate period: CheckPeriod=%u, GateFreq=%u \n", cntr->CheckPeriod, cntr->GateFreq));
      } else if ( maxHalf > 50000 ) {
         // Adjust the check period
         cntr->CheckPeriod /= 5;
         AdjustCheckPeriod(cntr->CheckPeriod);
         // Adjust the Gate Source
         gateSrc--;
         gateSrc = AdjustFreqMeasGateSource(gateSrc);
         counterCtrl.GS_GateSource = gateSrc;
         AdxMemOutD(shared->BarMemBase[1], DR_CntrMode(cntr->Chan), counterCtrl.Value);
         load_arm_counter(daq_dev, cntr->Chan);
         daq_trace(("### reduce Check Period, reduce Gate period: CheckPeriod=%u, GateFreq=%u \n", cntr->CheckPeriod, cntr->GateFreq));
      }

      // update Gate Freq
      for (i = 0; i < ARRAY_SIZE(s_freqGateSrc); ++i)
      {
         if (counterCtrl.GS_GateSource == s_freqGateSrc[i].ClkId)
         {
            cntr->GateFreq = s_freqGateSrc[i].ClkValue;
         }
      }

      // read the value
      cntr->HoldValue = hold_val;
      cntr->LoadValue = load_val;
      cntr->PrevTime  = *tm_stamp;
   }
}
//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------
void daq_cntr_update_state_work_func(struct work_struct *work)
{
   daq_device_t    *daq_dev = container_of(delayed_work_ptr(work), daq_device_t, cntr_work);
   DEVICE_SHARED   *shared  = &daq_dev->shared;
   struct timespec tm_now;
   __s64           tm_now_ns;
   __u32           i, active= shared->CntrChkTimerOwner;
   __u32           holdValue = 0;
   __u32           loadValue = 0;

   getnstimeofday(&tm_now);
   tm_now_ns = timespec_to_ns(&tm_now);

   for (i = 0; active; ++i, active >>= 1){
      if (active & 0x1) {
         if (shared->CntrState[i].Operation == InstantFreqMeter || shared->CntrState[i].Operation == InstantPwmIn)
         {
            //Read the pulse width value, Hold register(High), Load register(Low)
            holdValue = AdxMemInD(shared->BarMemBase[1], DR_CntrHold(i));
            loadValue = AdxMemInD(shared->BarMemBase[1], DR_CntrLoad(i));
            daq_trace(("i is %d holdValue is %d loadVaule is %d\n", i, holdValue,loadValue));
         } else {
            // save counter to HOLD and read out   
            __u8 cmd = SAVE_TO_HOLD;
            AdxMemOutB(shared->BarMemBase[1], DR_CntrCmd(i), cmd);
            cmd = 1 << i;
            AdxMemOutB(shared->BarMemBase[1], REG_COUNTER_CMD_ENABLE, cmd);

            holdValue = AdxMemInD(shared->BarMemBase[1], DR_CntrHold(i));
         }
         if (shared->CntrState[i].Operation == InstantFreqMeter){
            daq_cntr_update_fm_state(daq_dev, &shared->CntrState[i], holdValue, loadValue, &tm_now_ns);
         } else {
            daq_cntr_check_overflow_state(daq_dev, &shared->CntrState[i], holdValue, 0, &tm_now_ns);
         }
      }
   }

   if (daq_dev->shared.CntrChkTimerOwner){
      schedule_delayed_work(delayed_work_ptr(work), msecs_to_jiffies(CNTR_CHK_PERIOD_NS / 1000000L));
   }
}

void daq_cntr_reset(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED  *shared = &daq_dev->shared;
   unsigned long  flags;


   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   while (count--) {
      //Reset counter
      __u8 cmd = COUNTER_RESET;
      AdxMemOutB(shared->BarMemBase[1], DR_CntrCmd(start), cmd); 
      cmd = 1 << start;
      AdxMemOutB(shared->BarMemBase[1], REG_COUNTER_CMD_ENABLE, cmd);

      if (shared->CntrState[start].Operation == Primary
         || shared->CntrState[start].Operation == TimerPulse)
      {
         __u8 cntrInt = AdxMemInB(shared->BarMemBase[1], REG_COUNTER_INTERRUPT_CONTROL);
         cntrInt &= ~(1<<start);
         AdxMemOutB(shared->BarMemBase[1], REG_COUNTER_INTERRUPT_CONTROL, cntrInt);

         //Clear interrupt flag
         cntrInt = 1 << start;
         AdxMemOutB(shared->BarMemBase[1], REG_COUNTER_INTERRUPT_FLAG, cntrInt);
      }

      shared->CntrChkTimerOwner &= ~(0x1 << start);
      shared->CntrState[start].Operation = CNTR_IDLE;

      ++start;
      start %= CNTR_CHL_COUNT;
   }
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
}

int daq_ioctl_cntr_set_param(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   CNTR_SET_CFG  cntr;
   void*         dataPtr;
   __u32         valLen;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= CNTR_CHL_COUNT) {
      return -EINVAL;
   }

   if (cntr.Count > CNTR_CHL_COUNT - cntr.Start) {
      cntr.Count = CNTR_CHL_COUNT - cntr.Start;
   }

   switch (cntr.PropID)
   {
      //Primal
   case CFG_ChipClkPolarityOfCounters:
      dataPtr = &shared->CntrConfig.ChipClkPolarity[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_ChipGatePolarityOfCounters:
      dataPtr = &shared->CntrConfig.ChipGatePolarity[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_ChipOutSignalOfCounters:
      dataPtr = &shared->CntrConfig.ChipOutSigType[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;

   case CFG_ChipClkSourceOfCounters:
      dataPtr = &shared->CntrConfig.ChipClkSource[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_ChipGateSourceOfCounters:
      dataPtr = &shared->CntrConfig.ChipGateSource[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_ChipOperationModeOfCounters:
      dataPtr = &shared->CntrConfig.ChipOpMode[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_ChipSignalCountingTypeOfCounters:
      dataPtr = &shared->CntrConfig.ChipSigCntType[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_ChipLoadValueOfCounters:
      dataPtr = &shared->CntrConfig.ChipLoadValue[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_ChipHoldValueOfCounters:
      dataPtr = &shared->CntrConfig.ChipHoldValue[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
      //Event Count
   case CFG_EcClkPolarityOfCounters:
      dataPtr = &shared->CntrConfig.EcClkPolarity[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_EcGatePolarityOfCounters:
      dataPtr = &shared->CntrConfig.EcGatePolarity[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_EcGateEnabledOfCounters:
      dataPtr = &shared->CntrConfig.EcGateEnabled[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
      //OneShot
   case CFG_OsClkSourceOfCounters:
      dataPtr = &shared->CntrConfig.OsClkSource[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_OsGateSourceOfCounters:
      dataPtr = &shared->CntrConfig.OsGateSource[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_OsDelayCountOfCounters:
      dataPtr = &shared->CntrConfig.OsDelayCount[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;

   case CFG_OsClkPolarityOfCounters:
      dataPtr = &shared->CntrConfig.OsClkPolarity[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_OsGatePolarityOfCounters:
      dataPtr = &shared->CntrConfig.OsGatePolarity[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_OsOutSignalOfCounters:
      dataPtr = &shared->CntrConfig.OsOutSigType[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
      //TimerPulse
   case CFG_TmrFrequencyOfCounters:
      dataPtr = &shared->CntrConfig.TmrDivisor[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_TmrGateEnabledOfCounters:
      dataPtr = &shared->CntrConfig.TmrGateEnabled[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_TmrGatePolarityOfCounters:
      dataPtr = &shared->CntrConfig.TmrGatePolarity[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_TmrOutSignalOfCounters:
      dataPtr = &shared->CntrConfig.TmrOutSigType[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;

      //FreqMeter
   case CFG_FmCollectionPeriodOfCounters:
      dataPtr = &shared->CntrConfig.FmPeroid[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      daq_trace(("CFG_FmCollectionPeriodOfCounters\n"));
      break;
   case CFG_FmMethodOfCounters:
      dataPtr = &shared->CntrConfig.FmMethod[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
      //PwmOut
   case CFG_PoHiPeriodOfCounters:
      dataPtr = &shared->CntrConfig.PoHiPeriod[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_PoLoPeriodOfCounters:
      dataPtr = &shared->CntrConfig.PoLoPeriod[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;

   case CFG_PoGateEnabledOfCounters:
      dataPtr = &shared->CntrConfig.PoGateEnabled[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_PoGatePolarityOfCounters:
      dataPtr = &shared->CntrConfig.PoGatePolarity[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
      //PwmIn
   case Internal_CFG_PiClkSourceOfCounters:
      dataPtr = &shared->CntrConfig.PiClkSource[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   default:
      return ErrorPropReadOnly;
   }

   if (unlikely(copy_from_user(dataPtr, cntr.Value, valLen))){
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_cntr_start(daq_device_t *daq_dev, unsigned long arg)
{
   CNTR_START cntr;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= CNTR_CHL_COUNT || cntr.Count > CNTR_CHL_COUNT){
      return -EINVAL;
   }
   switch(cntr.Operation)
   {
   case Primary:
      return daq_cntr_start_primary(daq_dev, cntr.Start, cntr.Count);
   case InstantEventCount:
      return daq_cntr_start_event_count(daq_dev, cntr.Start, cntr.Count);
   case OneShot:
      return daq_cntr_start_one_shot(daq_dev, cntr.Start, cntr.Count);
   case TimerPulse:
      return daq_cntr_start_timer_pulse(daq_dev, cntr.Start, cntr.Count);
   case InstantFreqMeter:
      return daq_cntr_start_freq_measure(daq_dev, cntr.Start, cntr.Count);
   case InstantPwmIn:
      return daq_cntr_start_pwm_in(daq_dev, cntr.Start, cntr.Count);
   case InstantPwmOut:
      return daq_cntr_start_pwm_out(daq_dev, cntr.Start, cntr.Count);
   default:
      return -ENOSYS;
   }
}

int daq_ioctl_cntr_read(daq_device_t *daq_dev, unsigned long arg)
{
   CNTR_READ  cntr;
   CNTR_VALUE vals[CNTR_CHL_COUNT];
   CNTR_VALUE *curr = vals;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= CNTR_CHL_COUNT || cntr.Count > CNTR_CHL_COUNT){
      return -EINVAL;
   }

   {
      DEVICE_SHARED  *shared  = &daq_dev->shared;
      unsigned       mask;
      int            i;
      __u8           cmd;
      __u32          start = cntr.Start;

      mask  = ((0x1 << cntr.Count) - 1) << cntr.Start;
      mask |= mask >> CNTR_CHL_COUNT;

      for (i = 0; i < cntr.Count; ++i){
         // read the value
         // save counter to HOLD and read out   
         cmd = SAVE_TO_HOLD;
         AdxMemOutB( shared->BarMemBase[1], DR_CntrCmd(start), cmd );
         cmd = 1 << start;
         AdxMemOutB( shared->BarMemBase[1], REG_COUNTER_CMD_ENABLE, cmd );
         curr->CanRead = 1;
         curr->Value = AdxMemInD( shared->BarMemBase[1], DR_CntrHold(start) );
         daq_trace(("CounterRead[%d]=%d\n", start, curr->Value));

         if ( shared->CntrState[start].Operation == Primary )
         {
            AdxMemOutD( shared->BarMemBase[1], DR_CntrHold(start), shared->CntrConfig.ChipHoldValue[start] );
         } else {
            //shared->CntrState[start].HoldValue = vals->Value;
         }

         if (shared->CntrState[cntr.Start].Operation == InstantEventCount) {
            daq_cntr_check_overflow_state(daq_dev, &shared->CntrState[cntr.Start], curr->Value, 0, 0);
            curr->Overflow = (__u16)shared->CntrState[cntr.Start].Overflow;
         }

         ++curr;
         ++cntr.Start;
         cntr.Start %= CNTR_CHL_COUNT;
      }
   }

   if (unlikely(copy_to_user(cntr.Value, vals, cntr.Count * sizeof(CNTR_VALUE)))){
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_cntr_reset(daq_device_t *daq_dev, unsigned long arg)
{
   CNTR_RESET cntr;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= CNTR_CHL_COUNT || cntr.Count > CNTR_CHL_COUNT){
      return -EINVAL;
   }

   daq_cntr_reset(daq_dev, cntr.Start, cntr.Count);

   return 0;
}
