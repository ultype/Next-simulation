// ############################################################################
// ****************************************************************************
//                 Copyright (c) 2011, Advantech Co. Ltd.
//      THIS IS AN UNPUBLISHED WORK CONTAINING CONFIDENTIAL AND PROPRIETARY
//         INFORMATION WHICH IS THE PROPERTY OF ADVANTECH AUTOMATION CORP.
//
//    ANY DISCLOSURE, USE, OR REPRODUCTION, WITHOUT WRITTEN AUTHORIZATION FROM
//               ADVANTECH AUTOMATION CORP., IS STRICTLY PROHIBITED.
// ****************************************************************************
// ############################################################################
//
// File:        ai.c
// Environment: Kernel Mode
// Description: analog input functions.
//
// Revision History:
//	-- May 6, 2016	Created by Rocky.Ji
// ----------------------------------------------------------------------------

// the delay time in 100-nanosecond units
static __inline void daq_udelay(daq_device_t *daq_dev, uint32 usecond) 
{
   while(usecond-- != 0) {
      AdxMemInD(daq_dev->iomem_base[0], 0); //This operation need about 1.975 us
   } 
}

/************************************************************************
Function:    daq_fai_configure_trigger
Description: configure trigger function.
Arguments:   daq_dev - device extension
Return:      <NONE>
************************************************************************/
static  
void daq_fai_configure_trigger(daq_device_t * daq_dev)
{
   daq_kshared_t  *shared = &daq_dev->kshared;
   trg_config_t  *trigger = shared->fai_param.trigger;

   SW_TRG_R       sw_trg  = {0};
   int            is_trig_start_set = 0;

   //--------------------------
   // DelayToStart

   // Trigger0
   if (trigger[0].source != SignalNone && trigger[0].action == DelayToStart) {
      is_trig_start_set = 1;

      if(trigger[0].source >= SigAi0) {
         IOREGS->AI_ATRG[0].SRC = ANATRG_SRC_AIx(trigger[0].source - SigAi0);
         IOREGS->AI_ATRG[0].FN  = TRG_FN_START;
         IOREGS->AI_ATRG[0].EDG = trigger[0].edge == RisingEdge ? TRG_EDGE_RISING : TRG_EDGE_FALLING;
         IOREGS->AI_ATRG0DNUM   = trigger[0].delay_count;
         IOREGS->AI_ATRG0THRD   = trigger[0].level_bin;
         IOREGS->AI_ATRG0HYST   = trigger[0].hyst_idx_bin;

         sw_trg.TOUT0SRC = TRG_OUTSRC_ATRG0;
      } else { // SigExtDigTrigger0
         IOREGS->AI_DTRG[0].FN   = TRG_FN_START;
         IOREGS->AI_DTRG[0].EDG  = trigger[0].edge == RisingEdge ? TRG_EDGE_RISING : TRG_EDGE_FALLING;
         IOREGS->AI_DTRG[0].FDRM = 1;
         IOREGS->AI_DTRG0DNUM    = trigger[0].delay_count;

         sw_trg.TOUT0SRC = TRG_OUTSRC_DTRG0;
      }

      //The source of Trigger Output 1 will be SW Stop if it is not set.
      sw_trg.TOUT1SRC = TRG_OUTSRC_SWSTP;
   }

   // Trigger1
   if (trigger[1].source != SignalNone && trigger[1].action == DelayToStart) {
      is_trig_start_set = 1;

      if(trigger[1].source >= SigAi0) {
         IOREGS->AI_ATRG[1].SRC = ANATRG_SRC_AIx(trigger[1].source - SigAi0);
         IOREGS->AI_ATRG[1].FN  = TRG_FN_START;
         IOREGS->AI_ATRG[1].EDG = trigger[1].edge == RisingEdge ? TRG_EDGE_RISING : TRG_EDGE_FALLING;
         IOREGS->AI_ATRG1DNUM   = trigger[1].delay_count;
         IOREGS->AI_ATRG1THRD   = trigger[1].level_bin;
         IOREGS->AI_ATRG1HYST   = trigger[1].hyst_idx_bin;

         sw_trg.TOUT1SRC = TRG_OUTSRC_ATRG1;
      } else { // SigExtDigTrigger1
         IOREGS->AI_DTRG[1].FN   = TRG_FN_START;
         IOREGS->AI_DTRG[1].EDG  = trigger[1].edge == RisingEdge ? TRG_EDGE_RISING : TRG_EDGE_FALLING;
         IOREGS->AI_DTRG[1].FDRM = 1;
         IOREGS->AI_DTRG1DNUM    = trigger[1].delay_count;

         sw_trg.TOUT1SRC = TRG_OUTSRC_DTRG1;
      }

      // The source of Trigger Output 0 will be SW Stop if it is never set.
      if (sw_trg.TOUT0SRC == TRG_OUTSRC_DISABLED) {
         sw_trg.TOUT0SRC = TRG_OUTSRC_SWSTP;
      }
   }

   // Enable SW start trigger
   shared->fai_status.sw_start = !is_trig_start_set && shared->fai_param.rec_cycles != 1;

   //--------------------------
   // DelayToStop

   // Trigger0
   if (trigger[0].source != SignalNone && trigger[0].action == DelayToStop) {

      if(trigger[0].source >= SigAi0) {
         IOREGS->AI_ATRG[0].SRC = ANATRG_SRC_AIx(trigger[0].source - SigAi0);
         IOREGS->AI_ATRG[0].FN  = TRG_FN_STOP;
         IOREGS->AI_ATRG[0].EDG = trigger[0].edge == RisingEdge ? TRG_EDGE_RISING : TRG_EDGE_FALLING;
         IOREGS->AI_ATRG0DNUM   = trigger[0].delay_count;
         IOREGS->AI_ATRG0THRD   = trigger[0].level_bin;
         IOREGS->AI_ATRG0HYST   = trigger[0].hyst_idx_bin;

         sw_trg.TOUT0SRC = TRG_OUTSRC_ATRG0;
      } else { // SigExtDigTrigger0
         IOREGS->AI_DTRG[0].FN   = TRG_FN_STOP;
         IOREGS->AI_DTRG[0].EDG  = trigger[0].edge == RisingEdge ? TRG_EDGE_RISING : TRG_EDGE_FALLING;
         IOREGS->AI_DTRG[0].FDRM = 1;
         IOREGS->AI_DTRG0DNUM    = trigger[0].delay_count;

         sw_trg.TOUT0SRC = TRG_OUTSRC_DTRG0;
      }

      //The source of Trigger Output 1 will be SW Start if it is not set.
      if (sw_trg.TOUT1SRC == TRG_OUTSRC_DISABLED) { 
         sw_trg.TOUT1SRC = TRG_OUTSRC_SWSTA;
      }
   }

   // Trigger1
   if (trigger[1].source != SignalNone && trigger[1].action == DelayToStop) {

      if(trigger[1].source >= SigAi0) {
         IOREGS->AI_ATRG[1].SRC = ANATRG_SRC_AIx(trigger[1].source - SigAi0);
         IOREGS->AI_ATRG[1].FN  = TRG_FN_STOP;
         IOREGS->AI_ATRG[1].EDG = trigger[1].edge == RisingEdge ? TRG_EDGE_RISING : TRG_EDGE_FALLING;
         IOREGS->AI_ATRG1DNUM   = trigger[1].delay_count;
         IOREGS->AI_ATRG1THRD   = trigger[1].level_bin;
         IOREGS->AI_ATRG1HYST   = trigger[1].hyst_idx_bin;

         sw_trg.TOUT1SRC = TRG_OUTSRC_ATRG1;
      } else { // SigExtDigTrigger1
         IOREGS->AI_DTRG[1].FN   = TRG_FN_STOP;
         IOREGS->AI_DTRG[1].EDG  = trigger[1].edge == RisingEdge ? TRG_EDGE_RISING : TRG_EDGE_FALLING;
         IOREGS->AI_DTRG[1].FDRM = 1;
         IOREGS->AI_DTRG1DNUM    = trigger[1].delay_count;

         sw_trg.TOUT1SRC = TRG_OUTSRC_DTRG1;
      }

      // The source of Trigger Output 0 will be SW Start if it is never set.
      if (sw_trg.TOUT0SRC == TRG_OUTSRC_DISABLED) {
         sw_trg.TOUT0SRC = TRG_OUTSRC_SWSTA;
      }
   }

   IOREGS->AI_RETRGEN = 1;
   IOREGS->AI_RETRGEN = 0;

   //setting Trigger output for SW trigger
   if (sw_trg.TOUT0SRC == TRG_OUTSRC_DISABLED && sw_trg.TOUT1SRC == TRG_OUTSRC_DISABLED) {
      sw_trg.TOUT0SRC = TRG_OUTSRC_SWSTA;
      sw_trg.TOUT1SRC = TRG_OUTSRC_SWSTP;
   }
   sw_trg.SWSTA = !is_trig_start_set;
   IOREGS->AI_SWTRG.xval = sw_trg.xval;

   daq_trace(("sw trigger: 0x%x, D-trig setting: 0x%x\n", sw_trg.xval, *(uint32*)IOREGS->AI_DTRG));   
}

/************************************************************************
Function: daq_ai_config_channel
Description: configure the AI channels, such as the channel's gain
             code and signal connection.
Arguments:
   daq_dev - device extension
   phyChan - physical channel number.
   gain - the gain code will be set to the channel
   sctype -- signal connection type will be set to the channel
Return:
   <NONE>
************************************************************************/
static  
void daq_ai_config_channel(
   daq_device_t *daq_dev,
   uint32        ch_start, 
   uint32        ch_count, 
   uint8        *sctype, 
   uint8        *gain,
   uint8        *coupling,
   uint8        *iepe)
{
   daq_kshared_t *shared = &daq_dev->kshared;
   AI_CH_R       ch_reg = {0};
   uint32        ch_mask = AI_CH_MASK(shared);
   uint32        ch, i;

   for (i = 0; i < ch_count; ++i) {
      ch = (ch_start + i) & ch_mask;

      ch_reg.PSEDIF = !!(sctype[ch] == PseudoDifferential);
      ch_reg.CPLING = !!(coupling[ch] == DCCoupling);
      ch_reg.GAIN   = gain[ch];
      IOREGS->AI_CH[ch].xval = ch_reg.xval;

      if (iepe[ch] == IEPENone) {
         IOREGS->AI_CHIEPE[ch].EN   = 0;
         IOREGS->AI_CHIEPE[ch].CURR = 0;
      } else {
         IOREGS->AI_CHIEPE[ch].CURR = iepe[ch] == IEPE10mA ? AI_CH_IEPE_10mA : 0;
         IOREGS->AI_CHIEPE[ch].EN   = 1;
      }      
   }
}

//------------------------------------------------------------------------
// FAI common routines
//------------------------------------------------------------------------

static
void daq_fai_initialize_rbuf(daq_kshared_t *shared)
{
   uint32 half_fifo = AI_DATA_DMA_SIZE / 2;

   shared->fai_rb_status.RP  = 0;

   if (shared->fai_status.ov_sect_len > half_fifo) {
      shared->fai_rb_status.PP = half_fifo;
      shared->fai_rb_status.SC = shared->fai_status.ov_sect_len;
   } else {
      shared->fai_rb_status.PP = shared->fai_status.ov_sect_len;
      shared->fai_rb_status.SC = 0;
   }
};

//------------------------------------------------------------------------
// global functions
//------------------------------------------------------------------------

/************************************************************************
Function: AiHardareInitialize
Description: initialize the h/w register for analog input operations.
Arguments: daq_dev - device extension
Return:    <NONE>
************************************************************************/
void daq_ai_initialize_hardware(daq_device_t *daq_dev, int booting)
{
   daq_kshared_t *shared = &daq_dev->kshared;

   // Load AI calibration data from EEPROM to ram
   IOREGS->ACC.AC_DAT = AC_DATA_CLEAR;
   IOREGS->ACC.AC_CMD = AC_CMD_LD_TO_RAM;
   daq_udelay(daq_dev, 200);

   // Configure AI channel
   daq_ai_config_channel(daq_dev, 0, AI_CH_COUNT(shared), 
      shared->ai_ch_sctype, shared->ai_ch_gain, shared->ai_ch_cpl, shared->ai_ch_iepe);

   // DMA, interrupt, etc
   IOREGS->AI_DMAEN     = 0;
   IOREGS->AI_IE.xval   = 0;
   IOREGS->DEV_IF0.xval = AI_INT_MASK;

   IOREGS->AI_DDMAADRL  = IOREGS->AI_DDMAADRH = IOREGS->AI_DDMASIZE = 0;
   IOREGS->AI_PDMAADRL  = IOREGS->AI_PDMAADRH = 0;
   IOREGS->AI_TDMAADRL  = IOREGS->AI_TDMAADRH = IOREGS->AI_TDMASIZE = 0;

   // Sampling frequency & DDS
   IOREGS->ADC_CTL.DECI  = shared->sai_param.deci_selector;
   IOREGS->ADC_CTL.SMOD  = shared->sai_param.samp_mode;
   IOREGS->ADC_CTL.DFLT  = ADC_DFLT_RSPN_LOWDELAY;             // Always enable low group delay
   IOREGS->REF_CLKSRC    = INTERNAL_CLOCK;
   IOREGS->DDS_TUNING    = shared->sai_param.dds_tuning;
   IOREGS->DDS_CTL.ACMOD = DDS_ACMOD_UPD_ALL;

   // Trigger
   IOREGS->AI_DTRG[0].xval = IOREGS->AI_DTRG[1].xval = 0;
   IOREGS->AI_ATRG[0].xval = IOREGS->AI_ATRG[1].xval = 0;
   IOREGS->AI_SWTRG.xval   = 0;

   // Calibration
   IOREGS->ACC.AC_EN   = 0;
   IOREGS->ACC.AC_VREF = AC_VREF_0mV;

   // Re-calculate logical channel
   shared->ai_log_ch_count = AI_CH_COUNT(shared);
}

/************************************************************************
Function: daq_ai_set_channel
Description: set the parameter of the specified AI channels.
Return: <NONE>
************************************************************************/
void daq_ai_set_channel(daq_device_t *daq_dev, AI_SET_CH *arg)
{
   daq_kshared_t *shared = &daq_dev->kshared;
   uint32        ch_mask = AI_CH_MASK(shared);
   uint32        ch, i;

   // configure the channels
   for (i = 0; i < arg->PhyCHCount; ++i) {
      ch = (arg->PhyCHStart + i) & ch_mask;
      if (arg->SetWhich & AI_SET_SCTYPE)   { shared->ai_ch_sctype[i] = arg->CHCfg[i].SCType;  }
      if (arg->SetWhich & AI_SET_GAIN)     { shared->ai_ch_gain[i]   = arg->CHCfg[i].Gain;    }
      if (arg->SetWhich & AI_SET_COUPLING) { shared->ai_ch_cpl[i]    = arg->CHCfg[i].CplType; }
      if (arg->SetWhich & AI_SET_IEPE)     { shared->ai_ch_iepe[i]   = arg->CHCfg[i].IepeType;}
   }

   //If IEPE is enabled, adjust to Pseudo-Differential automatically.
   for (i = 0; i < arg->PhyCHCount; ++i) {
      if(shared->ai_ch_iepe[i] != IEPENone) {
         shared->ai_ch_sctype[i] = PseudoDifferential;
      }
   }

   daq_ai_config_channel(daq_dev, arg->PhyCHStart, arg->PhyCHCount, 
      shared->ai_ch_sctype, shared->ai_ch_gain, shared->ai_ch_cpl, shared->ai_ch_iepe);
}

/************************************************************************
Function: daq_fai_set_param
Description: Set the parameters for FAI operation.
Return: ErrorCode
************************************************************************/
ErrorCode daq_fai_set_param(daq_device_t *daq_dev, fai_config_t *arg)
{
   unsigned long flags;

   x_fai_spin_lock(daq_dev, flags);
   if (daq_dev->kshared.fai_status.fn_state != DAQ_FN_IDLE) {
      x_fai_spin_unlock(daq_dev, flags);
      return ErrorFuncBusy;
   } 
   // We had own FAI resource, save the FAI parameters. 
   daq_dev->kshared.fai_param = *arg;
   daq_dev->kshared.fai_param.phy_ch_start &= AI_CH_MASK(&daq_dev->kshared);
   daq_dev->kshared.fai_param.log_ch_count = x_min(arg->log_ch_count, daq_dev->kshared.ai_log_ch_count);
   x_fai_spin_unlock(daq_dev, flags);

   daq_dev_signal_event(daq_dev, KdxDevPropChged);

   // FAI SampleFreq & DDS
   // The following Will be done in DLL due to we must wait the clock to be stable. 
   /*
   IOREGS->REF_CLKSRC    = INTERNAL_CLOCK;
   IOREGS->DDS_TUNING    = daq_dev->kshared.fai_param.dds_tuning;
   IOREGS->DDS_CTL.ACMOD = DDS_ACMOD_UPD_ALL;

   IOREGS->ADC_CTL.DECI  = daq_dev->kshared.fai_param.deci_selector;
   IOREGS->ADC_CTL.SMOD  = daq_dev->kshared.fai_param.samp_mode;
   IOREGS->ADC_CTL.DFLT  = ADC_DFLT_RSPN_LOWDELAY;             // Always enable low group delay
   */
   return Success;
}

/************************************************************************
Routine : daq_fai_start_acquisition
Description:
      start the hardware for the data acquisition.
Arguments:
   daq_dev - device extension.
   request - Handle to a framework request object which will be suspended or completed.
Return: 
   ErrorCode
************************************************************************/
ErrorCode daq_fai_start_acquisition(daq_device_t *daq_dev, uint32 acq_mode)
{
   daq_kshared_t *shared = &daq_dev->kshared;
   ErrorCode     ret     = Success;
   unsigned long flags;

   //
   // Reset all running-time data --------------------------------
   //
   x_fai_spin_lock(daq_dev, flags);
   do {
      if (shared->fai_status.fn_state == DAQ_FN_IDLE) {
         ret = ErrorFuncNotInited;
         break;
      }

      if (shared->fai_status.fn_state == DAQ_FN_RUNNING) {
         ret = ErrorFuncBusy;
         break;
      }

      memset(&shared->fai_status, 0, sizeof(shared->fai_status));
      shared->fai_status.fn_state   = DAQ_FN_RUNNING;

   } while (0);
   x_fai_spin_unlock(daq_dev, flags);

   if (ret != Success) {
      return ret;
   }

   shared->fai_status.acq_mode    = acq_mode;
   shared->fai_status.buf_length  = shared->fai_param.samp_count;
   shared->fai_status.ov_sect_len = shared->fai_param.sect_length;
   shared->fai_status.rec_limit   = acq_mode == DAQ_ACQ_INFINITE ? 0 : shared->fai_status.buf_length;
   shared->fai_status.prev_sn     = -1;

   shared->event_signaled[KdxAiDataReady] = 0;
   shared->event_signaled[KdxAiOverrun] = 0;
   shared->event_signaled[KdxAiStopped] = 0;
   shared->event_signaled[KdxAiCacheOverflow] = 0;
   shared->event_signaled[KdxAiConvStopped] = 0;

   daq_dev_clear_event(daq_dev, KdxAiDataReady);
   daq_dev_clear_event(daq_dev, KdxAiOverrun);
   daq_dev_clear_event(daq_dev, KdxAiStopped);
   daq_dev_clear_event(daq_dev, KdxAiCacheOverflow);
   daq_dev_clear_event(daq_dev, KdxAiConvStopped);

   //
   // Initialize hardware --------------------------------
   //

   // Disable DMA
   IOREGS->AI_DMAEN   = 0;
   IOREGS->AI_FIFOCLR = 1;

   // Disable interrupt
   IOREGS->AI_IE.xval = 0;
   IOREGS->DEV_IF0.xval = AI_INT_MASK;
  
   // Set Ring buffer periodic count and section count(it is buffer size count actually)
   IOREGS->AI_PNUM = 0;
   IOREGS->AI_SNUM = 0;

   // In order to reset WP address, the stop process will reset DMA / Trigger memory size
   IOREGS->AI_DDMASIZE = 0;
   IOREGS->AI_TDMASIZE = 0;

   // Set DMA address
   IOREGS->AI_DDMAADRL = (uint32)daq_dev->fai_ddma_buf.daddr;
   IOREGS->AI_DDMAADRH = (uint32)(daq_dev->fai_ddma_buf.daddr >> 32);
   IOREGS->AI_DDMASIZE = daq_dev->fai_ddma_buf.size;

   IOREGS->AI_PDMAADRL = (uint32)daq_dev->fai_pdma_buf.daddr;
   IOREGS->AI_PDMAADRH = (uint32)(daq_dev->fai_pdma_buf.daddr >> 32);

   IOREGS->AI_TDMAADRL = (uint32)daq_dev->fai_tdma_buf.daddr;
   IOREGS->AI_TDMAADRH = (uint32)(daq_dev->fai_tdma_buf.daddr >> 32);
   IOREGS->AI_TDMASIZE = daq_dev->fai_tdma_buf.size;

   // Init PC & SC
   daq_fai_initialize_rbuf(shared);
   IOREGS->AI_PNUM = shared->fai_rb_status.PP;
   IOREGS->AI_SNUM = shared->fai_rb_status.SC;

   // The device support 3 kinds of AI interrupt source
   // PC: Periodic counter Interrupt
   // SC: Samples counter Interrupt
   // CF: Conversion finished Interrupt
   IOREGS->AI_IE.PC = 1;
   IOREGS->AI_IE.SC = !!shared->fai_rb_status.SC;
   IOREGS->AI_IE.CF = 1;/*!!IS_DELAY_TO_STOP_TRIG(shared->fai_param)*/;

   // Enable DMA
   IOREGS->AI_DMAEN = 1;

   // Enable AI channel
   {
      int i, ch_en = shared->fai_param.phy_ch_enabled;
      for (i = 0; i < AI_CH_COUNT(shared); ++i, ch_en >>= 1) {
         IOREGS->AI_CH[i].EN = ch_en & 0x1;
      }
   }
   
   // Configure trigger
   daq_fai_configure_trigger(daq_dev);

   return Success;
}

/************************************************************************
Function: daq_fai_stop_acquisition
Description: 
      terminate the current FAI operation. this function do the actual work
   of terminating a FAI operation.
      Supply this function just is because that we need do the work more 
   than place in the driver while the FaiTerminate is mainly for the device
   IO control and not suitable being called internally to do the work.
Arguments:
   daq_dev - device extension.
   cleanup -- whether we should release any resource allocated for FAI or not.
Return Value:
   STATUS_SUCCESS if the operation succeeds. Otherwise, this function
   must return one of the error status values
************************************************************************/
void daq_fai_stop_acquisition(daq_device_t *daq_dev, int cleanup)
{
   daq_kshared_t *shared     = &daq_dev->kshared;
   fai_status_t  *fai_status = &shared->fai_status;

   unsigned long  flags;

   x_fai_spin_lock(daq_dev, flags);
   if (fai_status->fn_state != DAQ_FN_RUNNING) {
      x_fai_spin_unlock(daq_dev, flags);
   } else {
      // update FAI state
      fai_status->fn_state = DAQ_FN_STOPPED;
      x_fai_spin_unlock(daq_dev, flags);

      // Send out software stop trigger
      IOREGS->AI_SWTRG.TOUT0SRC = TRG_OUTSRC_SWSTP;
      IOREGS->AI_SWTRG.SWSTP    = 1;

      // Disable DMA
      IOREGS->AI_DMAEN = 0;

      // Stop Interrupt
      IOREGS->AI_IE.xval   = 0;
      IOREGS->DEV_IF0.xval = AI_INT_MASK;

      // signal the 'AI terminated' event. Send the event only when we had completed a request.
      if (!shared->event_signaled[KdxAiStopped]) { 
         shared->event_signaled[KdxAiStopped] = 1;
         daq_dev_signal_event(daq_dev, KdxAiStopped);
      }

      // If we had pending the 'FAI Start' request for synchronous FAI, complete the request now
      x_fai_complete_request(daq_dev);
   }

   // Set Ring buffer periodic count and section count(it is buffer size count actually)
   IOREGS->AI_PNUM = 0;
   IOREGS->AI_SNUM = 0;

   // Clear DMA FIFO
   IOREGS->AI_FIFOCLR = 1;

   if (cleanup) {
      x_fai_free_buffer(daq_dev);
   }

   daq_trace(("<-- daq_fai_stop_acquisition\n"));
}

/************************************************************************
Function: daq_fai_update_rp_for_delay_to_stop
Description: update the read pos(rp) if 'delay to stop' trigger is active.
Return: <None>
************************************************************************/
void daq_fai_update_rp_for_delay_to_stop(daq_kshared_t *shared, uint32 trg_src)
{
   fai_status_t *fai_status = &shared->fai_status;

   uint32 avail_start = 0;
   uint32 avail_count = 0;
   uint32 delay_count = 0;

   //Retrieve trigger delay count according to trigger source
   switch(trg_src)
   {
   case 0x01:  //Digital Trigger 0
   case 0x03:  //Analog Trigger 0
      delay_count = shared->fai_param.trigger[0].delay_count * shared->fai_param.log_ch_count;
      break;
   case 0x02:  //Digital Trigger 1
   case 0x04:  //Analog Trigger 1
      delay_count = shared->fai_param.trigger[1].delay_count * shared->fai_param.log_ch_count;
      break;
   default:
      return;
   }
   
   if (!delay_count) { 
      return; 
   }

   //////////////////////////////////////////////////////////////////////////
   //DelayToEnd Solution 
   // User Buffer
   //   |---------------------------------------------------------------|
   //Case0:
   //                                  ^TriggerPos          (The last data)
   //                                  |--------------------|             DelayCount
   //                                                       ^AvailDataStart
   //Case1:
   //                                  ^TriggerPos          ^WP(The last data) 
   //                                  |--------------------|             DelayCount
   //   ^AvailDataStart
   //Case2:
   //            ^WP(The last data)    ^TriggerPos
   //   |--------|                     |--------------------------------| DelayCount 
   //            ^AvailDataStart
   //
   //Case3:
   //                                   ^WP(The last data)    ^TriggerPos
   //   |-------------------------------|                     |---------| DelayCount 
   //   ^AvailDataStart
   //
   if (delay_count > shared->fai_param.samp_count) {
      avail_start = fai_status->wr_pos;
      avail_count = shared->fai_param.samp_count;
   } else {
      if (fai_status->wr_pos >= delay_count) { //trig_pos = fai_status->wr_pos - delay_count;
         if (fai_status->wp_run_back) {// case0
            avail_start = fai_status->wr_pos;
            avail_count = shared->fai_param.samp_count;
         } else { // case1
            avail_start = 0;
            avail_count = fai_status->wr_pos;
         }
      } else { // trig_pos = shared->fai_param.samp_count - (delay_count - fai_status->wr_pos); 
         if (fai_status->wp_run_back) {// case 2
            avail_start = fai_status->wr_pos;
            avail_count = shared->fai_param.samp_count;
         } else {// case 3
            avail_start = 0;
            avail_count = fai_status->wr_pos;
         }
      }
   }

   if (avail_count == shared->fai_param.samp_count) {
      ++fai_status->wp_run_back;
   }

   //Adjust the RP(to indicate the max available data)
   if (fai_status->rd_pos <= avail_start) {
      fai_status->rd_pos = avail_start;
   }

   daq_trace(("RP=%d, WP=%d, wp_run_back=%d; TrigEnd=%d, AvailDataStart=%d, AvailDataCount=%d\n", 
      fai_status->rd_pos, fai_status->wr_pos, fai_status->wp_run_back, fai_status->wr_pos, avail_start, avail_count));
}