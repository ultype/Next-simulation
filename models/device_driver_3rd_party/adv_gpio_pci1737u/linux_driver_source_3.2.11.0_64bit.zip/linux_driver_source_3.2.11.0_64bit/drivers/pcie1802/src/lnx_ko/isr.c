/*
 * isr.c
 *
 *  Created on: 2015-06-10
 *      Author: 
 */
#include "kdriver.h"
#include "cmn/dev_fn.h"

irqreturn_t lnx_interrupt_handler(int irq, void *dev_id)
{
   daq_device_t *daq_dev = (daq_device_t *)dev_id;

   if (!daq_interrupt_handler(daq_dev)) {
      return IRQ_RETVAL(0);
   }

   // schedule a tasklet
   tasklet_schedule(&daq_dev->dev_tasklet);
   return IRQ_RETVAL(1);
}

void lnx_interrupt_tasklet(unsigned long arg)
{
   daq_device_t *daq_dev = (daq_device_t *)arg;
   daq_interrupt_tasklet(daq_dev);
}
