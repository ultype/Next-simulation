// ############################################################################
// ****************************************************************************
//                 Copyright (c) 2011, Advantech Co. Ltd.
//      THIS IS AN UNPUBLISHED WORK CONTAINING CONFIDENTIAL AND PROPRIETARY
//         INFORMATION WHICH IS THE PROPERTY OF ADVANTECH AUTOMATION CORP.
//
//    ANY DISCLOSURE, USE, OR REPRODUCTION, WITHOUT WRITTEN AUTHORIZATION FROM
//               ADVANTECH AUTOMATION CORP., IS STRICTLY PROHIBITED.
// ****************************************************************************
// ############################################################################
//
// File:        dio.c
// Environment: Kernel Mode
// Description: Kernel mode driver analog output functions.
//
// Revision History:
//	-- May 6, 2016	Created by Rocky.Ji
// ----------------------------------------------------------------------------

/************************************************************************
Function: daq_dio_initialize_hardware
Description: initialize the h/w register 
Arguments:
   daq_dev - device extension
Return: <NONE>
************************************************************************/
void daq_dio_initialize_hardware(daq_device_t *daq_dev, int booting)
{
   // Need do nothing!
}

/************************************************************************
Function: daq_dio_set_port
Description: set the DIO port configuration
Return: ErrorCode
************************************************************************/
ErrorCode daq_dio_set_port(daq_device_t *daq_dev, DIO_SET_PORT *arg)
{
   switch(arg->SetWhich)
   {
   case DIFLT_SET_BLKINTVL:
      {
         daq_dev->kshared.diflt_blk_time = *(uint32*)arg->Buffer;
         IOREGS->DIO_CTL.DFDUR = (uint8)daq_dev->kshared.diflt_blk_time;
      }
      break;
   case DIFLT_SET_CHENBED:
      {
         uint8 * ptr = daq_dev->kshared.diflt_ch_enabled;

         ptr[0] = arg->Buffer[0];
         IOREGS->DIO_CTL.B0DFEN = !!arg->Buffer[0];
      }
      break;
   default:
      return ErrorPropNotSpted;
   }
   
   return Success;
}

/************************************************************************
Function: daq_dio_write_do_port
Description: write the DO port.
Return: ErrorCode
************************************************************************/
ErrorCode daq_dio_write_do_port(daq_device_t *daq_dev, DIO_WRITE_PORT *arg)
{
   uint32 i, port;

   if (arg->PortStart >= DIO_PORT_COUNT || arg->PortCount >DIO_PORT_COUNT) {
      return ErrorParamOutOfRange;
   }
   
   for (i = 0; i < arg->PortCount; ++i) {
      port = (i + arg->PortStart) % DIO_PORT_COUNT;
      IOREGS->DO_DAT[port] = arg->Data[i];
   }

   return Success;
}

/************************************************************************
Function: daq_dio_write_do_bit
Description: write the DO channel.
Return: ErrorCode
************************************************************************/
ErrorCode daq_dio_write_do_bit(daq_device_t *daq_dev, DIO_WRITE_BIT *arg)
{
   unsigned long flags;
   uint32 val;

   if (arg->Port > DIO_PORT_COUNT || arg->Bit > DO_CH_COUNT) {
      return ErrorParamOutOfRange;
   }
   
   x_dev_spin_lock(daq_dev, flags);
      val  = IOREGS->DO_DAT[arg->Port]; 
      val &= ~(1 << arg->Bit);
      val |= (!!arg->State) << arg->Bit; 
      IOREGS->DO_DAT[arg->Port] = (uint8)val;
   x_dev_spin_unlock(daq_dev, flags);

   return Success;
}

/************************************************************************
Function: daq_dio_set_int
Description: set the trigger edge / gate control for DI interrupt.
Return: ErrorCode
************************************************************************/
ErrorCode daq_dio_set_int(daq_device_t *daq_dev, DIO_SET_INT *arg)
{
   uint32 i;  

   switch (arg->SetWhich)
   {
   case DIINT_SET_TRIGEDGE:
      {
         if (arg->SrcStart + arg->SrcCount > DI_INT_SRC_COUNT) {
            return ErrorParamOutOfRange;
         }
         for (i = 0; i < arg->SrcCount; ++i) {
            daq_dev->kshared.diint_trig_edge[arg->SrcStart + i] = arg->Buffer[i];
         }
      }
      break;
   default:
      return ErrorPropNotSpted;
   }
   return Success;
}

/************************************************************************
Function: daq_dio_exec_di_snap
Description: execute the DI snap command: start, stop.
Return: ErrorCode
************************************************************************/
ErrorCode daq_dio_exec_di_snap(daq_device_t *daq_dev, DIO_EXEC_DISNAP *arg)
{
   uint32 kdx;

   // Check port range
   if (arg->PortStart >= DIO_PORT_COUNT || arg->PortCount >DIO_PORT_COUNT) {
      return ErrorParamOutOfRange;
   }

   // Check event id
   kdx = kdxofEvent(arg->EventType);
   if (kdx < KdxDiBegin || kdx > KdxDiEnd) {
      return ErrorEventNotSpted;
   }

   // Save snap parameters
   daq_dev->kshared.di_snap[kdx - KdxDiBegin].start = (uint8)arg->PortStart;
   daq_dev->kshared.di_snap[kdx - KdxDiBegin].count = (uint8)arg->PortCount;

   // Setup hardware
   if (arg->Command == DISNAP_CMD_START) {
      // Reset the associated event
      daq_dev->kshared.event_signaled[kdx] = false; 
      daq_dev_clear_event(daq_dev, kdx);

      // Trigger edge
      switch (daq_dev->kshared.diint_trig_edge[0])
      {
      case RisingEdge:   IOREGS->DIO_CTL.B0REDG = 1; break;
      case FallingEdge:  IOREGS->DIO_CTL.B0FEDG = 1; break;
      case BothEdge: 
           IOREGS->DIO_CTL.B0REDG = 1;
           IOREGS->DIO_CTL.B0FEDG = 1; 
           break;
      default:
         return ErrorPropValueNotSpted;
      }

      // Enable interrupt
      IOREGS->DIO_CTL.B0IE = 1;
   } else {
      IOREGS->DIO_CTL.B0IE   = 0;
      IOREGS->DIO_CTL.B0REDG = 0;
      IOREGS->DIO_CTL.B0FEDG = 0; 
   }

   return Success;
}