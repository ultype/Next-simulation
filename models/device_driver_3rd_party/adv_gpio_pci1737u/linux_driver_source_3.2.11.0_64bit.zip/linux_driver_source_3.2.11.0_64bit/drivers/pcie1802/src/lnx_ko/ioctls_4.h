/*
 * Ioctls.h
 *
 *  Created on: 2011-8-29
 *      Author: rocky
 */

#ifndef DAQNAVI_IOCTL_DEFINITION
#define DAQNAVI_IOCTL_DEFINITION

#include <linux/ioctl.h>

// Magic Number of IOCTLs
#define IOCTL_MAGIC_KLIB              'k'
#define IOCTL_MAGIC_DEV               'a'
#define IOCTL_MAGIC_AI                'b'
#define IOCTL_MAGIC_AO                'c'
#define IOCTL_MAGIC_DIO               'd'
#define IOCTL_MAGIC_CT                'e'

#define DAQCTL_RD(magic, number)      _IO(magic, number)
#define DAQCTL_WR(magic, number)      _IO(magic, number)
#define DAQCTL_NB(magic, number)      _IO(magic, number)

#define SIZEOF_VLST(st, field, vlen)  (offset_of(st, field) + vlen * sizeof(((st*)0)->field[0]))
#define DECL_64COMPAT(type, name)     union { type name; int64 _pad##name; }

//******************************************************************************************
//                                                                                         *
// IOCTL for klib operation                                                                *
//                                                                                         *
//******************************************************************************************
// Input: <None>
// Output: Handle of event
#define IOCTL_KLIB_CREATE_EVENT        DAQCTL_RD(IOCTL_MAGIC_KLIB, 1)

// Input: Handle of event
// Output: <None>
#define IOCTL_KLIB_CLOSE_EVENT         DAQCTL_RD(IOCTL_MAGIC_KLIB, 2)

// Input: Handle of event
// Output: <None>
#define IOCTL_KLIB_SET_EVENT           DAQCTL_RD(IOCTL_MAGIC_KLIB, 3)

// Input: Handle of event
// Output: <None>
#define IOCTL_KLIB_RESET_EVENT         DAQCTL_RD(IOCTL_MAGIC_KLIB, 4)

// Input: KLIB_WAIT_EVENT.
// Output: <None>
typedef struct KLIB_WAIT_EVENT {
   int32  Result;
   int32  Timeout;
   int32  WaitAll;
   uint32 Count;
   HANDLE *Events;
} KLIB_WAIT_EVENT, *PKLIB_WAIT_EVENT;

#define IOCTL_KLIB_WAIT_EVENT          DAQCTL_RD(IOCTL_MAGIC_KLIB, 5)

#ifndef ISA_NAME_MAX_LEN
#define ISA_NAME_MAX_LEN  32
#endif

// Input: pointer of structure ISA_DEV_INFO
// Output: <None>
typedef struct ISA_DEV_INFO {
   char   DriverName[ISA_NAME_MAX_LEN];
   char   DeviceName[ISA_NAME_MAX_LEN];
   uint32 IoBase;
   uint32 Irq;
   uint32 Dma;
} ISA_DEV_INFO, *PISA_DEV_INFO;

// Input:
// Output:
#define IOCTL_KLIB_ADD_DEV             DAQCTL_RD(IOCTL_MAGIC_KLIB, 6)
#define IOCTL_KLIB_REMOVE_DEV          DAQCTL_RD(IOCTL_MAGIC_KLIB, 7)

//******************************************************************************************
//                                                                                         *
// IOCTL for device operation                                                              *
//                                                                                         *
//******************************************************************************************

// input:  an array of struct USER_EVENT_INFO.
// output: <none>
typedef struct EVENT_INFO {
   DECL_64COMPAT(uint32, Id);
   DECL_64COMPAT(HANDLE, Handle);
} EVENT_INFO, *PEVENT_INFO;

#define IOCTL_DEV_REGISTER_EVENT       DAQCTL_RD(IOCTL_MAGIC_DEV, 1)
#define IOCTL_DEV_UNREGISTER_EVENT     DAQCTL_RD(IOCTL_MAGIC_DEV, 2)

// Input buffer:  uint32, EventID
// Output buffer: <None>
#define IOCTL_DEV_TRIGGER_EVENT        DAQCTL_WR(IOCTL_MAGIC_DEV, 3)

// Input: <None>
// Output: CHAR[64], device location information
#define IOCTL_DEV_GET_LOCATION         DAQCTL_RD(IOCTL_MAGIC_DEV, 4)

// Input: <None>
// Output: CHAR[64], board version( firmware version )
#define IOCTL_DEV_GET_BOARD_VER        DAQCTL_RD(IOCTL_MAGIC_DEV, 5)

// Input: <None>
// Output: <None>
#define IOCTL_DEV_LOCATE_DEVICE        DAQCTL_RD(IOCTL_MAGIC_DEV, 6)

// Input: the uint32 type boardID to be set to device
// Output: <None>
// Add these ioctrl code to manage the boardID problem of USB device.
#define IOCTL_DEV_SET_BOARDID          DAQCTL_WR(IOCTL_MAGIC_DEV, 7)

// Input buffer: <None>
// Output buffer: uint32[16], bool value, each element indicates whether a board id is freed or not.
#define IOCTL_DEV_GET_FREED_BOARDID    DAQCTL_RD(IOCTL_MAGIC_DEV, 8)

// Set WDT mode 
// Input buffer: uint32, the WDT Mode to be set to device
// Output Buffer:  <None>
#define IOCTL_DEV_SET_WDT_MODE         DAQCTL_WR(IOCTL_MAGIC_DEV, 9)

// Update the firmware of H/W
// Input buffer:  <depends on device>
// Output buffer: <depends on device>
typedef struct FW_DOWNLOAD {
   uint32 Length;
   void   *Data;
   uint32 *Result;
} FW_DOWNLOAD, *PFW_DOWNLOAD;

#define IOCTL_DEV_DOWNLOAD_FW          DAQCTL_WR(IOCTL_MAGIC_DEV, 10)

// Input:  uint32
// Output: uint8 []
#define IOCTL_DEV_READ_PRV_RGN         DAQCTL_RD(IOCTL_MAGIC_DEV, 11)
#define IOCTL_DEV_WRITE_PRV_RGN        DAQCTL_WR(IOCTL_MAGIC_DEV, 12)

// -------------------------------------------------------------------/
// ///////////////////////////////////////////////////////////////////
// For debug and calibration only !!!!!!!!!!!!!!!!!!
typedef struct DBG_REG_IO {
   uint64 Addr;
   uint32 Length;
   uint32 Value;
} DBG_REG_IO, *PDBG_REG_IO;

#define IOCTL_DEV_DBG_REG_IN           DAQCTL_RD(IOCTL_MAGIC_DEV, 13)
#define IOCTL_DEV_DBG_REG_OUT          DAQCTL_WR(IOCTL_MAGIC_DEV, 14)

typedef struct DBG_USB_IO {
   uint16  MajorCmd;
   uint16  MinorCmd;
   uint32  Result;
   uint32  Length;
   uint8   Data[0];
} DBG_USB_IO, *PDBG_USB_IO;

#define IOCTL_DEV_DBG_USB_IN           DAQCTL_WR(IOCTL_MAGIC_DEV, 15)
#define IOCTL_DEV_DBG_USB_OUT          DAQCTL_WR(IOCTL_MAGIC_DEV, 16)
// \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\/
// ------------------------------------------------------------------/

// Input buffer:   <None>
// Output Buffer:  a pointer to DEVICE_EXT_SHRED which had been mapped into caller process.
#define IOCTL_DEV_GET_KSHARED          DAQCTL_RD(IOCTL_MAGIC_DEV, 17)

// Input buffer:  <None>
// Output Buffer: a pointer to DEV_MEM_BAR which had been mapped into caller process.
#define IOCTL_DEV_GET_MEM_MAPPED       DAQCTL_RD(IOCTL_MAGIC_DEV, 18)

// Input buffer:   bool, shared writing allowed.
// Output Buffer:  <none>
#define IOCTL_DEV_MAKE_SHARED          DAQCTL_RD(IOCTL_MAGIC_DEV, 19)

// Input buffer:   <none>
// Output Buffer:  kernel driver version, ansi chars.
#define IOCTL_DEV_GET_DRV_VER          DAQCTL_RD(IOCTL_MAGIC_DEV, 20)

#define DRVSPEC_DN3  3 
#define DRVSPEC_DN4  4 
typedef struct DEVICE_HWINFO {
   uint32 DeviceNumber;  // -1 if it is DN4 driver
   uint32 ProductId;
   uint32 BoardId;
   union {
      uint32 BusSlot;    
      uint32 IoBase;     
   };
   uint32 DriverSpec;   // driver spec version, currently we support two version: 3.0 and 4.0.
   char   DriverName[32];
   char   DeviceName[32];
} DEVICE_HWINFO, *PDEVICE_HWINFO;

#define IOCTL_DEV_GET_HWINFO           DAQCTL_RD(IOCTL_MAGIC_DEV, 24)

//******************************************************************************************
//                                                                                         *
// IOCTL for analog input operation                                                        *
//                                                                                         *
//******************************************************************************************
// Input:    AI_SET_CH
// Output:   <none>
#define AI_SET_SCTYPE                  0x1
#define AI_SET_GAIN                    0x2
#define AI_SET_COUPLING                0x4
#define AI_SET_IMPEDANCE               0x8
#define AI_SET_BANDWIDTH               0x10
#define AI_SET_IEPE                    0x20
#define AI_SET_CH_ALL                  (-1)
typedef struct AI_CH_CFG {
   uint8  SCType;          // single-ended or differential
   uint8  Gain;            // gain code of the channel.
   uint8  CplType;         // AC/DC coupling.
   uint8  ImpdType;        // Impedance
   uint8  Bandwidth;       // Bandwidth
   uint8  IepeType;        // IEPE type
} AI_CH_CFG, *PAI_CH_CFG;

typedef struct AI_SET_CH {
   uint32    SetWhich;    // set which
   uint32    PhyCHStart;  // Physical channel number of the start channel to configure.
   uint32    PhyCHCount;  // Physical channel count to configure.
   AI_CH_CFG CHCfg[0];    // variable length array for channel data.
} AI_SET_CH, *PAI_SET_CH;

#define IOCTL_AI_SET_CH                DAQCTL_WR(IOCTL_MAGIC_AI, 1)

// Input:  AI_READ_CH.
// Output: an array of Binary data. The minimize size of the output buffer is
//         channel count to scan multiplies the size of each data.
typedef struct AI_READ_CH {
   uint32 PhyCHStart; // Physical channel number of the start channel
   uint32 LogCHCount; // logical channel count
   void   *Data;
} AI_READ_CH, *PAI_READ_CH;

#define IOCTL_AI_READ_CH               DAQCTL_RD(IOCTL_MAGIC_AI, 2)

// Set CJC channel
#define IOCTL_AI_SET_CJC               DAQCTL_WR(IOCTL_MAGIC_AI, 3)

// Input:  <NONE>.
// Output: an array of Binary data.
typedef struct AI_CJC_VALUE {
   uint32 CjcError;      //CJC error
   uint32 CjcValCount;   //The count of CJC Value
   uint8  CjcValues[0];  //variable length array for CJC value
} AI_CJC_VALUE, *PAI_CJC_VALUE;

#define IOCTL_AI_READ_CJC              DAQCTL_RD(IOCTL_MAGIC_AI, 4)

// Input:  AI_BURN_DETECT
// Output: uint32[]
typedef struct AI_BURN_DETECT {
   uint32 Command;
   uint32 CHStart;
   uint32 CHCount;
   uint32 *Status;
} AI_BURN_DETECT, *PAI_BURN_DETECT;

#define IOCTL_AI_BURN_DETECT           DAQCTL_RD(IOCTL_MAGIC_AI, 5)

// Input:  AI_USB_CALI
// Output: <none>
typedef struct AI_USB_CALI {
   uint16 CaliCmd;
   uint16 Gain;
   uint32 *Result;
} AI_USB_CALI, *PAI_USB_CALI;

#define IOCTL_AI_USB_CALI              DAQCTL_WR(IOCTL_MAGIC_AI, 6)

// Input:  FAI_FUNC_CFG.
// Output: <None>
#define IOCTL_FAI_SET_PARAM            DAQCTL_WR(IOCTL_MAGIC_AI, 7)

// Input:  <None>
// Output: pointer to FAI_BUFFER
#define IOCTL_FAI_SET_BUFFER           DAQCTL_NB(IOCTL_MAGIC_AI, 8)

// Input:  <None>
// Output: pointer to BUFFER
#define IOCTL_FAI_MAP_BUFFER           DAQCTL_NB(IOCTL_MAGIC_AI, 9)

// Input:  FAI_EXEC_ARG
// Output: <None>
#define FAI_CMD_START                  0x0
#define FAI_CMD_STOP                   0x1
#define FAI_CMD_RESUMEDMA              0x2

// For command 'stop'
#define FAI_FREE_RES                   0x1   

typedef struct FAI_EXEC_ARG {
   uint32 Command;
   union {
      uint32 AcqMode;    // For 'start' command
      uint32 StopFlag;   // For 'stop' command
      uint32 ResumeInfo; // For 'resume' command
   };
} FAI_EXEC_ARG, *PFAI_EXEC_ARG;

#define IOCTL_FAI_EXEC                 DAQCTL_WR(IOCTL_MAGIC_AI, 10)


//******************************************************************************************
//                                                                                         *
// IOCTL for analog output operation                                                       *
//                                                                                         *
//******************************************************************************************
#define AO_SET_CHVRG                   0x1
#define AO_SET_EXTREFUNI               0x2
#define AO_SET_EXTREFBI                0x4
#define AO_SET_ALL                     -1
typedef struct AO_SET_CH {
   uint32  SetWhich;
   double  ExtRefUnipolar;  // unipolar external reference value
   double  ExtRefBipolar;   // bipolar external reference value
   uint32  CHStart;         // channel number of the start channel to configure.
   uint32  CHCount;         // channel number of the end channel to configure.
   uint32  Gain[0];        // variable length array for channels gain.
} AO_SET_CH, *PAO_SET_CH;

#define IOCTL_AO_SET_CH                DAQCTL_WR(IOCTL_MAGIC_AO, 1)

// Input:  AO_WRITE_SAMPLES.
// Output: <None>
typedef struct AO_WRITE_CH {
   uint32 CHStart;     // channel number of the start channel to write data to.
   uint32 CHCount;     // count of channel to write data to.
   uint8  Data[0];     // variable length array for channel data. the array length should match the channel count.
} AO_WRITE_CH, *PAO_WRITE_CH;

#define IOCTL_AO_WRITE_CH              DAQCTL_WR(IOCTL_MAGIC_AO, 2)

// Input:  FAO_FUNC_CFG.
// Output: <None>
#define IOCTL_FAO_SET_PARAM            DAQCTL_WR(IOCTL_MAGIC_AO, 3)

// Input: pointer to user buffer
// Output: <None>
#define IOCTL_FAO_SET_BUFFER           DAQCTL_NB(IOCTL_MAGIC_AO, 4)

// Input: <NONE>
// Output: pointer to user buffer
#define IOCTL_FAO_MAP_BUFFER           DAQCTL_WR(IOCTL_MAGIC_AO, 5)

// Input: uint32 : acquisition mode: FINITE or INFINITE
// Output buffer: <None>
#define FAO_CMD_START                  0x0
#define FAO_CMD_STOP                   0x1

// For command 'stop'
#define FAO_FREE_RES                   0x1   // free resource or not: 0 -- do not free resource, 1 -- free resource.
#define FAO_BREAK_NOW                  0x2   // wait for the working buffer empty or not: 0 -- wait, 1 -- no wait, stop immediately,

typedef struct FAO_EXEC_ARG {
   uint32 Command;
   union {
      uint32 AcqMode;    // For 'start' command
      uint32 StopFlag;   // For 'stop' command
   };
} FAO_EXEC_ARG, *PFAO_EXEC_ARG;

#define IOCTL_FAO_EXEC                 DAQCTL_WR(IOCTL_MAGIC_AO, 6)

//******************************************************************************************
//                                                                                         *
// IOCTL for digital input/output operation                                                *
//                                                                                         *
//******************************************************************************************

// Input:   DIO_SET_PORT.
// Output:  <None>
#define DIO_SET_PORTDIR                0x1
#define DIFLT_SET_BLKINTVL             0x2
#define DIFLT_SET_CHENBED              0x3
typedef struct DIO_SET_PORT {
   uint32 SetWhich;
   uint32 PortStart;           
   uint32 PortCount;           
   uint8  Buffer[0];            
} DIO_SET_PORT, *PDIO_SET_PORT;

#define IOCTL_DIO_SET_PORT             DAQCTL_WR(IOCTL_MAGIC_DIO, 1)

// Input:  DIO_READ_PORT.
// Output: uint8 [] of DI port data.
typedef struct DIO_READ_PORT {
   uint32 PortStart;           
   uint32 PortCount;           
   uint8  *Data;
} DIO_READ_PORT, *PDIO_READ_PORT;

#define IOCTL_DIO_READ_DI_PORT        DAQCTL_RD(IOCTL_MAGIC_DIO, 2)

// Input:  DIO_WRITE_PORT.
// Output: <none>
typedef struct DIO_WRITE_PORT {
   uint32 PortStart;             
   uint32 PortCount;             
   uint8  Data[0];               
} DIO_WRITE_PORT, *PDIO_WRITE_PORT;

#define IOCTL_DIO_WRITE_DO_PORT       DAQCTL_WR(IOCTL_MAGIC_DIO, 3)

// Input:  DIO_READ_PORT.
// Output: uint8 [] of DO ports state.
#define IOCTL_DIO_READ_DO_PORT        DAQCTL_RD(IOCTL_MAGIC_DIO, 4)

// Input:  DIO_WRITE_BIT.
// Output: <none>
typedef struct DIO_WRITE_BIT {
   uint32 Port;             
   uint32 Bit;              
   uint8  State;            
} DIO_WRITE_BIT, *PDIO_WRITE_BIT;

#define IOCTL_DIO_WRITE_DO_BIT  	      DAQCTL_WR(IOCTL_MAGIC_DIO, 5)

// Input:  DIO_SET_INT.
// Output: <None>
#define DIINT_SET_TRIGEDGE             0x1
#define DIINT_SET_RISING_EDGE          0x2  
#define DIINT_SET_FALLING_EDGE         0x3  
#define DIINT_SET_GATECTRL             0x4
#define DICOS_SET_CHENBED              0x5
#define DIPM_SET_PORTVAL               0x6
#define DIPM_SET_CHENBED               0x7
typedef struct DIO_SET_INT {
   uint32 SetWhich;
   uint32 SrcStart;    // start DI INT source to configure
   uint32 SrcCount;    // DI INT source count to configure
   uint8  Buffer[0];   // variable length array of interrupt setting.
} DIO_SET_INT, *PDIO_SET_INT;

#define IOCTL_DIO_SET_INT              DAQCTL_WR(IOCTL_MAGIC_DIO, 6)

// Input:  DIO_EXEC_DISNAP.
// Output: <none>
#define DISNAP_CMD_START               0x0
#define DISNAP_CMD_STOP                0x1
typedef struct DIO_EXEC_DISNAP {
   uint32 Command;               // Start / stop the DI snap
   uint32 EventType;             // event type to trigger DI snap function
   uint32 PortStart;             // start DI port to scan when the event occurred.
   uint32 PortCount;             // ports count to scan when the event occurred.
} DIO_EXEC_DISNAP, *PDIO_EXEC_DISNAP;

#define IOCTL_DIO_EXEC_DISNAP          DAQCTL_WR(IOCTL_MAGIC_DIO, 7)

// Input:  uint32, 0 -- disable the function, 1 -- enable the function
// Output: <none>
#define DOFRZ_CMD_ENABLE               0x0
#define DOFRZ_CMD_DISABLE              0x1
#define DOFRZ_CMD_POLLSTATE            0x2
typedef struct DIO_EXEC_DOFRZ {
   uint32 Command;
   uint32 *Result;
} DIO_EXEC_DOFRZ, *PDIO_EXEC_DOFRZ;

#define IOCTL_DIO_EXEC_DOFRZ           DAQCTL_WR(IOCTL_MAGIC_DIO, 8)

// Input:  DIO_SET_POCFG
// Output:  <None>
#define DIOPO_SET_PORTDIR              0x0
#define DIOPO_SET_DOSTATE              0x1
typedef struct DIO_SET_POCFG {
   uint32 SetWhich;
   uint8  Buffer[0];
} DIO_SET_POCFG, *PDIO_SET_POCFG;

#define IOCTL_DIO_SET_POCFG            DAQCTL_WR(IOCTL_MAGIC_DIO, 9)

// Input:  DIO_EXEC_DOWTD.
// Output: <None>
#define DOWTD_CMD_SET_FEEDINTVL        0x1
#define DOWTD_CMD_SET_LOCKVALUE        0x2
#define DOWTD_CMD_START                0x3
#define DOWTD_CMD_STOP                 0x4
#define DOWTD_CMD_FEED                 0x5
typedef struct DIO_EXEC_DOWTD {
   uint32 Command;
   uint32 PortStart;      
   uint32 PortCount;      
   uint8  Buffer[0];      
} DIO_EXEC_DOWTD, *PDIO_EXEC_DOWTD;

#define IOCTL_DIO_EXEC_DOWTD           DAQCTL_WR(IOCTL_MAGIC_DIO, 10)

//******************************************************************************************
//                                                                                         *
// IOCTL for Counter/Timer operation                                                       *
//                                                                                         *
//******************************************************************************************
//
// Input:  CT_SET_CFG
// Output: <None>
typedef struct CT_SET_CFG {
   uint32 PropID;
   uint32 Start;
   uint32 Count;
   uint8  Value[0];
} CT_SET_CFG, *PCT_SET_CFG;

#define IOCTL_CT_SET_CFG               DAQCTL_WR(IOCTL_MAGIC_CT, 1)

// Input:  CT_START
// Output: <None>
typedef struct CT_START {
   uint32 Operation;
   uint32 Start;
   uint32 Count;
   uint8  Param[0];  
} CT_START, *PCT_START;

#define IOCTL_CT_START                 DAQCTL_WR(IOCTL_MAGIC_CT, 2)

// Input:  CT_READ
// Output: depending on device and the operation value.
typedef struct CT_READ {
   uint32 Operation; 
   uint32 Start;
   uint32 Count;
   void   *Data;
} CT_READ, *PCT_READ;

typedef struct CT_VALUE {
   uint32 CanRead;   
   uint32 Overflow;  
   uint32 Value;     
} CT_VALUE, *PCT_VALUE;

#define IOCTL_CT_READ                  DAQCTL_RD(IOCTL_MAGIC_CT, 3)

// Input:  CT_RESET
// Output: <NONE>
#define CT_RESET_HW                    0x0
#define CT_RESET_VALUE                 0x1  
typedef struct CT_RESET {
   uint32 Start;
   uint32 Count;
   uint32 Param;
} CT_RESET, *PCT_RESET;

#define IOCTL_CT_RESET                 DAQCTL_WR(IOCTL_MAGIC_CT, 4)

// Input:  CT_EXEC_SNAP.
// Output: <none>
#define CTSNAP_CMD_START               0x0
#define CTSNAP_CMD_STOP                0x1
typedef struct CT_EXEC_SNAP {
   uint32 Command;               // Start / stop  snap
   uint32 EventType;             // event type to trigger DI snap function
   uint32 CntrStart;             // start channel to scan when the event occurred.
   uint32 CntrCount;             // channel count to scan when the event occurred.
} CT_EXEC_SNAP, *PCT_EXEC_SNAP;

#define IOCTL_CT_EXEC_SNAP             DAQCTL_WR(IOCTL_MAGIC_CT, 5)

// Input:  CT_CCMP_CFG
// Output: <NONE>
#define CT_CCMP_SET_TABLE              0x1
#define CT_CCMP_SET_INTVL              0x2
#define CT_CCMP_CLEAR                  (-1)
typedef struct CT_CCMP_CFG {
   uint32 Command;
   uint32 Counter;
   union {
      struct {
         uint32 Start;
         int32  Step;
         uint32 Count;
      };
      struct {
         uint32 TblSize;
         uint32 TblData[0];
      };
   };
} CT_CCMP_CFG, *PCT_CCMP_CFG;

#define IOCTL_CT_CCMP_CFG              DAQCTL_WR(IOCTL_MAGIC_CT, 6)

#endif /* DAQNAVI_IOCTL_DEFINITION */
