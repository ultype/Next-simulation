// ############################################################################
// ****************************************************************************
//                 Copyright (c) 2011, Advantech Co. Ltd.
//      THIS IS AN UNPUBLISHED WORK CONTAINING CONFIDENTIAL AND PROPRIETARY
//         INFORMATION WHICH IS THE PROPERTY OF ADVANTECH AUTOMATION CORP.
//
//    ANY DISCLOSURE, USE, OR REPRODUCTION, WITHOUT WRITTEN AUTHORIZATION FROM
//               ADVANTECH AUTOMATION CORP., IS STRICTLY PROHIBITED.
// ****************************************************************************
// ############################################################################
//
// File:        dev.c
// Environment: Kernel Mode
// Description: miscellaneous functions.
//
// Revision History:
//   -- May 6, 2016   Created by Rocky.Ji
// ----------------------------------------------------------------------------

/************************************************************************
Function: daq_dev_load_default_setting
Description: load the default setting of the device
Return: <NONE>
************************************************************************/
void daq_dev_load_default_setting(daq_device_t *daq_dev)
{
   daq_kshared_t *shared = &daq_dev->kshared;
   int i;

   // AI 
   for (i = 0; i < AI_CH_CNT_MAX; ++i) {
      shared->ai_ch_sctype[i] = Differential;
      shared->ai_ch_gain[i]   = 0;            // +/- 10V
      shared->ai_ch_cpl[i]    = DCCoupling;
      shared->ai_ch_iepe[i]   = IEPENone;
   }

   // FAI
   shared->sai_param.conv_clk_src  = SigInternalClock;
   shared->sai_param.conv_clk_rate = 216000.0;      // default is using highest sample frequency
   shared->sai_param.samp_mode     = 2;             // default is using highest sample mode
   shared->sai_param.dds_tuning    = 0x2363b256;    // default is using highest DDS (216000 * 2748)  
   shared->sai_param.deci_selector = 0;   

   shared->fai_param.conv_clk_src  = SigInternalClock;
   shared->fai_param.conv_clk_rate = 216000.0;      // default is using highest sample frequency
   shared->fai_param.samp_mode     = 2;             // default is using highest sample mode
   shared->fai_param.dds_tuning    = 0x2363b256;    // default is using highest DDS (216000 * 2748)  
   shared->fai_param.deci_selector = 0;       

   shared->fai_param.phy_ch_start = 0;
   shared->fai_param.log_ch_count = 1; // default is single channel
   shared->fai_param.phy_ch_enabled = 0x1; // default is single channel

   shared->fai_param.xfer_mode    = DAQ_XFER_DMA;
   shared->fai_param.sect_length  = AI_DATA_DMA_SIZE / 2; // half FIFO
   shared->fai_param.rec_cycles   = 1;

   for (i = 0; i < AI_TRIG_COUNT; ++i) {
      shared->fai_param.trigger[i].edge     = RisingEdge;
      shared->fai_param.trigger[i].level    = 0;
      shared->fai_param.trigger[i].source   = SignalNone;   
      shared->fai_param.trigger[i].action   = DelayToStart; 
      shared->fai_param.trigger[i].hyst_idx = 0;
   }

   // DI
   for (i = 0; i < DI_INT_SRC_COUNT; ++i) {
      shared->diint_trig_edge[i] = RisingEdge;
   }
}

/************************************************************************
Function: daq_dev_find_iomem_idx
Description: look for the address bar for a physical address
Return: the bar index, or -1 if failed.
************************************************************************/
int daq_dev_find_iomem_idx(daq_device_t *daq_dev, uint64 phy_addr)
{
   daq_kshared_t *shared = &daq_dev->kshared;
   int i;
   for (i = 0; i < PCI_BAR_COUNT; ++i) {
      if (phy_addr >= shared->io_phy_base[i]
         && phy_addr <  shared->io_phy_base[i] + shared->io_length[i]) {
            return i;
      }
   }

   return -1;
}

/************************************************************************
Routine :    daq_dev_signal_event
Description: signal the specified event.
Parameters:
   daq_dev - pointer to daq_device_t object
   kdx - the index of the event to be signaled.
Return:  <None>
************************************************************************/
void daq_dev_signal_event(daq_device_t *daq_dev, uint32 kdx)
{
   daq_file_ctx_t *curr;
   unsigned long flags;

   x_dev_spin_lock(daq_dev, flags);
   x_list_for_each_entry(curr, &daq_dev->file_ctx_list, list_entry, daq_file_ctx_t) {
      if (curr->events[kdx] != NULL) {
         x_event_set(curr->events[kdx]);
      }
   }
   x_dev_spin_unlock(daq_dev, flags);
}

/************************************************************************
Routine : daq_dev_clear_event
Description: reset the specified event to non-signal state.
Parameters:
   daq_dev - device extension
   kdx - the index of the event to be reset.
Return:   <None>
************************************************************************/
void daq_dev_clear_event(daq_device_t *daq_dev, uint32 kdx)
{
   daq_file_ctx_t *curr;
   unsigned long flags;

   x_dev_spin_lock(daq_dev, flags);
   x_list_for_each_entry(curr, &daq_dev->file_ctx_list, list_entry, daq_file_ctx_t) {
      if (curr->events[kdx] != NULL) {
         x_event_reset(curr->events[kdx]);
      }
   }
   x_dev_spin_unlock(daq_dev, flags);
}

/************************************************************************
Routine : daq_dev_is_event_active
Description: whether the specified event is active or not.
Parameters:
   daq_dev - device extension
   kdx - the index of the event to be reset.
Return:   <None>
************************************************************************/
int daq_dev_is_event_active(daq_device_t *daq_dev, uint32 kdx)
{
   daq_file_ctx_t *curr;
   unsigned long flags;
   int active = 0;

   x_dev_spin_lock(daq_dev, flags);
   x_list_for_each_entry(curr, &daq_dev->file_ctx_list, list_entry, daq_file_ctx_t) {
      if (curr->events[kdx] != NULL) {
         active = 1;
         break;
      }
   }
   x_dev_spin_unlock(daq_dev, flags);

   return active;
}

/************************************************************************
Routine : daq_dev_dbg_reg_in / daq_dev_dbg_reg_out
Description: read/write the specified register of device.
Parameters:
   daq_dev - device extension
   kdx - the index of the event to be reset.
Return:   <None>
************************************************************************/
ErrorCode daq_dev_dbg_reg_in(daq_device_t *daq_dev, DBG_REG_IO *arg, uint8 *data)
{
   daq_kshared_t *shared = &daq_dev->kshared;
   int    bar;
   uint32 offset;

   // does the start address is valid(located in our device's IO space.)
   bar = daq_dev_find_iomem_idx(daq_dev, arg->Addr);
   if (bar == -1) {
      return ErrorParamOutOfRange;
   }

   // calculate the register offset
   offset = (uint32)(arg->Addr - shared->io_phy_base[bar]);
   if (arg->Length > shared->io_length[bar] - offset) {
      return ErrorParamOutOfRange;
   }

   // read ports using read byte / read word / read dword according with alignment rules.
   switch(arg->Length)
   {
   case 1: *(uint8 *)data = AdxMemInB(daq_dev->iomem_base[bar], offset); break;
   case 2: *(uint16*)data = AdxMemInW(daq_dev->iomem_base[bar], offset); break;
   case 4: *(uint32*)data = AdxMemInD(daq_dev->iomem_base[bar], offset); break;
   default: 
      return ErrorParamNotSpted; 
   }

   return Success;
}

ErrorCode daq_dev_dbg_reg_out(daq_device_t *daq_dev, DBG_REG_IO *arg)
{
   daq_kshared_t *shared = &daq_dev->kshared;
   int    bar;
   uint32 offset;

   // does the start address is valid(located in our device's IO space.)
   bar = daq_dev_find_iomem_idx(daq_dev, arg->Addr);
   if (bar == -1) {
      return ErrorParamOutOfRange;
   }

   // calculate the register offset
   offset = (uint32)(arg->Addr - shared->io_phy_base[bar]);
   if (arg->Length > shared->io_length[bar] - offset) {
      return ErrorParamOutOfRange;
   }

   // write ports using write byte / write word / write dword according with alignment rules.
   switch(arg->Length)
   {
   case 1: AdxMemOutB(daq_dev->iomem_base[bar], offset, arg->Value); break;
   case 2: AdxMemOutW(daq_dev->iomem_base[bar], offset, arg->Value); break;
   case 4: AdxMemOutD(daq_dev->iomem_base[bar], offset, arg->Value); break;
   default: 
      return ErrorParamNotSpted;
   }

   return Success;
}
