/*
 * ao.c
 *
 *  Created on: 2011-11-10
 *      Author: rocky
 */
#include "kdriver.h"

void daq_ao_initialize_hw(daq_device_t *daq_dev)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   int           i, ret;

   for (i = 0; i < AO_CHL_COUNT; ++i){
     ret = daq_usb_ao_configure_channel(daq_dev, i, 0, shared->AoChanGain[i]);
     if (ret < 0){
        break;
     }

     if (shared->InitOnLoad){
        daq_usb_ao_write_channel(daq_dev, i, 1, &shared->AoChanState[i]);
     }
   }
}

int daq_ioctl_ao_set_channel(daq_device_t *daq_dev, unsigned long arg)
{
   AO_SET_CHAN xbuf;
   __u32       gain[AO_CHL_COUNT];

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   if (unlikely((xbuf.SetWhich & AO_SET_CHVRG) == 0)){
      return 0;
   }

   if (unlikely(xbuf.ChanCount > AO_CHL_COUNT)){
      xbuf.ChanCount = AO_CHL_COUNT;
   }

   if (unlikely(copy_from_user(gain, (void *)xbuf.Gains, sizeof(__u32) * xbuf.ChanCount))){
      return -EFAULT;
   } else {
      int ret = 0;
      for ( ; xbuf.ChanCount; --xbuf.ChanCount) {
         ret = daq_usb_ao_configure_channel(daq_dev, xbuf.ChanStart, 0, gain[xbuf.ChanStart]);
         if (ret < 0) {
            break;
         }
         daq_dev->shared.AoChanGain[xbuf.ChanStart] = gain[xbuf.ChanStart];

         ++xbuf.ChanStart;
         xbuf.ChanStart &= AO_CHL_MASK;
      }
      return ret < 0 ? ret : 0;
   }
}

int daq_ioctl_ao_write_sample(daq_device_t *daq_dev, unsigned long arg)
{
   AO_WRITE_SAMPLES xbuf;
   __u16            sample[AO_CHL_COUNT];

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   xbuf.ChanStart &= AO_CHL_MASK;
   if (xbuf.ChanCount > AO_CHL_COUNT){
      xbuf.ChanCount = AO_CHL_COUNT;
   }

   if (unlikely(copy_from_user(sample, (void *)xbuf.Data, sizeof(__u16) * xbuf.ChanCount))){
      return -EFAULT;
   }

   if (daq_usb_ao_write_channel(daq_dev, xbuf.ChanStart, xbuf.ChanCount, sample) < 0){
      return -EIO;
   }

   return 0;
}
