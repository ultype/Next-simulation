/*
 * isr.c
 *
 *  Created on: July 7, 2012
 *      Author: rocky
 */
#include "kdriver.h"
#include "hw.h"

// -----------------------------------------------------------------------------
// Must hold the lock when call this function.
void daq_dio_tasklet_func(unsigned long arg)
{
   daq_device_t  *daq_dev = (daq_device_t *) arg;
   DEVICE_SHARED *shared  = &daq_dev->shared;
   __u32 int_source_index = shared->DiSnapIndex;

   
   if (shared->DiSnapParam[int_source_index].PortCount) {
      __u32 i;
      for ( i = 0; i < DIO_PORT_COUNT; ++i ) {
        shared->DiSnapState[int_source_index].State[i] = AdxIoInB(shared->IoBase, DR_DIO_PORTX(i));
      }
   }

   // signal the event if needed.
   if (!shared->IsEvtSignaled[KdxDiBegin + int_source_index]) {
      shared->IsEvtSignaled[KdxDiBegin + int_source_index] = 1;
      daq_device_signal_event(daq_dev, KdxDiBegin + int_source_index);
   }
}

irqreturn_t daq_irq_handler(int irq, void *dev_id)
{
   daq_device_t  *daq_dev = (daq_device_t *) dev_id;

   tasklet_schedule(&daq_dev->dio_tasklet);

   return IRQ_RETVAL(1);
}

