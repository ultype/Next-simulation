/*
 * isr.c
 *
 * Created on: October 7, 2012
 * Author: 
 */
#include "kdriver.h"
#include "hw.h"

// -----------------------------------------------------------------------------
// 
static __u8 * daq_di_snap_port(__u32 ioBase, __u8 buffer[DIO_PORT_COUNT])
{
   buffer[0] = AdxIoInB(ioBase, DR_DI_PORTX(0));
   buffer[1] = AdxIoInB(ioBase, DR_DI_PORTX(1));
   buffer[2] = AdxIoInB(ioBase, DR_DI_PORTX(2));
   buffer[3] = AdxIoInB(ioBase, DR_DI_PORTX(3));
   return buffer;
}

void daq_dio_tasklet_func(unsigned long arg)
{
   daq_device_t  *daq_dev = (daq_device_t *) arg;
   DEVICE_SHARED *shared  = &daq_dev->shared;
   unsigned long flags;
   __u32         i, int_state;
   __u8          *snapped = NULL;

   // Copy the interrupt state to local cache to avoid impose the interrupt handler.
   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   int_state = daq_dev->int_state;
   daq_dev->int_state = 0;
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

   // check DI interrupt state
   for (i = 0; int_state; int_state >>= 1, ++i) {
      if (int_state & 0x1) {
          if (shared->DiSnap[i].Count) {
             if (snapped) {
                memcpy(shared->DiSnap[i].State, snapped, DIO_PORT_COUNT);
             } else {
                snapped = daq_di_snap_port(shared->IoBase, shared->DiSnap[i].State);
             }
          }

          // signal the event if needed.
          if (!shared->IsEvtSignaled[i + KdxDiBegin]) {
             shared->IsEvtSignaled[i + KdxDiBegin] = 1;
             daq_device_signal_event(daq_dev, i + KdxDiBegin);
          }
      }
   }
}

irqreturn_t daq_irq_handler(int irq, void *dev_id)
{
   daq_device_t  *daq_dev  = (daq_device_t *) dev_id;
   __u32         int_state = AdxIoInB(daq_dev->shared.IoBase, DR_INT_STA) & DEV_INT_MASK;
   
   if (!int_state) {
      return IRQ_RETVAL(0);
   }

   spin_lock(&daq_dev->dev_lock);
   daq_dev->int_state |= int_state;
   spin_unlock(&daq_dev->dev_lock);
   
   tasklet_schedule(&daq_dev->int_tasklet);

   AdxIoOutB(daq_dev->shared.IoBase, DR_INT_CLR, int_state);
   return IRQ_RETVAL(1);
}

