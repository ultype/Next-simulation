/*
 * hw.h
 *
 *  Created on: 2011-10-19
 *      Author: rocky
 */

#ifndef _KERNEL_MODULE_HW_H_
#define _KERNEL_MODULE_HW_H_

// device register : AI Data
#define DR_AI_DATA        0x0
#define DR_AI_SWTRIG      0x0

typedef union _AI_CHL_CTL{
   __u8 Value;
   struct{
      __u8 Gain  : 5;
      __u8 Diff  : 1;
      __u8 unused: 2;
   };
}AI_CHL_CTL;
#define DR_AI_CHCTL       0x2

#define DR_AI_MUX         0x4

#define DEV_CTL_SW_TRIG   1

typedef union _DEV_CTL_STA{
   __u16 Value;
   struct{
      __u16 SwTrig    : 1;
      __u16 PcrTrig   : 1;
      __u16 unused1   : 2;
      __u16 IrqEn     : 1;
      __u16 IntHF     : 1;
      __u16 unused2   : 2;
      __u16 FifoEmpty : 1;
      __u16 FifoHalf  : 1;
      __u16 FifoFull  : 1;
      __u16 IntFlag   : 1;
      __u16 unused3   : 3;
      __u16 CaliMode  : 1;
   };
}DEV_CTL_STA;

#define DR_CONTROL        0x6
#define DR_STATUS         0x6

#define DR_CLR_INTR       0x8
#define DR_CLR_FIFO       0x9

#define DR_BID            0x14

#define DR_CNTR0       0x18
#define DR_CNTR1       0x1A
#define DR_CNTR2       0x1C
#define DR_CNTR_CTL    0x1E

#endif /* _KERNEL_MODULE_HW_H_ */
