/*
 * ai.c
 *
 *  Created on: 2011-11-10
 *      Author: rocky
 */

#include "kdriver.h"
#include "hw.h"

static
int daq_ai_configure_channel(DEVICE_SHARED *shared, __u32 chan, __u8 sctype, __u8 gain)
{
   shared->AiChanType[chan] = sctype;
   shared->AiChanGain[chan] = gain;

   if (!(chan & 0x1) || sctype != Differential) {
       AI_CHL_CTL ctl;
       ctl.Gain = gain;
       ctl.Diff = sctype;

       AdxIoOutW(shared->IoBase, DR_AI_MUX,   (chan << 8 | chan));
       AdxIoOutB(shared->IoBase, DR_AI_CHCTL, ctl.Value);
   }

   return 0;
}

static
__u32 daq_ai_read_channel(DEVICE_SHARED *shared, unsigned timeout)
{
   DEV_CTL_STA   sta;
   unsigned long absolute_timeout;

   // Trigger a A/D conversion.
   AdxIoOutW(shared->IoBase, DR_AI_SWTRIG, 1);

   // use time-out detecting.
   absolute_timeout = jiffies + msecs_to_jiffies(timeout);

   // waiting for data ready
   do {
      sta.Value = AdxIoInW(shared->IoBase, DR_STATUS);
      if (!sta.FifoEmpty){
         break;
      }
      if (time_is_before_jiffies(absolute_timeout)){
         daq_trace((KERN_ERR "read ai time-out."));
         return -1;
      }
   }while (1);

   return AdxIoInW(shared->IoBase, DR_AI_DATA);
}

static
void daq_fai_setup_pacer(DEVICE_SHARED *shared)
{
   I825X_CTL ctl;

   // disable  pacer
   AdxIoOutW(shared->IoBase, DR_CONTROL, 0);

   // Select counter 1; Read/write LSB first, then MSB; operation mode 2(rate gen); binary counting.
   ctl.SC   = 1;
   ctl.RW   = 3;
   ctl.Mode = 2;
   ctl.Bcd  = 0;
   AdxIoOutB(shared->IoBase, DR_CNTR_CTL, ctl.Value);
   AdxIoOutB(shared->IoBase, DR_CNTR1,    shared->FaiParam.PacerDivider);
   AdxIoOutB(shared->IoBase, DR_CNTR1,    shared->FaiParam.PacerDivider >> 8);

   // Select counter 2; Read/write LSB first, then MSB; operation mode 2(rate gen); binary counting.
   ctl.SC = 2;
   AdxIoOutB(shared->IoBase, DR_CNTR_CTL,  ctl.Value);
   AdxIoOutB(shared->IoBase, DR_CNTR2,     shared->FaiParam.PacerDivider >> 16);
   AdxIoOutB(shared->IoBase, DR_CNTR2,     shared->FaiParam.PacerDivider >> 24);
}

static
int daq_fai_start_hardware(daq_device_t *daq_dev)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   FAI_CONFIG  *faiParam = &shared->FaiParam;
   FAI_STATUS *faiStatus = &shared->FaiStatus;
   DEV_CTL_STA   dev_csr = {0};

   // Disable device interrupt
   AdxIoOutW(shared->IoBase, DR_CONTROL, 0);

   // Clear device's AD interrupt and FIFO
   AdxIoOutW(shared->IoBase, DR_CLR_INTR, 0);

   // Pacer trigger
   daq_fai_setup_pacer(shared);

   // Set channel scan range
   {
      unsigned ch_range = daq_ai_calc_phy_chan_range(shared->AiChanType, AI_CHL_COUNT,
                           faiParam->PhyChanStart, faiParam->LogChanCount);
      AdxIoOutW(shared->IoBase, DR_AI_MUX, ch_range);
   }

   if (faiParam->ConvClkSource == SigExtDigClock) {
      dev_csr.ExtTrig = 1;
      dev_csr.ExtTrigGate = 1;
   } else {
      dev_csr.PcrTrig = 1;
   }

   if (faiParam->XferMode == DAQ_XFER_INT) {
      // Enable 9056 PCI Interrupt & Local (device) Interrupt
      PLX_INT_CSR intcsr = {0};
      intcsr.PciIntEn      = 1;
      intcsr.LocIntInputEn = 1;
      AdxIoOutD(shared->BrBase, BR_PLX_INTCSR, intcsr.Value);

      dev_csr.IrqEn = 1;
      if (faiParam->SectionSize >= (AI_FIFO_SIZE / 2)) {
         dev_csr.IntHF = 1;
      }
   } else {
      if (faiStatus->AcqMode == DAQ_ACQ_INFINITE) {
         daq_dev->fai_sgl.end->DescPtr.LastElement = 0;
      } else {
         daq_dev->fai_sgl.end->DescPtr.LastElement = 1;
      }

      // Local Address Space 0 Local Base Address
      // Enable Local address space 0, base address 0
      {
         PLX_LAS0_BA las0ba = {0};
         las0ba.Spc0En  = 1;
         AdxIoOutW(shared->BrBase, BR_PLX_LAS0BA, las0ba.Value);
      }

      // Mode/DMA Arbitration
      // Local Bus BREQ Enable, Local Bus Direct Slave Release Bus Mode
      {
         PLX_MOD_DMA_ARB marbr  = {0};
         marbr.LocBusBREQEn = 1;
         marbr.LocBusDSRBM  = 1;
         AdxIoOutD(shared->BrBase, BR_PLX_MODDMAARB, marbr.Value);
      }

      // Local Address Space 0/Expansion ROM Bus Region Descriptor
      // 16bit local bus width, 3 internal wait state
      {
         PLX_LAS0_BUS_RGN_DPR lbrd = {0};
         lbrd.MemSpc0LBWidth   = 1;
         lbrd.MemSpc0WaitState = 3;
         AdxIoOutW(shared->BrBase, BR_PLX_LAS0BUSRGNDPR, lbrd.Value);
      }

      // DMA Threshold
      // zero for all field.
      AdxIoOutW(shared->BrBase, BR_PLX_DMATHR, 0);

      // DMA DAC: zero it
      AdxIoOutD(shared->BrBase, BR_PLX_DMADAC0, 0);

      // Interrupt Control / Status register
      // PCI Interrupt Enable, Local DMA Channel 0 Interrupt Enable.
      {
         PLX_INT_CSR intcsr = {0};
         intcsr.PciIntEn     = 1;
         intcsr.LocDMA0IntEn = 1;
         AdxIoOutD(shared->BrBase, BR_PLX_INTCSR, intcsr.Value);
      }

      // DMA Channel 0 Mode
      // Local bus width : 16Bit, Internal wait state: 3
      // Local Burst Enable, Scatter/Gather Mode, Done Interrupt Enable,
      // Local Addressing Mode 1 ( holds the Local Address bus constant),
      // Demand Mode, DMA Channel 0 Interrupt Select.
      {
         PLX_DMA_MODE dmamode = {0};
         dmamode.LocBusWidth   = 1;
         dmamode.IntlWaitState = 3;
         dmamode.LocBurstEn    = 1;
         dmamode.SGModeEn      = 1;
         dmamode.LocAddrMode   = 1;
         dmamode.DemandModeEn  = 1;
         dmamode.DmaIntSelect  = 1;
         dmamode.DacChainLoad  = PLX_DAC_CHAIN_LOAD;
         AdxIoOutD(shared->BrBase, BR_PLX_DMAMODE0, dmamode.Value);
      }

      // DMA Channel 0 Descriptor Pointer
      {
         PLX_DMA_DPR dmadpr = {0};
         dmadpr.Value       = daq_dev->fai_sgl.startPA;
         dmadpr.NextDPRLoc  = 1;
         AdxIoOutD(shared->BrBase, BR_PLX_DMADPR0, dmadpr.Value);
      }

      // DMA Channel 0 Command/Status
      // Enable the DMA channel, clear interrupt.
      {
         PLX_DMA_CSR dmacmd  = {0};
         dmacmd.Enable   = 1;
         dmacmd.ClearInt = 1;
         dmacmd.Start    = 1;
         AdxIoOutB(shared->BrBase, BR_PLX_DMACSR0, dmacmd.Value);
      }
   }

   // start AI acquirement
   AdxIoOutW(shared->IoBase, DR_CONTROL, dev_csr.Value);

   // add the task to wait_queue for sync read
   if (faiStatus->AcqMode == DAQ_ACQ_FINITE_SYNC){
      return wait_event_interruptible(daq_dev->fai_queue, faiStatus->FnState != DAQ_FN_RUNNING);
   }

   return 0;
}

//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------
void daq_ai_initialize_hw(daq_device_t *daq_dev)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   int i;

   for (i = 0; i < AI_CHL_COUNT; ++i) {
      daq_ai_configure_channel(shared, i, shared->AiChanType[i], shared->AiChanGain[i]);
   }
   shared->AiLogChanCount = daq_ai_calc_log_chan_count(shared->AiChanType, AI_CHL_COUNT);
}

void daq_fai_stop_acquisition(daq_device_t *daq_dev, int cleanup)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   FAI_CONFIG  *faiParam = &shared->FaiParam;
   FAI_STATUS *faiStatus = &shared->FaiStatus;

   unsigned long flags;

   spin_lock_irqsave(&daq_dev->fai_lock, flags);
   if (faiStatus->FnState != DAQ_FN_RUNNING){
      spin_unlock_irqrestore(&daq_dev->fai_lock, flags);
   } else {
      faiStatus->FnState = DAQ_FN_STOPPED;
      spin_unlock_irqrestore(&daq_dev->fai_lock, flags);

      AdxIoOutW(shared->IoBase, DR_CONTROL,  0);
      AdxIoOutW(shared->IoBase, DR_CLR_INTR, 0);

      if (faiParam->XferMode == DAQ_XFER_DMA) {
         PLX_DMA_CSR dmacsr;
         dmacsr.Value  = AdxIoInB(shared->BrBase, BR_PLX_DMACSR0);
         if (!dmacsr.Done) {
            do {
               dmacsr.Abort = 1;
               AdxIoOutB(shared->BrBase, BR_PLX_DMACSR0, dmacsr.Value);
               dmacsr.Value = AdxIoInB(shared->BrBase, BR_PLX_DMACSR0);
            } while (!dmacsr.Done);

            daq_plx9054_flush_fifo(shared->BrBase, 0);
         }
      }

      daq_device_signal_event(daq_dev, KdxAiStopped);
      wake_up_interruptible(&daq_dev->fai_queue);
   }

   if (cleanup) {
      daq_umem_unmap(&daq_dev->fai_buffer);
      daq_plx905x_free_sgl_mem(&daq_dev->fai_sgl);

      spin_lock_irqsave(&daq_dev->fai_lock, flags);
      faiStatus->FnState = DAQ_FN_IDLE;
      spin_unlock_irqrestore(&daq_dev->fai_lock, flags);
   }
}


int daq_ioctl_ai_set_channel(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   AI_SET_CHAN   xbuf;
   AI_CHAN_CFG   cfg[AI_CHL_COUNT];
   __u32         i, ch;

   if (unlikely(shared->FaiStatus.FnState == DAQ_FN_RUNNING)){
      return -EBUSY;
   }

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   if (unlikely(xbuf.PhyChanCount > AI_CHL_COUNT)){
      xbuf.PhyChanCount = AI_CHL_COUNT;
   }
   if (unlikely(copy_from_user(cfg, (void *)xbuf.ChanCfg, sizeof(AI_CHAN_CFG) * xbuf.PhyChanCount))){
      return -EFAULT;
   }

   for (i = 0; i < xbuf.PhyChanCount; ++i)
   {
      ch = (xbuf.PhyChanStart + i) & AI_CHL_MASK;
      daq_ai_configure_channel(shared, ch, cfg[i].SCType, cfg[i].Gain);
   }

   shared->AiLogChanCount = daq_ai_calc_log_chan_count(shared->AiChanType, AI_CHL_COUNT);

   return 0;
}

int daq_ioctl_ai_read_sample(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED   *shared = &daq_dev->shared;
   AI_READ_SAMPLES xbuf;
   __u16           sample[AI_CHL_COUNT];
   __u16           *data_ptr;
   __u32           ch_range, result;

   if (unlikely(daq_dev->shared.FaiStatus.FnState == DAQ_FN_RUNNING)){
      return -EBUSY;
   }

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   xbuf.PhyChanStart &= AI_CHL_MASK;
   xbuf.LogChanCount =  x_min(xbuf.LogChanCount, shared->AiLogChanCount);
   ch_range = daq_ai_calc_phy_chan_range(shared->AiChanType, AI_CHL_COUNT, xbuf.PhyChanStart, xbuf.LogChanCount);

   // configure hardware
   AdxIoOutW(shared->IoBase, DR_AI_MUX,   ch_range);
   AdxIoOutW(shared->IoBase, DR_CLR_INTR, 0);
   AdxIoOutW(shared->IoBase, DR_CONTROL,  DEV_CTL_SW_TRIG);

   // Read samples
   for(data_ptr = sample; data_ptr < sample + xbuf.LogChanCount; ++data_ptr){
      udelay(SAI_DELAY_TIME);
      result = daq_ai_read_channel(shared, SAI_TIMEOUT_VAL);
      if (result == -1){
         return -EIO;
      }
      *data_ptr = (__u16)result;
   }

   if (unlikely(copy_to_user((void *)xbuf.Data, sample, xbuf.LogChanCount * sizeof(__u16)))) {
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_fai_set_param(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   FAI_CONFIG    xbuf;
   unsigned long flags;
   int           ret = 0;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   spin_lock_irqsave(&daq_dev->fai_lock, flags);
   if (unlikely(shared->FaiStatus.FnState != DAQ_FN_IDLE)){
      ret = -EBUSY;
   } else {
      shared->FaiParam              = xbuf;
      shared->FaiParam.PhyChanStart = xbuf.PhyChanStart & AI_CHL_MASK;
      shared->FaiParam.LogChanCount = x_min(xbuf.LogChanCount, shared->AiLogChanCount);
   }
   spin_unlock_irqrestore(&daq_dev->fai_lock, flags);

   if (likely(!ret)){
      daq_device_signal_event(daq_dev, KdxDevPropChged);
   }

   return ret;
}

int daq_ioctl_fai_set_buffer(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   FAI_CONFIG  *faiParam = &shared->FaiParam;
   FAI_STATUS *faiStatus = &shared->FaiStatus;

   unsigned long flags;
   unsigned      sgl_len, data_len, sect_len;
   int           ret = 0;

   if (unlikely(!faiParam->SampleCount)) {
      return -EINVAL;
   }

   spin_lock_irqsave(&daq_dev->fai_lock, flags);
   if (unlikely(faiStatus->FnState != DAQ_FN_IDLE)){
      ret = -EBUSY;
   } else {
      faiStatus->FnState   = DAQ_FN_READY;
      faiStatus->BufLength = faiParam->SampleCount;
   }
   spin_unlock_irqrestore(&daq_dev->fai_lock, flags);

   do {
      if (unlikely(ret)){
         break;
      }

      data_len = faiParam->SampleCount * AI_DATA_SIZE;
      sect_len = faiParam->SectionSize * AI_DATA_SIZE;
      if (shared->FaiParam.XferMode == DAQ_XFER_INT){
         ret = daq_umem_map(arg, data_len, 1, &daq_dev->fai_buffer);
      } else {
         sgl_len = daq_plx905x_calc_sgl_length(data_len, sect_len);
         ret = daq_plx905x_alloc_sgl_mem(sgl_len, &daq_dev->fai_sgl);
         if (unlikely(ret)){
            break;
         }

         ret = daq_umem_get_pages(arg, data_len, 1, &daq_dev->fai_buffer);
         if (unlikely(ret)){
            break;
         }

         ret = daq_plx905x_build_sgl(&daq_dev->fai_buffer,
               data_len, sect_len, DR_AI_DATA, 1, &daq_dev->fai_sgl);
         if (unlikely(ret)){
            break;
         }
      }
   } while (0);

   if (ret){
      daq_umem_unmap(&daq_dev->fai_buffer);
      daq_plx905x_free_sgl_mem(&daq_dev->fai_sgl);
      faiStatus->FnState = DAQ_FN_IDLE;
   }

   return ret;
}

int daq_ioctl_fai_start(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   unsigned long flags;
   int           ret = 0;

   spin_lock_irqsave(&daq_dev->fai_lock, flags);
   do {
      if (shared->FaiStatus.FnState == DAQ_FN_IDLE){
         ret = -EINVAL;
         break;
      }

      if (shared->FaiStatus.FnState == DAQ_FN_RUNNING){
         ret = -EBUSY;
         break;
      }

      memset(shared->IsEvtSignaled, 0, sizeof(shared->IsEvtSignaled));
      memset(&shared->FaiStatus, 0, sizeof(FAI_STATUS));
      shared->FaiStatus.FnState   = DAQ_FN_RUNNING;
      shared->FaiStatus.AcqMode   = (__u32)arg;
      shared->FaiStatus.BufLength = shared->FaiParam.SampleCount;
   } while (0);
   spin_unlock_irqrestore(&daq_dev->fai_lock, flags);

   if (ret){
      return ret;
   }

   daq_device_clear_event(daq_dev, KdxAiDataReady);
   daq_device_clear_event(daq_dev, KdxAiOverrun);
   daq_device_clear_event(daq_dev, KdxAiStopped);
   daq_device_clear_event(daq_dev, KdxAiCacheOverflow);

   ret = daq_fai_start_hardware(daq_dev);

   return ret;
}

int daq_ioctl_fai_stop(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;

   if (shared->FaiStatus.FnState == DAQ_FN_IDLE){
      return 0;
   }

   daq_fai_stop_acquisition(daq_dev, arg & FAI_STOP_FREE_RES);

   return 0;
}

