/*
 * ao.c
 *
 *  Created on: 2011-11-10
 *      Author: rocky
 */
#include "kdriver.h"
#include "hw.h"

static inline
unsigned daq_ao_build_chan_map(unsigned start, unsigned count)
{
   #if AO_CHL_COUNT > 32
   #error AO channel count exceeds the limitation of the algorithm! Please modify the algorithm at first.
   #endif

   #define BUILD_CH_MAP(start, count)   (((1 << (count)) - 1) << (start))

   if (start + count <= AO_CHL_COUNT) {
      return BUILD_CH_MAP(start, count);
   } else {
      return BUILD_CH_MAP(start, AO_CHL_COUNT - start) | BUILD_CH_MAP(0, start + count - AO_CHL_COUNT);
   }
}

static inline
int daq_ao_chan_available(DEVICE_SHARED *shared, unsigned start, unsigned count)
{
   unsigned fao_ch, sao_ch;
   if (shared->FaoStatus.FnState != DAQ_FN_RUNNING) {
      return 1;
   }
   fao_ch = daq_ao_build_chan_map(shared->FaoParam.ChanStart, shared->FaoParam.ChanCount);
   sao_ch = daq_ao_build_chan_map(start, count);
   return (fao_ch & sao_ch) == 0;
}

static inline
void  daq_ao_fill_chan_csr(unsigned chan, unsigned gain, AO_CHL_CSR *csr)
{
   csr->CHx_Gain &= ~(0x3 << (chan * 2));

   if (gain == V_ExternalRefBipolar || gain == V_ExternalRefUnipolar) {
      csr->CHx_VREF  |= 1 << chan;
      if (gain == V_ExternalRefBipolar) {
         csr->CHx_Gain |= 0x2 << (chan * 2);
      }
   } else {
      csr->CHx_VREF &= ~(0x1 << chan);

      switch (gain)
      {
      case V_Neg10To10: csr->CHx_Gain |= 0x3 << (chan * 2); break;
      case V_Neg5To5:   csr->CHx_Gain |= 0x2 << (chan * 2); break;
      case V_0To10:     csr->CHx_Gain |= 0x1 << (chan * 2); break;
      default:          break; // 00b, uni-polar, 5V Reference Voltage for V_0To5, mA_0To20, mA_4To20
      }
   }
}

static
void daq_fao_setup_pacer(DEVICE_SHARED *shared)
{
   I825X_CTL ctl_word;

   // Select counter 1; Read/write LSB first, then MSB; operation mode 2(rate gen); binary counting.
   ctl_word.SC   = 1;
   ctl_word.RW   = 3;
   ctl_word.Mode = 3;
   ctl_word.Bcd  = 0;
   AdxIoOutB(shared->IoBase, DR_CNTR_CTL, ctl_word.Value);
   AdxIoOutB(shared->IoBase, DR_CNTR1,    shared->FaoParam.PacerDivider);
   AdxIoOutB(shared->IoBase, DR_CNTR1,    shared->FaoParam.PacerDivider >> 8);

   // Select counter 2; Read/write LSB first, then MSB; operation mode 2(rate gen); binary counting.
   ctl_word.SC = 2;
   AdxIoOutB(shared->IoBase, DR_CNTR_CTL,  ctl_word.Value);
   AdxIoOutB(shared->IoBase, DR_CNTR2,     shared->FaoParam.PacerDivider >> 16);
   AdxIoOutB(shared->IoBase, DR_CNTR2,     shared->FaoParam.PacerDivider >> 24);
}

static
int daq_fao_start_hardware(daq_device_t *daq_dev)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   FAO_CONFIG  *faoParam = &shared->FaoParam;
   FAO_STATUS *faoStatus = &shared->FaoStatus;

   // Disable device interrupt
   AdxIoOutD(shared->BrBase, BR_PLX_INTCSR,  0);

   // Clear FIFO
   AdxIoOutW(shared->IoBase, DR_CLR_FIFO, 0x0000);

   // ----- pacer setting -----------------------------------------------
   {
      DEV_CTL_STA csr;
      csr.Value = AdxIoInW(shared->IoBase, DR_CONTROL);
      if (faoParam->ConvClkSource == SigExtDigClock) {
         csr.FifoClk = 3;
      } else {
         switch (faoParam->PacerDivider)
         {
         case 1: csr.FifoClk = 2;  break; // 10b -- 10MHz
         case 2: csr.FifoClk = 1;  break; // 01b -- 5MHz
         default:
            csr.FifoClk = 0;              // 00b -- clock from counter, up to 2.5MHz limitation.
            daq_fao_setup_pacer(shared);
            break;
         }
      }

      AdxIoOutW(shared->IoBase, DR_CONTROL, csr.Value);
   }

   // Set the output mode of channel: from FIFO
   {
      int i;
      AO_CHL_CSR ch_csr;
      ch_csr.Value = AdxIoInW(shared->IoBase, DR_AO_CHCSR);
      for (i = 0; i < faoParam->ChanCount; ++i) {
         ch_csr.CHx_Mode |= 0x1 << ((faoParam->ChanStart + i) & AO_CHL_MASK);
      }
      AdxIoOutW(shared->IoBase, DR_AO_CHCSR, ch_csr.Value);
   }

   // PLX9056 register setup ---------------------------------------
   if (faoStatus->AcqMode == DAQ_ACQ_INFINITE) {
      daq_dev->fao_sgl.end->DescPtr.LastElement = 0;
   } else {
      daq_dev->fao_sgl.end->DescPtr.LastElement = 1;
   }

   //
   // Local Address Space 0 Local Base Address
   // Enable Local address space 0, base address 0
   {
      PLX_LAS0_BA las0ba = {0};
      las0ba.Spc0En  = 1;
      AdxIoOutW(shared->BrBase, BR_PLX_LAS0BA, las0ba.Value);
   }

   // Mode/DMA Arbitration
   // Local Bus BREQ Enable, Local Bus Direct Slave Release Bus Mode
   {
      PLX_MOD_DMA_ARB marbr  = {0};
      marbr.LocBusBREQEn = 1;
      marbr.LocBusDSRBM  = 1;
      AdxIoOutD(shared->BrBase, BR_PLX_MODDMAARB, marbr.Value);
   }

   // Interrupt Control / Status register
   // PCI Interrupt Enable, Local DMA Channel 0 Interrupt Enable.
   {
      PLX_INT_CSR intcsr = {0};
      intcsr.LocParityErr = 1;
      intcsr.PciIntEn     = 1;
      intcsr.LocDMA0IntEn = 1;
      AdxIoOutD(shared->BrBase, BR_PLX_INTCSR, intcsr.Value);
   }

   // Local Address Space 0/Expansion ROM Bus Region Descriptor
   // 16bit local bus width, 3 internal wait state
   {
      PLX_LAS0_BUS_RGN_DPR lbrd = {0};
      lbrd.MemSpc0LBWidth   = 1;
      lbrd.MemSpc0WaitState = 3;
      AdxIoOutW(shared->BrBase, BR_PLX_LAS0BUSRGNDPR, lbrd.Value);
   }

   // DMA Threshold
   // zero for all field.
   AdxIoOutW(shared->BrBase, BR_PLX_DMATHR, 0);

   // DMA DAC: zero it
   AdxIoOutD(shared->BrBase, BR_PLX_DMADAC0, 0);

   // DMA Channel 0 Mode
   // Local bus width : 16Bit, Internal wait state: 3
   // Local Burst Enable, Scatter/Gather Mode, Done Interrupt Enable,
   // Local Addressing Mode 1 (holds the Local Address bus constant),
   // Demand Mode, DMA Channel 0 Interrupt Select.
   {
      PLX_DMA_MODE dmamode = {0};
      dmamode.LocBusWidth   = 1;
      dmamode.IntlWaitState = 2;
      dmamode.LocBurstEn    = 1;
      dmamode.SGModeEn      = 1;
      dmamode.LocAddrMode   = 1;
      dmamode.DemandModeEn  = 1;
      dmamode.DmaEOTEn      = 1;
      dmamode.DmaIntSelect  = 1;
      dmamode.DacChainLoad  = PLX_DAC_CHAIN_LOAD;
      AdxIoOutD(shared->BrBase, BR_PLX_DMAMODE0, dmamode.Value);
   }

   // DMA Channel 0 Descriptor Pointer
   {
      PLX_DMA_DPR dmadpr = {0};
      dmadpr.Value       = daq_dev->fao_sgl.startPA;
      dmadpr.NextDPRLoc  = 1;
      AdxIoOutD(shared->BrBase, BR_PLX_DMADPR0, dmadpr.Value);
   }

   // DMA Channel 0 Command/Status
   // Enable the DMA channel, clear interrupt.
   {
      PLX_DMA_CSR dmacmd  = {0};
      dmacmd.Enable   = 1;
      dmacmd.ClearInt = 1;
      dmacmd.Start    = 1;
      AdxIoOutB(shared->BrBase, BR_PLX_DMACSR0, dmacmd.Value);
   }

   // add the task to wait_queue for sync read
   if (faoStatus->AcqMode == DAQ_ACQ_FINITE_SYNC){
      return wait_event_interruptible(daq_dev->fao_queue, faoStatus->FnState != DAQ_FN_RUNNING);
   }

   return 0;
}

//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------
void daq_ao_initialize_hw(daq_device_t *daq_dev)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   AO_CHL_CSR    csr     = {0};
   int           i;

   for (i = 0; i < AO_CHL_COUNT; ++i) {
      daq_ao_fill_chan_csr(i, shared->AoChanGain[i], &csr);
   }
   AdxIoOutW(shared->IoBase, DR_AO_CHCSR, csr.Value);

   // enable synchronized output
   AdxIoOutW(shared->IoBase, DR_AO_SYNC_CTL, 0x1);

   // set channel init state
   if (shared->InitOnLoad) {
      for (i = 0; i < AO_CHL_COUNT; ++i) {
         AdxIoOutW(shared->IoBase, DR_AO_DATA_BASE + i * AO_DATA_SIZE, shared->AoChanState[i] & AO_DATA_MASK);
      }

      // strobe the synchronized output
      AdxIoOutW(shared->IoBase, DR_AO_SYNC_STROBE, 0);
   }
}

void daq_fao_stop_acquisition(daq_device_t *daq_dev, int cleanup)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   FAO_STATUS *faoStatus = &shared->FaoStatus;

   unsigned long flags;

   spin_lock_irqsave(&daq_dev->fao_lock, flags);
   if (faoStatus->FnState != DAQ_FN_RUNNING){
      spin_unlock_irqrestore(&daq_dev->fao_lock, flags);
   } else {
      faoStatus->FnState = DAQ_FN_STOPPED;
      spin_unlock_irqrestore(&daq_dev->fao_lock, flags);

      AdxIoOutD(shared->BrBase, BR_PLX_INTCSR,  0);

      // Stop DMA transfer
      {
         PLX_DMA_CSR dma_csr;

         dma_csr.Value  = AdxIoInB(shared->BrBase, BR_PLX_DMACSR0);
         dma_csr.Enable = 0;
         AdxIoOutB(shared->BrBase, BR_PLX_DMACSR0, dma_csr.Value);
         if (!dma_csr.Done) {
            do {
             dma_csr.Abort = 1;
             AdxIoOutB(shared->BrBase, BR_PLX_DMACSR0, dma_csr.Value);
             dma_csr.Value = AdxIoInB(shared->BrBase, BR_PLX_DMACSR0);
            } while (!dma_csr.Done);

            AdxIoOutW(shared->IoBase, DR_CLR_FIFO, 0);
            daq_plx9054_flush_fifo(shared->BrBase, 0);
            AdxIoOutW(shared->IoBase, DR_CLR_FIFO, 0);
         }
      }
      shared->FaoStatus.WritePos = 0;

      {
         AO_CHL_CSR ch_csr;

         ch_csr.Value    = AdxIoInW(shared->IoBase, DR_AO_CHCSR);
         ch_csr.CHx_Mode = 0;
         AdxIoOutW(shared->IoBase, DR_AO_CHCSR, ch_csr.Value);
      }

      if (!shared->IsEvtSignaled[KdxAoTransStopped]) {
         shared->IsEvtSignaled[KdxAoTransStopped] = 1;
         daq_device_signal_event(daq_dev, KdxAoTransStopped);
      }

      daq_device_signal_event(daq_dev, KdxAoStopped);
      wake_up_interruptible(&daq_dev->fao_queue);
   }

   if (cleanup) {
      daq_umem_free(&daq_dev->fao_buffer);
      daq_plx905x_free_sgl_mem(&daq_dev->fao_sgl);

      spin_lock_irqsave(&daq_dev->fao_lock, flags);
      faoStatus->FnState = DAQ_FN_IDLE;
      spin_unlock_irqrestore(&daq_dev->fao_lock, flags);
   }
}

void daq_fao_fifo_check_work_func(struct work_struct *work)
{
   daq_device_t *daq_dev = container_of(delayed_work_ptr(work), daq_device_t, fao_fifo_chk_work);
   FIFO_STATUS  fifoStatus;

   fifoStatus.Value = AdxIoInW(daq_dev->shared.IoBase, DR_FIFO_STATUS);
   if (!fifoStatus.NotEmpty) {
      daq_fao_stop_acquisition(daq_dev, 0);
   }

   if (daq_dev->shared.FaoStatus.FnState == DAQ_FN_RUNNING){
      schedule_delayed_work(delayed_work_ptr(work), 1 /*jiffy*/);
   }
}

int daq_ioctl_ao_set_channel(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   AO_SET_CHAN   xbuf;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   if (xbuf.SetWhich & AO_SET_EXTREFUNI) {
      memcpy(&shared->AoExtRefUnipolar, &xbuf.ExtRefUnipolar, sizeof(shared->AoExtRefUnipolar));
   }
   if (xbuf.SetWhich & AO_SET_EXTREFBI) {
      memcpy(&shared->AoExtRefBipolar, &xbuf.ExtRefBipolar, sizeof(shared->AoExtRefBipolar));
   }

   if (xbuf.SetWhich & AO_SET_CHVRG){
      AO_CHL_CSR csr;
      __u32      i, ch, gains[AO_CHL_COUNT];

      if (unlikely(shared->FaoStatus.FnState == DAQ_FN_RUNNING)){
         return -EBUSY;
      }

      if (unlikely(xbuf.ChanCount > AO_CHL_COUNT)){
         xbuf.ChanCount = AO_CHL_COUNT;
      }
      if (unlikely(copy_from_user(gains, (void *)xbuf.Gains, xbuf.ChanCount * sizeof(__u32)))){
         return -EFAULT;
      }

      csr.Value = AdxIoInW(shared->IoBase, DR_AO_CHCSR);
      for (i = 0; i < xbuf.ChanCount; ++i) {
         ch = (xbuf.ChanStart + i) & AO_CHL_MASK;
         shared->AoChanGain[ch] = gains[i];
         daq_ao_fill_chan_csr(ch, gains[i], &csr);
      }

      // Set AO channel configuration
      AdxIoOutW(shared->IoBase, DR_AO_CHCSR, csr.Value);
   }

   return 0;
}

int daq_ioctl_ao_write_sample(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED    *shared = &daq_dev->shared;
   AO_WRITE_SAMPLES xbuf;
   __u16            data[AO_CHL_COUNT];
   __u32            i, ch;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   if (unlikely(xbuf.ChanStart >= AO_CHL_COUNT || xbuf.ChanCount > AO_CHL_COUNT)){
      return -EINVAL;
   }

   if (unlikely(!daq_ao_chan_available(shared, xbuf.ChanStart, xbuf.ChanCount))){
      return -EBUSY;
   }

   if (unlikely(copy_from_user(data, (void *)xbuf.Data, xbuf.ChanCount * sizeof(__u16)))){
      return -EFAULT;
   }

   // Write samples
   for(i = 0; i < xbuf.ChanCount; ++i)
   {
      ch = (xbuf.ChanStart + i) & AO_CHL_MASK;
      AdxIoOutW(shared->IoBase, DR_AO_DATA_BASE + ch * AO_DATA_SIZE, data[i]);
   }

   // strobe the synchronized output
   AdxIoOutW(shared->IoBase, DR_AO_SYNC_STROBE, 0);

   return 0;
}

int daq_ioctl_fao_set_param(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   FAO_CONFIG    xbuf;
   unsigned long flags;
   int           ret = 0;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   spin_lock_irqsave(&daq_dev->fao_lock, flags);
   if (unlikely(shared->FaoStatus.FnState != DAQ_FN_IDLE)){
      ret = -EBUSY;
   } else {
      shared->FaoParam           = xbuf;
      shared->FaoParam.ChanStart = xbuf.ChanStart & AO_CHL_MASK;
      shared->FaoParam.ChanCount = x_min(xbuf.ChanCount, (unsigned)AO_CHL_COUNT);
   }
   spin_unlock_irqrestore(&daq_dev->fao_lock, flags);

   if (likely(!ret)){
      daq_device_signal_event(daq_dev, KdxDevPropChged);
   }

   return ret;
}

int daq_ioctl_fao_set_buffer(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   FAO_CONFIG  *faoParam = &shared->FaoParam;
   FAO_STATUS *faoStatus = &shared->FaoStatus;

   unsigned long flags;
   unsigned      sgl_len, data_len, sect_len;
   int           ret = 0;

   if (unlikely(!faoParam->SampleCount)) {
      return -EINVAL;
   }

   spin_lock_irqsave(&daq_dev->fao_lock, flags);
   if (unlikely(faoStatus->FnState != DAQ_FN_IDLE)){
      ret = -EBUSY;
   } else {
      faoStatus->FnState  = DAQ_FN_READY;
      faoStatus->BufLength= shared->FaoParam.SampleCount;
      faoStatus->WritePos = 0;
   }
   spin_unlock_irqrestore(&daq_dev->fao_lock, flags);

   do {
      if (unlikely(ret)){
         break;
      }

      data_len = faoParam->SampleCount * AO_DATA_SIZE;
      ret = daq_umem_alloc(data_len, &daq_dev->fao_buffer, 1);
      if (unlikely(ret)){
         break;
      }
      
      sect_len = faoParam->SectionSize * AO_DATA_SIZE;
      sgl_len  = daq_plx905x_calc_sgl_length(data_len, sect_len);
      ret = daq_plx905x_alloc_sgl_mem(sgl_len, &daq_dev->fao_sgl);
      if (unlikely(ret)){
         break;
      }
/*
      ret = daq_umem_get_pages(arg, data_len, 1, &daq_dev->fao_buffer);
      if (unlikely(ret)){
         break;
      }
*/
      daq_dev->fao_cutoff_pt = NULL;
      ret = daq_plx905x_build_sgl(&daq_dev->fao_buffer,
               data_len, sect_len, DR_DMA_FIFO_DATA, 0, &daq_dev->fao_sgl);
      if (unlikely(ret)){
         break;
      }
   } while (0);

   if (ret){
      daq_umem_free(&daq_dev->fao_buffer);
      daq_plx905x_free_sgl_mem(&daq_dev->fao_sgl);

      faoStatus->FnState = DAQ_FN_IDLE;
      daq_dev->fao_cutoff_pt = NULL;
   }

   return ret;
}

int daq_ioctl_fao_start(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   unsigned long  flags;
   int            ret = 0;

   spin_lock_irqsave(&daq_dev->fao_lock, flags);
   do{
      if (shared->FaoStatus.FnState == DAQ_FN_IDLE){
         ret = -EINVAL;
         break;
      }

      if (shared->FaoStatus.FnState == DAQ_FN_RUNNING){
         ret = -EBUSY;
         break;
      }

      memset(shared->IsEvtSignaled, 0, sizeof(shared->IsEvtSignaled));
      memset(&shared->FaoStatus, 0, sizeof(FAO_STATUS));
	printk("Before set data WP=%d\n", shared->FaoStatus.WritePos);
      shared->FaoStatus.FnState   = DAQ_FN_RUNNING;
      shared->FaoStatus.AcqMode   = (__u32)arg;
      shared->FaoStatus.BufLength = shared->FaoParam.SampleCount;
      shared->FaoStatus.WPRunBack = 1; // I suppose the user had filled out the whole buffer.
   } while (0);
   spin_unlock_irqrestore(&daq_dev->fao_lock, flags);

   if (ret){
      return ret;
   }

   daq_device_clear_event(daq_dev, KdxAoDataTransed);
   daq_device_clear_event(daq_dev, KdxAoUnderrun);
   daq_device_clear_event(daq_dev, KdxAoTransStopped);
   daq_device_clear_event(daq_dev, KdxAoStopped);

   // Restore the S/G entry if some had changed it in the previous call to 'FAO stop'
   if (daq_dev->fao_cutoff_pt) {
      *daq_dev->fao_cutoff_pt = daq_dev->fao_cutoff_pt_bkup;
      daq_dev->fao_cutoff_pt  = NULL;
   }

   ret = daq_fao_start_hardware(daq_dev);

   return ret;
}

int daq_ioctl_fao_stop(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;

   if (shared->FaoStatus.FnState == DAQ_FN_IDLE){
      return 0;
   }

   if (arg & FAO_STOP_FREE_RES){
      daq_fao_stop_acquisition(daq_dev, 1);
      return 0;
   }

   if (arg & FAO_STOP_BREAK_NOW){
      daq_fao_stop_acquisition(daq_dev, 0);
      return 0;
   }

   if (shared->FaoStatus.AcqMode == DAQ_ACQ_INFINITE) {
      FAO_STATUS    *faoStatus = &shared->FaoStatus;
      unsigned      wposInByte = faoStatus->WritePos * AO_DATA_SIZE;
      unsigned      offset     = 0;
      PLX_SGL_ENTRY *cutOffPt  = NULL;

      if (!wposInByte) {
         cutOffPt = daq_dev->fao_sgl.end;
         offset   = cutOffPt->DataLength;
      } else {
         #define PTR_PFN(x)          ((unsigned long)(x) & PAGE_MASK)
         PLX_SGL_ENTRY *end_ptr;
         int           i;

         for (i = 0; i < daq_dev->fao_sgl.nr_pages; ++i){
            cutOffPt = (PLX_SGL_ENTRY *)daq_dev->fao_sgl.pages[i];
            if (PTR_PFN(cutOffPt) == PTR_PFN(daq_dev->fao_sgl.end)){
               end_ptr = daq_dev->fao_sgl.end + 1;
            } else {
               end_ptr = (PLX_SGL_ENTRY *)(daq_dev->fao_sgl.pages[i] + PAGE_SIZE);
            }

            for (; cutOffPt < end_ptr; ++cutOffPt){
               if (wposInByte <= cutOffPt->DataLength) {
                  offset = wposInByte;
                  break;
               }
               wposInByte -= cutOffPt->DataLength;
            }

            if (cutOffPt < end_ptr){
               break;
            }
         }
      }

      daq_dev->fao_cutoff_pt        = cutOffPt;
      daq_dev->fao_cutoff_pt_bkup   = *cutOffPt;
      cutOffPt->DataLength          = offset;
      cutOffPt->DescPtr.LastElement = 1;
      cutOffPt->DescPtr.TermCountInt= 1;
   }

   return 0;
}

