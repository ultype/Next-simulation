/*
 * isr.c
 *
 *  Created on: Nov 29, 2011
 *      Author: rocky
 */
#include "kdriver.h"
#include "hw.h"

// -----------------------------------------------------------------------------
// Must hold the lock when call this function.
static inline
void daq_fao_update_status(FAO_CONFIG *cfg, FAO_STATUS *st, unsigned inc_count)
{
   // check data transmitted and update write position
   if (st->ReadPos + inc_count >= st->BufLength) {
      st->BufState  |=  DAQ_OUT_TRANSMITTED;
      st->ReadPos    = 0;
      st->WPRunBack  = 0;
   } else {
      if ((st->ReadPos % cfg->SectionSize) + inc_count >= cfg->SectionSize) {
         st->BufState |= DAQ_OUT_TRANSMITTED;
      }
      st->ReadPos += inc_count;
   }

   // check underrun
   if (st->ReadPos > st->WritePos && !st->WPRunBack) {
      st->BufState |= DAQ_OUT_BUF_UNDERRUN;
   }
}

void daq_fao_tasklet_func(unsigned long arg)
{
   daq_device_t  *daq_dev   = (daq_device_t *) arg;
   DEVICE_SHARED *shared    = &daq_dev->shared;
   FAO_STATUS    *faoStatus = &shared->FaoStatus;
   unsigned      buf_state;
   unsigned long flags;

   spin_lock_irqsave(&daq_dev->fao_lock, flags);
   buf_state = faoStatus->BufState;
   faoStatus->BufState = 0;
   spin_unlock_irqrestore(&daq_dev->fao_lock, flags);

   if (buf_state & DAQ_OUT_BUF_UNDERRUN) {
      if (!shared->IsEvtSignaled[KdxAoUnderrun]) {
         shared->IsEvtSignaled[KdxAoUnderrun] = 1;
         daq_device_signal_event(daq_dev, KdxAoUnderrun);
      }
      if (daq_dev->fao_cutoff_pt) {
         daq_fao_stop_acquisition(daq_dev, 0);
      }
   }

   if ((buf_state & DAQ_OUT_TRANSMITTED) && !shared->IsEvtSignaled[KdxAoDataTransed]) {
      shared->IsEvtSignaled[KdxAoDataTransed] = 1;
      daq_device_signal_event(daq_dev, KdxAoDataTransed);
   }

   if ((buf_state & DAQ_OUT_TRANSSTOPPED) && faoStatus->FnState == DAQ_FN_RUNNING) {
      shared->IsEvtSignaled[KdxAoTransStopped] = 1;
      daq_device_signal_event(daq_dev, KdxAoTransStopped);
      schedule_delayed_work(&daq_dev->fao_fifo_chk_work, 1 /*jiffy*/);
   }
}

irqreturn_t daq_irq_handler(int irq, void *dev_id)
{
   daq_device_t  *daq_dev = (daq_device_t *) dev_id;
   DEVICE_SHARED *shared  = &daq_dev->shared;
   PLX_INT_CSR   int_csr;
   PLX_DMA_CSR   dma_csr;

   int_csr.Value = AdxIoInD(shared->BrBase, BR_PLX_INTCSR);
   if (!int_csr.Dma0IntActive) {
      return IRQ_RETVAL(0);
   }

   dma_csr.Value = AdxIoInB(shared->BrBase, BR_PLX_DMACSR0);
   spin_lock(&daq_dev->fao_lock);
   daq_fao_update_status(&shared->FaoParam, &shared->FaoStatus, shared->FaoParam.SectionSize);
   if (dma_csr.Done){
      shared->FaoStatus.BufState |= DAQ_OUT_TRANSMITTED | DAQ_OUT_TRANSSTOPPED;
   }
   spin_unlock(&daq_dev->fao_lock);

   dma_csr.ClearInt = 1;
   AdxIoOutB(shared->BrBase, BR_PLX_DMACSR0, dma_csr.Value);

   tasklet_schedule(&daq_dev->fao_tasklet);
   return IRQ_RETVAL(1);
}
