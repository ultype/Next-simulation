/*
 * kshared.h
 *
 *  Created on: 2011-8-30
 *      Author: rocky
 */

#ifndef KERNEL_MODULE_SHARED_H_
#define KERNEL_MODULE_SHARED_H_

#include <linux/types.h>


#define ADVANTECH_VID 0x13fe
#define DEVICE_ID     0x1721
#define DEVICE_PID    BD_PCI1721
#define DEVICE_NAME   "PCI-1721"
#define DRIVER_NAME   "bio1721"

// ----------------------------------------------------------
// H/W feature and structures.
// ----------------------------------------------------------
#define AO_CHL_COUNT          4
#define AO_CHL_MASK           (AO_CHL_COUNT - 1)
#define AO_RES_IN_BIT         12
#define AO_DATA_SIZE          sizeof(__u16)
#define AO_DATA_MASK          0xfff

#define AO_EXT_REF_BIPOLAR    10
#define AO_EXT_REF_UNIPOLAR   10

#define AO_CLK_BASE           (10*1000*1000)
#define AO_MAX_PACER          (10*1000*1000)
#define AO_MIN_PACER          (AO_CLK_BASE / (65535.0 * 65535.0) )
#define AO_FIFO_SIZE          1024

#define DIO_PORT_COUNT           2
#define DIO_CHL_COUNT            (DIO_PORT_COUNT * 8)

#define CNTR_CHL_COUNT           1
#define CNTR_RES_IN_BIT          16
#define CNTR_DATA_SIZE           sizeof(__u16)
#define CNTR_MIN_VAL             2
#define CNTR_MAX_VAL             65535
#define CNTR_CLK_BASE            (10 * 1000 * 1000)
#define CNTR_IDLE                0

#define CNTR_RBUF_DEPTH          16
#define CNTR_RBUF_POSMASK        (CNTR_RBUF_DEPTH -1)
#define CNTR_CHK_PERIOD_NS       10000000UL
#define CNTR_CHK_PERIOD_MAX_NS   625000000UL  // 10000000000UL >> 4
#define CNTR_VAL_THRESHOLD_BASE  10

enum KRNL_EVENT_IDX{
   KdxDevPropChged = 0,
   KdxAoDataTransed,
   KdxAoUnderrun,
   KdxAoTransStopped,
   KdxAoStopped,
   KrnlSptedEventCount,
};

static inline __u32 GetEventKIndex(__u32 id)
{
   __u32 kdx;
   switch (id)
   {
   case EvtPropertyChanged:           kdx = KdxDevPropChged;     break;
   case EvtBufferedAoDataTransmitted: kdx = KdxAoDataTransed;break;
   case EvtBufferedAoUnderrun:        kdx = KdxAoUnderrun;       break;
   case EvtBufferedAoTransStopped:    kdx = KdxAoTransStopped;   break;
   case EvtBufferedAoStopped:         kdx = KdxAoStopped;        break;
   default: kdx = -1; break;
   }
   return kdx;
}

// -----------------------------------------------------
// default values
// -----------------------------------------------------
#define DEF_INIT_ON_LOAD        1

// AO default values
#define DEF_AO_GAIN             V_0To5
#define DEF_AO_EXT_REF_BIPOLAR  AO_EXT_REF_BIPOLAR
#define DEF_AO_EXT_REF_UNIPOLAR AO_EXT_REF_UNIPOLAR
#define DEF_AO_INIT_STATE       0

#define DEF_FAO_CHSTART         0
#define DEF_FAO_CHCOUNT         1
#define DEF_FAO_CLKSRC          SigInternalClock
#define DEF_FAO_PACERDIVISOR    (100 * 100)
#define DEF_FAO_SECTSIZE        AO_FIFO_SIZE
#define DEF_FAO_MODE            DAQ_XFER_DMA

// DIO default values
#define DEF_DIO_DIR             0
#define DEF_DO_STATE            0

// CNTR default values
#define DEF_CNTR_CHIP_CLKSRC    SigInternalClock
#define DEF_CNTR_CHIP_LOADVAL   ((1 << CNTR_RES_IN_BIT) - 1)
#define DEF_CNTR_CHIP_OPMODE    0
#define DEF_CNTR_OST_CLKSRC     SigInternalClock
#define DEF_CNTR_OST_DELAYCNT   ((1 << CNTR_RES_IN_BIT) - 1)
#define DEF_CNTR_TMR_DIVISOR    (CNTR_CLK_BASE / 200)
#define DEF_CNTR_FM_PERIOD      0

// ----------------------------------------------------------
// Device private data
// ----------------------------------------------------------
typedef struct _FAO_CONFIG
{
   __u32  XferMode;
   __u32  ChanStart;
   __u32  ChanCount;
   __u32  ConvClkSource;
   double ConvClkRatePerCH;
   __u32  PacerDivider;
   __u32  SectionSize;
   __u32  SampleCount;
} FAO_CONFIG;

typedef struct _FAO_STATUS
{
   __u32  AcqMode;
   __u32  FnState;
   __u32  BufState;
   __u32  BufLength;
   __u32  WPRunBack;
   __u32  WritePos;
   __u32  ReadPos;
} FAO_STATUS;

typedef struct _CNTR_CONFIG
{
   // --------------------------------------------------------
   __u32  ChipClkSource[CNTR_CHL_COUNT];
   __u32  ChipOpMode[CNTR_CHL_COUNT];
   __u32  ChipLoadValue[CNTR_CHL_COUNT];

   // --------------------------------------------------------
   __u32  OstClkSource[CNTR_CHL_COUNT];
   __u32  OstDelayCount[CNTR_CHL_COUNT];
   // --------------------------------------------------------
   __u32  TmrDivisor[CNTR_CHL_COUNT];
   // --------------------------------------------------------
   __u32  FmPeroid[CNTR_CHL_COUNT];
} CNTR_CONFIG;

typedef struct _CNTR_STATE
{
   __u32     Operation;
   __u32     CanRead;
   __u32     AutoAdaptive;

   // ------------------------------------------
   __u32     CheckPeriod;
   __u32     Overflow;
   __u32     PrevValue;
   __u32     SummedValue;
   __s64     PrevTime;
   __u64     TotalTime;
   struct  {
      __u32  Head;
      __u32  Tail;
      __u32  CntrDelta[CNTR_RBUF_DEPTH];
      __u32  TimeDelta[CNTR_RBUF_DEPTH];
   };
} CNTR_STATE;

typedef struct _DEVICE_SHARED
{
   __u32       Size;           // Size of the structure
   __u32       ProductId;      // Device Type
   __u32       DeviceNumber;   // Zero-based device number

   // HW Information
   __u32       BoardId;        // Board dip switch number for the device
   __u32       BusNumber;      // PCI Bus number
   __u32       SlotNumber;     // PCI Slot number
   __u32       BrBase;
   __u32       BrLength;
   __u32       IoBase;
   __u32       IoLength;
   __u32       Irq;
   __u32       InitOnLoad;

   // --------------------------------------------------------
   __u32       AoChanGain[AO_CHL_COUNT];
   double      AoExtRefUnipolar;
   double      AoExtRefBipolar;
   __u16       AoChanState[AO_CHL_COUNT];

   FAO_CONFIG  FaoParam;
   FAO_STATUS  FaoStatus;

   // --------------------------------------------------------
   __u8        DioPortDir[DIO_PORT_COUNT];
   __u8        DoPortState[DIO_PORT_COUNT];

   // --------------------------------------------------------
   CNTR_CONFIG CntrConfig;
   CNTR_STATE  CntrState[CNTR_CHL_COUNT];
   __u32       CntrChkTimerOwner;

   // ---------------------------------------------------------
   __u32       IsEvtSignaled[KrnlSptedEventCount];

} DEVICE_SHARED;

#endif /* KERNEL_MODULE_SHARED_H_ */
