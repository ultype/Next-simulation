/*
 * counter.c
 *
 *  Created on: 2011-10-24
 *      Author: rocky
 */
#include "kdriver.h"
#include "hw.h"

static
int daq_cntr_start_primary(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   I825X_CTL     ctlWord = {0};
   unsigned long flags;

   if( start >= CNTR_CHL_COUNT || count > CNTR_CHL_COUNT ){
      return -EINVAL;
   }

   ctlWord.RW = 3;
   while (count--) {
      spin_lock_irqsave(&daq_dev->dev_lock, flags);
      if (shared->CntrState[start].Operation == CNTR_IDLE) {
         memset(&shared->CntrState[start], 0, sizeof(CNTR_STATE));
         shared->CntrState[start].Operation = Primary;
      } else {
         spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
         return -EBUSY;
      }
      spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

      ctlWord.SC   = start;
      ctlWord.Mode = shared->CntrConfig.ChipOpMode[start];
      AdxIoOutB(shared->IoBase, DR_CNTR_CTL,  ctlWord.Value );
      AdxIoOutB(shared->IoBase, DR_CNTR0 + start, shared->CntrConfig.ChipLoadValue[start]);
      AdxIoOutB(shared->IoBase, DR_CNTR0 + start, shared->CntrConfig.ChipLoadValue[start] >> 8);

      ++start;
      start %= CNTR_CHL_COUNT;
   }

   return 0;
}

static
int daq_cntr_start_event_count(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED  *shared = &daq_dev->shared;
   I825X_CTL      ctlWord = {0};
   unsigned long  flags;

   if(start != 2 || count != 1){
      return -EINVAL;
   }

   ctlWord.RW   = 3;
   ctlWord.Mode = 0;

   while (count--) {
      spin_lock_irqsave(&daq_dev->dev_lock, flags);
      if (shared->CntrState[start].Operation == CNTR_IDLE) {
         memset(&shared->CntrState[start], 0, sizeof(CNTR_STATE));
         shared->CntrState[start].Operation = InstantEventCount;
      } else {
         spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
         return -EBUSY;
      }
      spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

      ctlWord.SC = start;
      AdxIoOutB(shared->IoBase, DR_CNTR_CTL,  ctlWord.Value );
      AdxIoOutB(shared->IoBase, DR_CNTR0 + start, 0xff);
      AdxIoOutB(shared->IoBase, DR_CNTR0 + start, 0xff);

      if (start == 2 && daq_device_is_event_active(daq_dev, KdxCntTmnalCnt2)) {
         daq_int_select_source(daq_dev, 1, INT_SRC_COUNTER2, TRIG_EDGE_RISING, KdxCntTmnalCnt2);
      }

      shared->CntrChkTimerOwner |= 0x1 << start;
      schedule_delayed_work(&daq_dev->cntr_work, 1);

      ++start;
      start %= CNTR_CHL_COUNT;
   }

   return 0;
}

static
int daq_cntr_start_timer_pulse(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED  *shared = &daq_dev->shared;
   I825X_CTL      ctlWord = {0};
   unsigned long  flags;
   int            ret;
   __u32          divisor;

   if(start != 1 || count != 1){
      return -EINVAL;
   }

   ret = daq_int_select_source(daq_dev, 0, INT_SRC_TIMER1, TRIG_EDGE_RISING, KdxCntTimer1);
   if (ret) {
      return ret;
   }

   ctlWord.RW   = 3;
   ctlWord.Mode = 3;

   start = 0;
   count = 2;
   divisor = shared->CntrConfig.TmrDivisor[1];

   while (count--) {
      spin_lock_irqsave(&daq_dev->dev_lock, flags);
      if (shared->CntrState[start].Operation == CNTR_IDLE) {
         memset(&shared->CntrState[start], 0, sizeof(CNTR_STATE));
         shared->CntrState[start].Operation = TimerPulse;
      } else {
         spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
         daq_int_disable_source(daq_dev, 0, INT_SRC_TIMER1);
         return -EBUSY;
      }
      spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

      ctlWord.SC = start;
      AdxIoOutB(shared->IoBase, DR_CNTR_CTL,  ctlWord.Value );
      AdxIoOutB(shared->IoBase, DR_CNTR0 + start, divisor);
      AdxIoOutB(shared->IoBase, DR_CNTR0 + start, divisor >> 8);

      ++start;
      start %= CNTR_CHL_COUNT;
      divisor >>= 16;
   }

   return 0;
}

static
int daq_cntr_start_freq_measure(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED   *shared = &daq_dev->shared;
   I825X_CTL       ctlWord = {0};
   struct timespec tm_now;
   unsigned long   flags;

   if(start != 2 || count != 1){
      return -EINVAL;
   }

   ctlWord.RW   = 3;
   ctlWord.Mode = 0;

   while (count--) {
      spin_lock_irqsave(&daq_dev->dev_lock, flags);
      if (shared->CntrState[start].Operation == CNTR_IDLE) {
         memset(&shared->CntrState[start], 0, sizeof(CNTR_STATE));
         shared->CntrState[start].Operation = InstantFreqMeter;
      } else {
         spin_unlock_irqrestore(&daq_dev->dev_lock, flags);
         return -EBUSY;
      }
      spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

      shared->CntrState[start].AutoAdaptive = shared->CntrConfig.FmPeroid[start] == 0;
      if (shared->CntrConfig.FmPeroid[start]) {
         shared->CntrState[start].CheckPeriod = x_max((__u32)CNTR_CHK_PERIOD_NS, shared->CntrConfig.FmPeroid[start] * 1000000 / CNTR_RBUF_DEPTH);
      } else {
         shared->CntrState[start].CheckPeriod = CNTR_CHK_PERIOD_NS;
      }

      ctlWord.SC = start;
      AdxIoOutB(shared->IoBase, DR_CNTR_CTL,  ctlWord.Value );
      AdxIoOutB(shared->IoBase, DR_CNTR0 + start, 0xff);
      AdxIoOutB(shared->IoBase, DR_CNTR0 + start, 0xff);

      tm_now = current_kernel_time();
      shared->CntrState[start].PrevTime = timespec_to_ns(&tm_now);
      shared->CntrChkTimerOwner |= 0x1 << start;
      schedule_delayed_work(&daq_dev->cntr_work, 1);

      ++start;
      start %= CNTR_CHL_COUNT;
   }

   return 0;
}

static inline
void daq_cntr_update_ec_state(CNTR_STATE *cntr, I825X_STATUS hw_st, __u32 hw_val, __s64 *tm_stamp)
{
   if (cntr->CanRead && cntr->PrevValue < hw_val){
      ++cntr->Overflow;
   }
   cntr->CanRead   = !hw_st.Null;
   cntr->PrevValue = hw_val;
}

static
void daq_cntr_update_fm_state(CNTR_STATE *cntr, I825X_STATUS hw_st, __u32 hw_val, __s64 *tm_stamp)
{
   __u32  val_delta;
   __u32  tm_delta;

   tm_delta = (__u32)(*tm_stamp - cntr->PrevTime);
   if (cntr->CanRead) {
      if (tm_delta < cntr->CheckPeriod){
         return;
      }

      ++cntr->Tail;
      cntr->Tail &= CNTR_RBUF_POSMASK;
      if (cntr->Tail == cntr->Head) {
         cntr->SummedValue -= cntr->CntrDelta[cntr->Head];
         cntr->TotalTime   -= cntr->TimeDelta[cntr->Head];
         cntr->Head         = (cntr->Tail + 1) & CNTR_RBUF_POSMASK;
      }

      val_delta = (__u16)(cntr->PrevValue - hw_val);
      cntr->CntrDelta[cntr->Tail] = val_delta;
      cntr->SummedValue          += val_delta;
      cntr->TimeDelta[cntr->Tail] = tm_delta;
      cntr->TotalTime            += tm_delta;
      cntr->PrevValue             = hw_val;
      cntr->PrevTime              = *tm_stamp;

      if (cntr->AutoAdaptive){
         if (val_delta >= 10 * CNTR_VAL_THRESHOLD_BASE) {
            cntr->CheckPeriod = CNTR_CHK_PERIOD_NS;
         } else if (val_delta < CNTR_VAL_THRESHOLD_BASE) {
            cntr->CheckPeriod = x_min(cntr->CheckPeriod << 3, (__u32)CNTR_CHK_PERIOD_MAX_NS);
         }
      }
   } else {
      cntr->CanRead     = !hw_st.Null;
      cntr->SummedValue = cntr->CntrDelta[0] = (__u16)(CNTR_MAX_VAL + 1 - hw_val);
      cntr->TotalTime   = cntr->TimeDelta[0] = tm_delta;
      cntr->PrevTime    = *tm_stamp;
      cntr->PrevValue   = hw_val;
   }
}
//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------
void daq_cntr_update_state_work_func(struct work_struct *work)
{
   daq_device_t    *daq_dev = container_of(delayed_work_ptr(work), daq_device_t, cntr_work);
   DEVICE_SHARED   *shared  = &daq_dev->shared;
   I825X_CTL_RDBK  ctl_word = {0};
   I825X_STATUS    hw_st;
   struct timespec tm_now;
   __s64           tm_now_ns;
   __u32           i, hw_val, active= shared->CntrChkTimerOwner;

   ctl_word.Cntrs = active;
   ctl_word.RDBK  = I8254_SC_RDBK;
   AdxIoOutB(shared->IoBase, DR_CNTR_CTL, ctl_word.Value);

   getnstimeofday(&tm_now);
   tm_now_ns = timespec_to_ns(&tm_now);

   for (i = 0; active; ++i, active >>= 1){
      if (active & 0x1) {
         hw_st.Value = AdxIoInB(shared->IoBase, DR_CNTR0 + i);
         hw_val  = AdxIoInB(shared->IoBase, DR_CNTR0 + i);
         hw_val |= AdxIoInB(shared->IoBase, DR_CNTR0 + i) << 8;
         if (shared->CntrState[i].Operation == InstantFreqMeter){
            daq_cntr_update_fm_state(&shared->CntrState[i], hw_st, hw_val, &tm_now_ns);
         } else {
            daq_cntr_update_ec_state(&shared->CntrState[i], hw_st, hw_val, &tm_now_ns);
         }
      }
   }

   if (daq_dev->shared.CntrChkTimerOwner){
      schedule_delayed_work(delayed_work_ptr(work), msecs_to_jiffies(CNTR_CHK_PERIOD_NS / 1000000L));
   }
}

void daq_cntr_reset(daq_device_t *daq_dev, __u32 start, __u32 count)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   I825X_CTL     ctlWord = {0};
   int           resetCntr0 = false;
   unsigned long flags;

   ctlWord.Mode = 4;
   ctlWord.RW   = 3;

   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   while (count--) {
      ctlWord.SC = start;
      AdxIoOutB(shared->IoBase, DR_CNTR_CTL,  ctlWord.Value );
      AdxIoOutB(shared->IoBase, DR_CNTR0 + start, 1 );
      AdxIoOutB(shared->IoBase, DR_CNTR0 + start, 0 );

      shared->CntrChkTimerOwner &= ~(0x1 << start);
      if (start == 1) {
         daq_int_disable_source(daq_dev, 0, INT_SRC_TIMER1);
         resetCntr0 = true;
      } else if (start == 2) {
         daq_int_disable_source(daq_dev, 1, INT_SRC_COUNTER2);
      }

      shared->CntrState[start].Operation = CNTR_IDLE;
      ++start;
      start %= CNTR_CHL_COUNT;
   }
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

   if (resetCntr0 && shared->CntrState[0].Operation != CNTR_IDLE) {
      daq_cntr_reset(daq_dev, 0, 1);
   }
}

int daq_ioctl_cntr_set_param(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   CNTR_SET_CFG  cntr;
   void*         dataPtr;
   __u32         valLen;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= CNTR_CHL_COUNT) {
      return -EINVAL;
   }

   if (cntr.Count > CNTR_CHL_COUNT - cntr.Start) {
      cntr.Count = CNTR_CHL_COUNT - cntr.Start;
   }

   switch (cntr.PropID)
   {
   case CFG_ChipOperationModeOfCounters:
      dataPtr = &shared->CntrConfig.ChipOpMode[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_ChipLoadValueOfCounters:
      dataPtr = &shared->CntrConfig.ChipLoadValue[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_TmrFrequencyOfCounters:
      dataPtr = &shared->CntrConfig.TmrDivisor[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   case CFG_FmCollectionPeriodOfCounters:
      dataPtr = &shared->CntrConfig.FmPeroid[cntr.Start];
      valLen  = sizeof(__u32) * cntr.Count;
      break;
   default:
      return -EINVAL;
   }

   if (unlikely(copy_from_user(dataPtr, cntr.Value, valLen))){
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_cntr_start(daq_device_t *daq_dev, unsigned long arg)
{
   CNTR_START cntr;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= CNTR_CHL_COUNT || cntr.Count > CNTR_CHL_COUNT){
      return -EINVAL;
   }

   switch(cntr.Operation)
   {
   case Primary:
      return daq_cntr_start_primary(daq_dev, cntr.Start, cntr.Count);
   case InstantEventCount:
      return daq_cntr_start_event_count(daq_dev, cntr.Start, cntr.Count);
   case TimerPulse:
      return daq_cntr_start_timer_pulse(daq_dev, cntr.Start, cntr.Count);
   case InstantFreqMeter:
      return daq_cntr_start_freq_measure(daq_dev, cntr.Start, cntr.Count);
   default:
      return -ENOSYS;
   }
}

int daq_ioctl_cntr_read(daq_device_t *daq_dev, unsigned long arg)
{
   CNTR_READ  cntr;
   CNTR_VALUE vals[CNTR_CHL_COUNT];
   CNTR_VALUE *curr = vals;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= CNTR_CHL_COUNT || cntr.Count > CNTR_CHL_COUNT){
      return -EINVAL;
   }

   {
      DEVICE_SHARED  *shared  = &daq_dev->shared;
      I825X_CTL_RDBK ctl_word = {0};
      I825X_STATUS   hw_st;
      unsigned       mask;
      int            i;

      mask  = ((0x1 << cntr.Count) - 1) << cntr.Start;
      mask |= mask >> 3;

      ctl_word.Cntrs = mask;
      ctl_word.RDBK  = I8254_SC_RDBK;
      AdxIoOutB(shared->IoBase, DR_CNTR_CTL, ctl_word.Value);

      for (i = 0; i < cntr.Count; ++i){
         hw_st.Value  = AdxIoInB(shared->IoBase, DR_CNTR0 + cntr.Start);
         curr->CanRead= !hw_st.Null;

         curr->Value  = AdxIoInB(shared->IoBase, DR_CNTR0 + cntr.Start);
         curr->Value |= AdxIoInB(shared->IoBase, DR_CNTR0 + cntr.Start) << 8;

         if (shared->CntrState[cntr.Start].Operation == InstantEventCount) {
            daq_cntr_update_ec_state(&shared->CntrState[cntr.Start], hw_st, curr->Value, 0);
            curr->Overflow = (__u16)shared->CntrState[cntr.Start].Overflow;
         }

         ++curr;
         ++cntr.Start;
         cntr.Start %= CNTR_CHL_COUNT;
      }
   }

   if (unlikely(copy_to_user(cntr.Value, vals, cntr.Count * sizeof(CNTR_VALUE)))){
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_cntr_reset(daq_device_t *daq_dev, unsigned long arg)
{
   CNTR_RESET cntr;

   if (unlikely(copy_from_user(&cntr, (void *)arg, sizeof(cntr)))){
      return -EFAULT;
   }

   if (cntr.Start >= CNTR_CHL_COUNT || cntr.Count > CNTR_CHL_COUNT){
      return -EINVAL;
   }

   daq_cntr_reset(daq_dev, cntr.Start, cntr.Count);

   return 0;
}
