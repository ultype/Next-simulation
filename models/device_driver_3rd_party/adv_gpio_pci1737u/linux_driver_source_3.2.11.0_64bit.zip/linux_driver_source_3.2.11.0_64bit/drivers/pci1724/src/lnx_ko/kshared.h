/*
 * kshared.h
 *
 *  Created on: 2011-8-30
 *      Author: rocky
 */

#ifndef KERNEL_MODULE_SHARED_H_
#define KERNEL_MODULE_SHARED_H_

#include <linux/types.h>


#define ADVANTECH_VID 0x13fe
#define DEVICE_ID     0x1724
#define DEVICE_PID    BD_PCI1724
#define DEVICE_NAME   "PCI-1724"
#define DRIVER_NAME   "bio1724"

// ----------------------------------------------------------
// H/W feature and structures.
// ----------------------------------------------------------
#define AO_CHL_COUNT          32
#define AO_CHL_MASK           (AO_CHL_COUNT - 1)
#define AO_RES_IN_BIT         14
#define AO_DATA_SIZE          sizeof(__u16)
#define AO_DATA_MASK          0x3fff

#define GAIN_V_Neg10To10   0
#define GAIN_mA_0To20      1
#define GAIN_mA_4To20      2
#define CALI_ZERO          0
#define CALI_SPAN          1

enum KRNL_EVENT_IDX{
   KdxDevPropChged = 0,
   KrnlSptedEventCount,
};

static inline __u32 GetEventKIndex(__u32 id)
{
   __u32 kdx;
   switch (id)
   {
   case EvtPropertyChanged: kdx = KdxDevPropChged; break;
   default:                 kdx = -1;              break;
   }
   return kdx;
}

// -----------------------------------------------------
// default values
// -----------------------------------------------------
#define DEF_INIT_ON_LOAD        1

// AO default values
#define DEF_AO_GAIN             GAIN_V_Neg10To10
#define DEF_AO_INIT_STATE       ((1 << AO_RES_IN_BIT) >> 1)

// ----------------------------------------------------------
// Device private data
// ----------------------------------------------------------

typedef struct _DEVICE_SHARED
{
   __u32       Size;           // Size of the structure
   __u32       ProductId;      // Device Type
   __u32       DeviceNumber;   // Zero-based device number

   // HW Information
   __u32       BoardId;        // Board dip switch number for the device
   __u32       BusNumber;      // PCI Bus number
   __u32       SlotNumber;     // PCI Slot number
   __u32       IoBase;
   __u32       IoLength;
   __u32       Irq;
   __u32       InitOnLoad;

   // --------------------------------------------------------
   __u32       AoChanGain[AO_CHL_COUNT];
   __u32       AoChanState[AO_CHL_COUNT];

} DEVICE_SHARED;

#endif /* KERNEL_MODULE_SHARED_H_ */
