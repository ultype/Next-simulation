/*
 * hw.h
 *
 *  Created on: 2011-10-19
 *      Author: rocky
 */

#ifndef _KERNEL_MODULE_HW_H_
#define _KERNEL_MODULE_HW_H_

#define DAC_MODE_NORMAL 0x3
#define DAC_MODE_OFFSET 0x2
#define DAC_MODE_GAIN   0x1
typedef union _DAC_CTRL_REG{
   __u32 Value;
   struct{
	   __u32 DacData  : 14;
	   __u32 DacMode  : 2;
	   __u32 Channel  : 4;  // 0 ~ 7
	   __u32 Group    : 4;  // bit-mapped value. [0x1, 0x2, 0x4, 0x8]
	   __u32 Reserved : 8;
   };
}DAC_CTRL_REG;

#define DR_DAC_CTL        0x0

#define DAC_SYNC_OUT     0x1
#define DR_DAC_SYNC_CTL  0x4

#define DAC_STAT_MASK    0x2
#define DAC_STAT_READY   0x0
#define DAC_STAT_BUSY    0x2
#define EEP_STAT_BUSY    0x4
#define DR_DEV_STAT      0x4

#define EEP_USER         0
#define EEP_FACTORY      1
#define AO_GRP_ADDR(grp) (246 + (grp))

#define EEP_SCLK	     (0x1 << 0)
#define EEP_SDI	         (0x1 << 1)
#define EEP_CS_EEP1	     (0x1 << 2)
#define EEP_CS_EEP2	     (0x1 << 3)
#define EEP_RDY	         (0x1 << 4)
#define EEP_SDO	         (0x1 << 5)
#define EEP_CS_BASE      EEP_CS_EEP1
#define DR_EEP_CSR       0x8

#define DR_DAC_SYNC_STROBE 0xC

#define DR_BID           0x10

#define DR_DAC_RESET     0x20

/*
	93LC66 Definition
*/
#define EEP_OP_READ	     0x0200		/* For 93LC66 In 16-Bits Data Read  OP Code */
#define EEP_OP_WRITE	 0x0100		/* For 93LC66 In 16-Bits Data Write OP Code */
#define EEP_OP_ERASE	 0x0300		/* For 93LC66 In 16-Bits Data Erase One Word */
#define EEP_IGNOREBIT	 6		    /* For EWEN, ERAL, WRAL, EWDS CMD Timing */
#define EEP_OPCODEBIT    2
#define EEP_ADDRBIT	     8		    /* For 93LC66 In 16-Bit Mode Address Bit Number */
#define EEP_DATABITNO	 16		    /* For 93LC66 In 16-Bit Mode Data Bit Number */

#endif /* _KERNEL_MODULE_HW_H_ */
