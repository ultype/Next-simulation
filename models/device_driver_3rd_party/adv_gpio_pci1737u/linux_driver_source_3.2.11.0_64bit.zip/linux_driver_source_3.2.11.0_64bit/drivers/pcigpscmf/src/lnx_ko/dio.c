/*
 * dio.c
 *
 *  Created on: 2015-06-10
 *      Author: 
 */
#include "kdriver.h"
#include "hw.h"

//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------
static
void daq_dio_set_port_dir(daq_device_t *daq_dev)
{
   __u8 *dirs = daq_dev->shared.DioPortDir;
   __u8 curDir, newDir;

   unsigned i;

   for (i = 0; i < DIO_PORT_COUNT; ++i, ++dirs) {
      curDir = *(__u8 *)&IOREGS->DIO_CTL[i];

      newDir  = (*dirs & 0x0F) ? PORTDIR_OUT : PORTDIR_IN;
      newDir |= (*dirs & 0xF0) ? PORTDIR_OUT << 4 : PORTDIR_IN << 4;
      daq_trace(("SetPortDir: cur:0x%x --> new:0x%x\n", curDir, newDir));

      if (newDir != (curDir & 0x11)) {
         *(__u8 *)&IOREGS->DIO_CTL[i] = newDir;
      }
   }
}

void daq_dio_initialize_hw(daq_device_t *daq_dev)
{
   daq_dio_set_port_dir(daq_dev);

   if (daq_dev->shared.InitOnLoad){
      int i;
      for (i = 0; i < DIO_PORT_COUNT; ++i) {
        IOREGS->DIO_DAT[i] = daq_dev->shared.DoPortState[i];
      }
   }
}

int daq_ioctl_dio_set_port_dir(daq_device_t *daq_dev, unsigned long arg)
{
   DIO_SET_PORT_DIR xbuf;
   __u8             *dest = NULL;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   if (xbuf.PortStart + xbuf.PortCount > DIO_PORT_COUNT) {
      return -EINVAL;
   }

   dest = daq_dev->shared.DioPortDir;
   dest += xbuf.PortStart;

   if (unlikely(copy_from_user(dest, xbuf.Dirs, xbuf.PortCount))) {
      return -EFAULT;
   }

   daq_dio_set_port_dir(daq_dev);
   return 0;
}

int daq_ioctl_diflt_set_param(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED     *shared = &daq_dev->shared;
   DIO_SET_DIFLT_CFG xbuf;
   unsigned          i;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))) {
      return -EFAULT;
   }

   if (xbuf.SetWhich & DIFLT_SET_BLKINTVL) {
      shared->DiFltBlockTime = xbuf.BlkTime;
      for (i = 0; i < DIO_PORT_COUNT; ++i) {
         IOREGS->DIO_CTL[i].DFDUR = xbuf.BlkTime;
      }
   }

   if (xbuf.SetWhich & DIFLT_SET_CHENBED) {
      __u8 *dest = (__u8 *)shared->DiFltChEnabled + xbuf.SrcStart;

      for (i = 0; i < xbuf.SrcCount; ++i) {
         dest[xbuf.SrcStart + i] = xbuf.ChanEnabled[i];
         IOREGS->DIO_CTL[xbuf.SrcStart + i].DFEN0 = !!xbuf.ChanEnabled[i];
      }
   }

   return 0;
}

int daq_ioctl_diint_set_param(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED     *shared = &daq_dev->shared;
   DIO_SET_DIINT_CFG xbuf;
   __u8              *dest = NULL;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))) {
      return -EFAULT;
   }

   if (xbuf.SrcStart + xbuf.SrcCount > DIO_PORT_COUNT) {
      return -EINVAL;
   }

   switch(xbuf.SetWhich)
   {
   case DIINT_SET_TRIGEDGE: dest = shared->DiintTrigEdge; break;
   default: return -EINVAL;
   }

   dest += xbuf.SrcStart;
   if (unlikely(copy_from_user(dest, xbuf.Buffer, xbuf.SrcCount))) {
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_dicos_set_param(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED     *shared = &daq_dev->shared;
   DIO_SET_DICOS_CFG xbuf;
   __u8              *dest = NULL;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))) {
      return -EFAULT;
   }

   if (xbuf.SrcStart + xbuf.SrcCount > DIO_PORT_COUNT) {
      return -EINVAL;
   }

   dest = shared->DiCosChEnabled;
   dest += xbuf.SrcStart;

   if (unlikely(copy_from_user(dest, xbuf.ChanEnable, xbuf.SrcCount))) {
      return -EFAULT;
   }
   return 0;
}

int daq_ioctl_dipm_set_param(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED     *shared = &daq_dev->shared;
   DIO_SET_DIINT_CFG xbuf;
   __u8              *dest = NULL;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))) {
      return -EFAULT;
   }

   if (xbuf.SrcStart + xbuf.SrcCount > DIO_PORT_COUNT) {
      return -EINVAL;
   }

   switch (xbuf.SetWhich)
   {
   case DIPM_SET_CHENBED: dest = shared->DiPmChEnabled; break;
   case DIPM_SET_PORTVAL: dest = shared->DiPmValue; break;
   default: return -EINVAL;
   }
   dest += xbuf.SrcStart;

   if (unlikely(copy_from_user(dest, xbuf.Buffer, xbuf.SrcCount))) {
      return -EFAULT;
   }

   return 0;
}

int daq_ioctl_di_start_snap(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED     *shared = &daq_dev->shared;
   DIO_START_DI_SNAP xbuf;
   unsigned          event_kdx, src_idx, port;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))) {
      return -EFAULT;
   }

   event_kdx = GetEventKIndex(xbuf.EventId);
   src_idx   = event_kdx - KdxDiBegin;
   if (src_idx >= DI_SNAP_SRC_COUNT) {
      return -EINVAL;
   }

   daq_device_clear_event(daq_dev, event_kdx);
   shared->IsEvtSignaled[event_kdx]   = 0;
   shared->DiSnapParam[src_idx].PortStart = (__u8)xbuf.PortStart;
   shared->DiSnapParam[src_idx].PortCount = (__u8)xbuf.PortCount;

   port = src_idx / 3;
   switch(event_kdx)
   {
   case KdxDiintChan0:
   case KdxDiintChan8:
   case KdxDiintChan16:
      IOREGS->DIO_CTL[port].B0EDG = shared->DiintTrigEdge[port] == RisingEdge ? RISING_EDGE : FALLING_EDGE;
      IOREGS->DIO_CTL[port].LATEN = 1;
      IOREGS->DIO_CTL[port].B0IE  = 1;
      break;
   case KdxDicosPort0:
   case KdxDicosPort1:
   case KdxDicosPort2:
      IOREGS->DIO_CTL[port].SCDEN = shared->DiCosChEnabled[port];
      IOREGS->DIO_CTL[port].LATEN = 1;
      IOREGS->DIO_CTL[port].SCIE  = 1;
      break;
   case KdxDipmPort0:
   case KdxDipmPort1:
   case KdxDipmPort2:
      IOREGS->DIO_CTL[port].PMVAL = shared->DiPmValue[port];
      IOREGS->DIO_CTL[port].PMDEN = shared->DiPmChEnabled[port];
      IOREGS->DIO_CTL[port].LATEN = 1;
      IOREGS->DIO_CTL[port].PMIE  = 1;
      break;
   }

   return 0;
}

int daq_ioctl_di_stop_snap(daq_device_t *daq_dev, unsigned long arg)
{
   unsigned event_kdx, src_idx, port, latch_src;

   event_kdx = GetEventKIndex((__u32)arg);
   src_idx   = event_kdx - KdxDiBegin;
   if (src_idx >= DI_SNAP_SRC_COUNT) {
      return -EINVAL;
   }

   port = src_idx / 3;
   latch_src = IOREGS->DIO_CTL[port].B0IE | (IOREGS->DIO_CTL[port].SCIE << 1) | (IOREGS->DIO_CTL[port].PMIE << 2);

   switch(event_kdx)
   {
   case KdxDiintChan0:
   case KdxDiintChan8:
   case KdxDiintChan16:
      IOREGS->DIO_CTL[port].B0IE  = 0;
      IOREGS->DIO_CTL[port].LATEN = !!(latch_src & ~0x1);
      break;
   case KdxDicosPort0:
   case KdxDicosPort1:
   case KdxDicosPort2:
      IOREGS->DIO_CTL[port].SCIE  = 0;
      IOREGS->DIO_CTL[port].LATEN = !!(latch_src & ~0x2);
      break;
   case KdxDipmPort0:
   case KdxDipmPort1:
   case KdxDipmPort2:
      IOREGS->DIO_CTL[port].PMIE  = 1;
      IOREGS->DIO_CTL[port].LATEN = !!(latch_src & ~0x4);
      break;
   }

   return 0;
}

int daq_ioctl_do_write_bit(daq_device_t *daq_dev, unsigned long arg)
{
   DIO_RW_BIT xbuf;
   __u8       data, state;
   unsigned   port, bit;
   unsigned long flags;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   port = xbuf.Port % DIO_PORT_COUNT;
   bit  = xbuf.Bit;
   data = xbuf.Data;

   spin_lock_irqsave(&daq_dev->dev_lock, flags);
   state = IOREGS->DIO_DAT[port];
   state &= ~(1 << bit);
   state |= (data & 0x1) << bit;
   IOREGS->DIO_DAT[port] = state;
   spin_unlock_irqrestore(&daq_dev->dev_lock, flags);

   return 0;
}