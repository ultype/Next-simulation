/*
 * ai.c
 *
 *  Created on: 2015-06-10
 *      Author: 
 */

#include "kdriver.h"
#include "hw.h"

static 
int daq_ai_configure_channel(daq_device_t *daq_dev) 
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   AI_CH_R r = {0};
   int i;

   for (i = 0; i < AI_CHL_COUNT; ++i) {
      if ((i & 0x1) && shared->AiChanType[i] == Differential) {
         r.SD = 0;
      } else {
         r.SD = shared->AiChanType[i];
      }

      r.BU   = shared->AiChanGain[i] >> 4;
      r.GAIN = shared->AiChanGain[i] & 0x7;
      IOREGS->AI_CH[i] = r;       
   }

   return 0;
}

static 
void daq_ai_init_rbuf(DEVICE_SHARED *shared)
{
   FAI_CONFIG    *faiParam = &shared->FaiParam;
   RBUF_STATUS *rbufStatus = &shared->AiRBufStatus;
   __u16          halfFifo = AI_FIFO_SIZE / 2;
   
   if (faiParam->SectionSize > halfFifo) {
      rbufStatus->PPValue = halfFifo;
      rbufStatus->SCValue = faiParam->SectionSize;
   } else {
      rbufStatus->PPValue = faiParam->SectionSize;
      rbufStatus->SCValue = 0;
   }

   rbufStatus->RPValue = 0;
}

static 
int daq_fai_start_hardware(daq_device_t *daq_dev)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   FAI_CONFIG  *faiParam = &shared->FaiParam;
   FAI_STATUS *faiStatus = &shared->FaiStatus;
   AI_CTL_R       ai_ctl = {0}; 
   AC_IO_R        ac_io  = {0};
   int           SWTRGEN = 1;


   IOREGS->AI_DMAEN = 0;
   IOREGS->AI_CTL = ai_ctl;
   udelay(2 * 50);

   IOREGS->AI_IE.xval   = 0;
   IOREGS->DEV_IF0.xval = AI_INT_MASK;

   IOREGS->AI_WP  = 0;
   IOREGS->AI_RP  = 0;
   IOREGS->AI_MUX = daq_ai_calc_phy_chan_range32(shared->AiChanType, AI_CHL_COUNT, faiParam->PhyChanStart, faiParam->LogChanCount);

   IOREGS->AI_CCDIV = faiParam->PacerDivider;
   if (faiParam->ScanClkSource == SignalNone) {
      IOREGS->AI_SCDIV   = faiParam->PacerDivider;
      IOREGS->AI_ITERNUM = 1;
   } else {
      IOREGS->AI_SCDIV   = faiParam->ScanClkDivider;
      IOREGS->AI_ITERNUM = faiParam->ScanCount;
   }

   IOREGS->AI_SWTRG.SWSTAEN = 1;
   IOREGS->AI_SWTRG.SWSTA   = 0;

   if ((faiParam->TrigSource  != SignalNone && faiParam->TrigAction  != ActionNone) 
      ||(faiParam->Trig1Source != SignalNone && faiParam->Trig1Action != ActionNone)) 
   {
      // Trigger 0
      if (faiParam->TrigSource == SigExtDigTrigger0) {
         ai_ctl.DTRG0EDG = faiParam->TrigEdge == RisingEdge ? RISING_EDGE : FALLING_EDGE;
         ai_ctl.DTRG0FN  = faiParam->TrigAction == DelayToStart ? TRG_FN_START : TRG_FN_STOP;
        
         IOREGS->AI_DTRG0DNUM = faiParam->TrigDelayCount / faiParam->LogChanCount;
      } else if (faiParam->TrigSource == SigExtAnaTrigger) {
         ai_ctl.ATRG0EDG = faiParam->TrigEdge == RisingEdge ? RISING_EDGE : FALLING_EDGE;
         ai_ctl.ATRG0FN  = faiParam->TrigAction == DelayToStart ? TRG_FN_START : TRG_FN_STOP;

         IOREGS->AI_ATRG0DNUM = faiParam->TrigDelayCount / faiParam->LogChanCount;

         // Fix bug#10569
         // The following two register: data & cmd must be written together.
         ac_io.DATA = faiParam->TrigLevelBin;
         ac_io.CMD  = CAL_AI_TRG0_ANA_THD;
         IOREGS->ACIO.xval = ac_io.xval;
         udelay(2 * 2);

         ac_io.DATA = faiParam->TrigHystIndexBin;
         ac_io.CMD  = CAL_AI_TRG0_ANA_HYS;
         IOREGS->ACIO.xval = ac_io.xval;
         udelay(2 * 2);
      }

      // Trigger 1
      if (faiParam->Trig1Source == SigExtDigTrigger1) {
         ai_ctl.DTRG1EDG = faiParam->Trig1Edge == RisingEdge ? RISING_EDGE : FALLING_EDGE;
         ai_ctl.DTRG1FN  = faiParam->Trig1Action == DelayToStart ? TRG_FN_START : TRG_FN_STOP;

         IOREGS->AI_DTRG1DNUM = faiParam->Trig1DelayCount / faiParam->LogChanCount;
      } else if (faiParam->Trig1Source == SigExtAnaTrigger1) {
         ai_ctl.ATRG1EDG = faiParam->Trig1Edge == RisingEdge ? RISING_EDGE : FALLING_EDGE;
         ai_ctl.ATRG1FN  = faiParam->Trig1Action == DelayToStart ? TRG_FN_START : TRG_FN_STOP;

         IOREGS->AI_ATRG1DNUM = faiParam->Trig1DelayCount / faiParam->LogChanCount;

         // Fix bug#10569
         // The following two register: data & cmd must be written together.
         ac_io.DATA = faiParam->Trig1LevelBin;
         ac_io.CMD  = CAL_AI_TRG1_ANA_THD;
         IOREGS->ACIO.xval = ac_io.xval;
         udelay(2 * 2);

         ac_io.DATA = faiParam->Trig1HystIndexBin;
         ac_io.CMD  = CAL_AI_TRG1_ANA_HYS;
         IOREGS->ACIO.xval = ac_io.xval;
         udelay(2 * 2);
      }

      if ((faiParam->TrigAction  == DelayToStop && faiParam->TrigSource  != SignalNone)
         ||(faiParam->Trig1Action == DelayToStop && faiParam->Trig1Source != SignalNone)) {
         IOREGS->AI_IE.CF = 1;
      }

      if ((faiParam->TrigAction == DelayToStart && faiParam->TrigSource != SignalNone) 
         ||(faiParam->Trig1Action == DelayToStart && faiParam->Trig1Source != SignalNone)) {
         SWTRGEN = 0; 
      }
   }

   IOREGS->AI_DMAADRL = (__u32)daq_dev->fai_dma_buf.daddr;
   IOREGS->AI_DMAADRH = (__u32)(daq_dev->fai_dma_buf.daddr >> 32);
   IOREGS->AI_PNUM    = shared->AiRBufStatus.PPValue;

   if (shared->AiRBufStatus.SCValue != 0) {
      IOREGS->AI_SNUM = shared->AiRBufStatus.SCValue;
      IOREGS->AI_IE.SC = 1;
   }

   IOREGS->AI_IE.PC = 1;
   IOREGS->AI_IE.OF = 1;
   IOREGS->AI_DMAEN = 1;

   // Select AD clock source
   ai_ctl.CCLKSRC = faiParam->ConvClkSource == SigInternalClock ? CONV_CLK_INTERN : CONV_CLK_EXTERN;
   if (faiParam->ScanClkSource == SignalNone) {
      ai_ctl.SCLKSRC = faiParam->ConvClkSource == SigInternalClock ? SCAN_CLK_INTERN : SCAN_CLK_EXT_CONV;
   } else {
      ai_ctl.SCLKSRC = faiParam->ScanClkSource == SigInternalClock ? SCAN_CLK_INTERN : SCAN_CLK_EXT_SCAN;
   }

   // Set Pacer Mode to start A/D
   ai_ctl.POLLEN = 0;
   ai_ctl.CONVEN = 1;
   IOREGS->AI_CTL = ai_ctl;
   if (SWTRGEN) {
      IOREGS->AI_SWTRG.SWSTA = 1;
      IOREGS->AI_SWTRG.SWSTA = 0;
   }

   // add the task to wait_queue for sync read
   if (faiStatus->AcqMode == DAQ_ACQ_FINITE_SYNC){
      return wait_event_interruptible(daq_dev->fai_queue, faiStatus->FnState != DAQ_FN_RUNNING);
   }

   return 0;
}

//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------
void daq_ai_initialize_hw(daq_device_t *daq_dev)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   AI_CTL_R ctl = {0};

   IOREGS->ACC.EN = 0;

   IOREGS->AI_DMAEN = 0;
   IOREGS->AI_CTL.CONVEN = 0;

   IOREGS->AI_IE.xval   = 0;
   IOREGS->DEV_IF0.xval = AI_INT_MASK;

   IOREGS->AI_RBSZ = AI_FIFO_SIZE - 1;
   IOREGS->AI_WP = 0;
   IOREGS->AI_RP = 0;

   daq_ai_configure_channel(daq_dev);

   IOREGS->AI_MUX     = daq_ai_calc_phy_chan_range32(shared->AiChanType, AI_CHL_COUNT, shared->SaiCHStart, shared->SaiCHCount);
   IOREGS->AI_CCDIV   = shared->SaiClkDiv;
   IOREGS->AI_SCDIV   = shared->SaiClkDiv;
   IOREGS->AI_ITERNUM = 1;

   IOREGS->AI_SWTRG.SWSTAEN = 1;

   // ---------------------------------------------------------
   ctl.CCLKSRC  = INTERNAL_CLOCK;
   ctl.SCLKSRC  = INTERNAL_CLOCK; 

   ctl.ATRG0FN  = TRG_FN_DISABLED;
   ctl.ATRG1FN  = TRG_FN_DISABLED;

   ctl.DTRG0EDG = RISING_EDGE;
   ctl.DTRG0FN  = TRG_FN_DISABLED;

   ctl.DTRG1EDG = RISING_EDGE;
   ctl.DTRG1FN  = TRG_FN_DISABLED;
   ctl.RTRGEN   = 0;

   ctl.POLLEN   = 1;
   ctl.CONVEN   = 1; 

   IOREGS->AI_CTL = ctl;

   IOREGS->AI_SWTRG.SWSTA = 1;
   IOREGS->AI_SWTRG.SWSTA = 0;

   shared->AiLogChanCount = daq_ai_calc_log_chan_count(shared->AiChanType, AI_CHL_COUNT);
}

void daq_fai_stop_acquisition(daq_device_t *daq_dev, int cleanup)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   FAI_CONFIG  *faiParam = &shared->FaiParam;
   FAI_STATUS *faiStatus = &shared->FaiStatus;
   
   AI_CTL_R  ctl;
   unsigned long flags;

   spin_lock_irqsave(&daq_dev->fai_lock, flags);
   if (faiStatus->FnState != DAQ_FN_RUNNING){
      spin_unlock_irqrestore(&daq_dev->fai_lock, flags);
   } else {
      faiStatus->FnState = DAQ_FN_STOPPED;
      spin_unlock_irqrestore(&daq_dev->fai_lock, flags);

      IOREGS->AI_DMAEN = 0;

      ctl = IOREGS->AI_CTL;
      ctl.CCLKSRC = INTERNAL_CLOCK;
      ctl.SCLKSRC = INTERNAL_CLOCK;
      ctl.CONVEN  = 0;
      IOREGS->AI_CTL = ctl;

      IOREGS->AI_IE.xval   = 0;
      IOREGS->DEV_IF0.xval = AI_INT_MASK;

      IOREGS->AI_WP = 0;
      IOREGS->AI_RP = 0;

      IOREGS->AI_MUX     = daq_ai_calc_phy_chan_range32(shared->AiChanType, AI_CHL_COUNT, shared->SaiCHStart, shared->SaiCHCount);
      IOREGS->AI_CCDIV   = shared->SaiClkDiv;
      IOREGS->AI_SCDIV   = shared->SaiClkDiv;
      IOREGS->AI_ITERNUM = 1;

      IOREGS->AI_SWTRG.SWSTAEN = 1;

      ctl.POLLEN = 1;
      ctl.CONVEN = 1;
      IOREGS->AI_CTL = ctl;

      // Start AI convert
      IOREGS->AI_SWTRG.SWSTA = 1;
      IOREGS->AI_SWTRG.SWSTA = 0;

      if (((faiParam->TrigAction == DelayToStop) && (faiParam->TrigSource != SignalNone)) ||
         ((faiParam->Trig1Action == DelayToStop) && (faiParam->Trig1Source != SignalNone))) {
            __u32 availStart = 0;
            __u32 availCount = 0;
            __u32 trigPos    = 0;
            __u32 trigDelay  = 0;
            __u32 lastData   = 0;
            __u32 *userBuffer= (__u32 *)daq_dev->fai_buffer.kaddr;

            lastData = userBuffer[faiStatus->WritePos];

            daq_trace(("Stop trigger flag is %x\n", lastData));

            switch(lastData & 0xF0)
            {
            case 0x00: trigDelay = 0;   break;
            case 0x10:
            case 0x20: trigDelay = faiParam->TrigDelayCount * faiParam->ScanCount;  break;
            case 0x40:
            case 0x80: trigDelay = faiParam->Trig1DelayCount * faiParam->ScanCount; break;
            }

            if (trigDelay > faiParam->SampleCount) {
               trigPos    = 0;
               availStart = 0;
               availCount = faiParam->SampleCount;
            } else {
               if (faiStatus->WritePos >= trigDelay) {
                  trigPos = faiStatus->WritePos - trigDelay;
                  if (faiStatus->WPRunBack) {// case0
                     availStart = faiStatus->WritePos;
                     availCount = faiParam->SampleCount;
                  } else  {// case1
                     availStart = 0;
                     availCount = faiStatus->WritePos;
                  }
               } else {
                  trigPos = faiParam->SampleCount - (trigDelay - faiStatus->WritePos); 
                  if (faiStatus->WPRunBack) {// case 2
                     availStart = faiStatus->WritePos;
                     availCount = faiParam->SampleCount;
                  } else {// case 3
                     availStart = 0;
                     availCount = faiStatus->WritePos;
                  }
               }
               trigPos %= faiStatus->BufLength;
            }

            if (availCount == faiParam->SampleCount) {
               ++faiStatus->WPRunBack;
               ++faiStatus->WPRunBack_TDtp;
            }

            if (faiStatus->ReadPos <= availStart) {
               faiStatus->ReadPos = availStart;
            }
            daq_trace(("RP = %d, WP = %d, WPRunBack= %d; TrigPos = %d, TrigEnd = %d, AvailStart = %d, AvailCount = %d, 1stAvailData = 0x%x, 1stTrgData = 0x%x\n", 
               faiStatus->ReadPos, faiStatus->WritePos, faiStatus->WPRunBack, trigPos, faiStatus->WritePos, 
               availStart, availCount, userBuffer[availStart], userBuffer[trigPos]));
      }

      if (!shared->IsEvtSignaled[KdxAiStopped]) {
         shared->IsEvtSignaled[KdxAiStopped] = 1;
         daq_device_signal_event(daq_dev, KdxAiStopped);
      }

      wake_up_interruptible(&daq_dev->fai_queue);
   }

   if (cleanup) {
      daq_dmem_free(&daq_dev->pdev->dev, &daq_dev->fai_dma_buf);
      daq_umem_unmap(&daq_dev->fai_buffer);

      spin_lock_irqsave(&daq_dev->fai_lock, flags);
      faiStatus->FnState = DAQ_FN_IDLE;
      spin_unlock_irqrestore(&daq_dev->fai_lock, flags);
   }
}

int daq_ioctl_ai_set_channel(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   AI_SET_CHAN   xbuf;
   AI_CHAN_CFG   cfg[AI_CHL_COUNT];
   __u32         phyCH, i;

   if (unlikely(shared->FaiStatus.FnState == DAQ_FN_RUNNING)){
      return -EBUSY;
   }

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   if (unlikely(xbuf.PhyChanCount > AI_CHL_COUNT)){
      xbuf.PhyChanCount = AI_CHL_COUNT;
   }
   if (unlikely(copy_from_user(cfg, (void *)xbuf.ChanCfg, sizeof(AI_CHAN_CFG) * xbuf.PhyChanCount))){
      return -EFAULT;
   }

   IOREGS->AI_CTL.CONVEN = 0;

   for (i = 0; i < xbuf.PhyChanCount; ++i) {
      phyCH = (xbuf.PhyChanStart + i) & AI_CHL_MASK;
      if (xbuf.SetWhich & AI_SET_CHSCTYPE) {
         shared->AiChanType[ phyCH ] = cfg[i].SCType;
      }
      if (xbuf.SetWhich & AI_SET_CHGAIN) {
         shared->AiChanGain[ phyCH ] = cfg[i].Gain;
      }
   }

   daq_ai_configure_channel(daq_dev);

   IOREGS->AI_CTL.POLLEN = 1;
   IOREGS->AI_CTL.CONVEN = 1;

   IOREGS->AI_SWTRG.SWSTAEN = 1;
   IOREGS->AI_SWTRG.SWSTA   = 1;
   IOREGS->AI_SWTRG.SWSTA   = 0;

   // Re-calculate the logical channel count
   shared->AiLogChanCount = daq_ai_calc_log_chan_count(shared->AiChanType, AI_CHL_COUNT);
   return 0;
}

int daq_ioctl_fai_set_param(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;

   FAI_CONFIG    xbuf;
   unsigned long flags;
   int           ret = 0;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   spin_lock_irqsave(&daq_dev->fai_lock, flags);
   if (unlikely(shared->FaiStatus.FnState != DAQ_FN_IDLE)){
      ret = -EBUSY;
   } else {
      shared->FaiParam              = xbuf;
      shared->FaiParam.PhyChanStart = xbuf.PhyChanStart & AI_CHL_MASK;
      shared->FaiParam.LogChanCount = x_min(xbuf.LogChanCount, shared->AiLogChanCount);
   }
   spin_unlock_irqrestore(&daq_dev->fai_lock, flags);

   if (likely(!ret)){
      daq_device_signal_event(daq_dev, KdxDevPropChged);
   }

   return ret;
}

int daq_ioctl_fai_set_buffer(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   FAI_CONFIG  *faiParam = &shared->FaiParam;
   FAI_STATUS *faiStatus = &shared->FaiStatus;

   unsigned long flags;
   int           ret = 0;

   if (unlikely(!faiParam->SampleCount)) {
      return -EINVAL;
   }

   spin_lock_irqsave(&daq_dev->fai_lock, flags);
   if (unlikely(faiStatus->FnState != DAQ_FN_IDLE)){
      ret = -EBUSY;
   } else {
      faiStatus->FnState   = DAQ_FN_READY;
      faiStatus->BufLength = faiParam->SampleCount;
   }
   spin_unlock_irqrestore(&daq_dev->fai_lock, flags);
   if (unlikely(ret)){
      return ret;
   }

   do {
      ret = daq_umem_map(arg, faiParam->SampleCount * AI_DATA_SIZE, 1, &daq_dev->fai_buffer);
      if (unlikely(ret)) break; 

      ret = daq_dmem_alloc(&daq_dev->pdev->dev, AI_FIFO_SIZE * AI_DATA_SIZE, &daq_dev->fai_dma_buf);
      if (unlikely(ret)) break;

   } while (0);

   if (ret){
      daq_umem_unmap(&daq_dev->fai_buffer);
      faiStatus->FnState = DAQ_FN_IDLE;
   }

   return ret;
}

int daq_ioctl_fai_start(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   unsigned long flags;
   int           ret = 0;

   spin_lock_irqsave(&daq_dev->fai_lock, flags);
   do {
      if (shared->FaiStatus.FnState == DAQ_FN_IDLE){
         ret = -EINVAL;
         break;
      }

      if (shared->FaiStatus.FnState == DAQ_FN_RUNNING){
         ret = -EBUSY;
         break;
      }

      memset(&shared->FaiStatus, 0, sizeof(FAI_STATUS));
      shared->FaiStatus.FnState   = DAQ_FN_RUNNING;
      shared->FaiStatus.AcqMode   = (__u32)arg;
      shared->FaiStatus.BufLength = shared->FaiParam.SampleCount;
   } while (0);
   spin_unlock_irqrestore(&daq_dev->fai_lock, flags);

   if (ret){
      return ret;
   }

   shared->IsEvtSignaled[KdxAiDataReady]     = 0;
   shared->IsEvtSignaled[KdxAiOverrun]       = 0;
   shared->IsEvtSignaled[KdxAiStopped]       = 0;
   shared->IsEvtSignaled[KdxAiCacheOverflow] = 0;

   daq_device_clear_event(daq_dev, KdxAiDataReady);
   daq_device_clear_event(daq_dev, KdxAiOverrun);
   daq_device_clear_event(daq_dev, KdxAiStopped);
   daq_device_clear_event(daq_dev, KdxAiCacheOverflow);
   
   daq_ai_init_rbuf(shared);
   ret = daq_fai_start_hardware(daq_dev);

   return ret;
}

int daq_ioctl_fai_stop(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;

   if (shared->FaiStatus.FnState == DAQ_FN_IDLE){
      return 0;
   }

   daq_fai_stop_acquisition(daq_dev, arg & FAI_STOP_FREE_RES);

   return 0;
}

