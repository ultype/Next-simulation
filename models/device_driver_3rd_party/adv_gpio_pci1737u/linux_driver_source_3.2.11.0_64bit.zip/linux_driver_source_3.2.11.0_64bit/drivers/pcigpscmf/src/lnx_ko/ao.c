/*
 * ao.c
 *
 *  Created on: 2015-06-10
 *      Author: 
 */
#include "kdriver.h"
#include "hw.h"

__inline static 
void daq_ao_fill_chan_csr(unsigned chan, unsigned gain, AO_CH_R *r)
{
   r->GAIN = gain;
}

static void daq_ao_init_rbuf(daq_device_t *daq_dev)
{
   DEVICE_SHARED   *shared = &daq_dev->shared;
   FAO_CONFIG    *faoParam = &shared->FaoParam;
   FAO_STATUS   *faoStatus = &shared->FaoStatus;
   RBUF_STATUS *rbufStatus = &shared->AoRBufStatus;
   __u32          *usr_buf = (__u32*)daq_dev->fao_buffer.kaddr;
   __u32          *dma_buf = (__u32*)daq_dev->fao_dma_buf.kaddr;
   unsigned       i;

   if (faoParam->SectionSize > AO_FIFO_SIZE / 2) {
      __u32 tp = faoParam->SectionSize;
      while(1) {
         if (tp >= AO_FIFO_SIZE / 4 && tp <= AO_FIFO_SIZE / 2) {
            rbufStatus->TPValue = AO_FIFO_RBSZ - tp;
            break;
         }

         if (tp == 0) { break; }
         tp = tp / 2;
      }
   } else {
      __u32 sectSize = faoParam->SectionSize == 1 ? 2 : faoParam->SectionSize;
      rbufStatus->TPValue = AO_FIFO_RBSZ - sectSize;
   }

   rbufStatus->TPValue = faoParam->RealyTpValue == 0 ? rbufStatus->TPValue : faoParam->RealyTpValue;

   daq_trace(("AO SampleCount=%d, SectionSize=%d, DataLedft=%d \n", 
      faoParam->SampleCount, faoParam->SectionSize, faoStatus->DataLeft));

   //
   // Load data to the FIFO
   faoStatus->ReadPos = 0;
   if (faoStatus->BufLength < AO_FIFO_RBSZ) {
      for (i = 0; i < faoStatus->BufLength; ++i) {
         dma_buf[i] = usr_buf[i];

         if (i && (i % faoParam->SectionSize) == 0) {
            faoStatus->ReadPos += faoParam->SectionSize;

            if (!shared->IsEvtSignaled[KdxAoDataTransed]) {
               shared->IsEvtSignaled[KdxAoDataTransed] = 1;
               daq_device_signal_event(daq_dev, KdxAoDataTransed);
            }
         }
      }

      faoStatus->DataLeft = 0;
      faoStatus->ReadPos  = 0;
      rbufStatus->WPValue = faoStatus->BufLength;

      if (faoStatus->AcqMode == DAQ_ACQ_INFINITE) {
         faoStatus->DataLeft = AO_FIFO_RBSZ; 
         for (i = faoStatus->BufLength; i < AO_FIFO_RBSZ; ++i) {
            dma_buf[i] = usr_buf[faoStatus->ReadPos];
            faoStatus->ReadPos++;
            faoStatus->ReadPos %= faoStatus->BufLength;
         }
         rbufStatus->WPValue = 0;
      }
   } else { 
      for (i = 0; i < AO_FIFO_RBSZ; ++i) {
         dma_buf[i] = usr_buf[i];
         if (i && (i % faoParam->SectionSize) == 0) {
            faoStatus->ReadPos += faoParam->SectionSize;
            if (!shared->IsEvtSignaled[KdxAoDataTransed]) {
               shared->IsEvtSignaled[KdxAoDataTransed] = 1;
               daq_device_signal_event(daq_dev, KdxAoDataTransed);
            }
         }
      }

      //Update the userBuffer RP
      faoStatus->ReadPos  = AO_FIFO_RBSZ;
      faoStatus->DataLeft = faoStatus->BufLength - AO_FIFO_RBSZ;
      rbufStatus->WPValue = 0;
   }

   daq_trace(("UserBuf RP=%d, WP=%d, WPRunBack=%d; FIFO WP=%d\n", 
      faoStatus->ReadPos, faoStatus->WritePos, faoStatus->WPRunBack, rbufStatus->WPValue));
}

static 
int daq_fao_start_hardware(daq_device_t *daq_dev)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   FAO_CONFIG  *faoParam = &shared->FaoParam;
   FAO_STATUS *faoStatus = &shared->FaoStatus;
   int           SWTRGEN = 1;
   AO_CTL_R       ao_ctl = {0};
   __u32             mux;

   IOREGS->AO_CTL       = ao_ctl;
   IOREGS->AO_IE.xval   = 0;
   IOREGS->DEV_IF0.xval = AO_INT_MASK;

   IOREGS->AO_RP     = 0;
   IOREGS->AO_WP     = 0;
   IOREGS->AO_SYNCEN = 1;

   mux = ((faoParam->ChanStart + faoParam->ChanCount - 1) % AO_CHL_COUNT) << 16;
   mux |= faoParam->ChanStart;
   IOREGS->AO_MUX = mux;

   IOREGS->AO_CCDIV   = faoParam->PacerDivider;

   IOREGS->AO_DMAADRL = (__u32)daq_dev->fao_dma_buf.daddr;
   IOREGS->AO_DMAADRH = (__u32)(daq_dev->fao_dma_buf.daddr >> 32);
   IOREGS->AO_DMATHR  = shared->AoRBufStatus.TPValue;

   if (faoStatus->AcqMode != DAQ_ACQ_INFINITE && faoParam->SampleCount < AO_FIFO_RBSZ) {
      IOREGS->AO_DMALEN = faoParam->SampleCount;
   } else {
      IOREGS->AO_DMALEN = AO_FIFO_RBSZ;
   }

   udelay(40);

   IOREGS->AO_SWTRG.SWSTAEN = 1;
   IOREGS->AO_SWTRG.SWSTA   = 0;

   IOREGS->AO_IE.BE = 1;
   IOREGS->AO_IE.TP = 1;

   if ((faoParam->TrigSource  != SignalNone && faoParam->TrigAction != ActionNone) 
      || (faoParam->Trig1Source != SignalNone && faoParam->Trig1Action != ActionNone)) {

         SWTRGEN = false;

         // Trigger 0
         if (faoParam->TrigSource == SigExtDigTrigger0) {
            ao_ctl.DTRG0EDG = (faoParam->TrigEdge == RisingEdge) ?  RISING_EDGE : FALLING_EDGE;
            ao_ctl.DTRG0FN  = (faoParam->TrigAction == DelayToStart) ? TRG_FN_START : TRG_FN_STOP;
         } 

         // Trigger 1
         if (faoParam->Trig1Source == SigExtDigTrigger1) {
            ao_ctl.DTRG1EDG = (faoParam->Trig1Edge == RisingEdge) ? RISING_EDGE : FALLING_EDGE;
            ao_ctl.DTRG1FN  = (faoParam->Trig1Action == DelayToStart) ? TRG_FN_START : TRG_FN_STOP;
         } 
   }

   // enable ao convert
   ao_ctl.CCLKSRC = faoParam->ConvClkSource == SigInternalClock ? CONV_CLK_INTERN : CONV_CLK_EXTERN; 
   ao_ctl.CONVEN  = 1;
   IOREGS->AO_CTL = ao_ctl;

   if (SWTRGEN) {
      IOREGS->AO_SWTRG.SWSTA = 1;
      IOREGS->AO_SWTRG.SWSTA = 0;
   }

   if (faoStatus->AcqMode == DAQ_ACQ_FINITE_SYNC){
      return wait_event_interruptible(daq_dev->fao_queue, faoStatus->FnState != DAQ_FN_RUNNING);
   }

   return 0;
}

//-------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------
void daq_ao_initialize_hw(daq_device_t *daq_dev)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   AO_CTL_R      ctl = {0};
   int           i;

   for (i = 0; i < AO_CHL_COUNT; ++i) {
      daq_ao_fill_chan_csr(i, shared->AoChanGain[i], &IOREGS->AO_CH[i]);
   }

   IOREGS->AO_RBSZ = AO_FIFO_SIZE - 1;
   IOREGS->AO_IE.xval   = 0;
   IOREGS->DEV_IF0.xval = AO_INT_MASK;

   IOREGS->AO_RP     = 0;
   IOREGS->AO_WP     = 0;
   IOREGS->AO_MUX    = 1;
   IOREGS->AO_SYNCEN = 0;
   IOREGS->AO_SYNCLD = 0;
   IOREGS->AO_SWTRG.SWSTAEN = 1;

   //The ConvEn and TrgEn bit must be set as 0 in SAO mode
   ctl.CCLKSRC = INTERNAL_CLOCK;
   ctl.ATRG0FN = TRG_FN_DISABLED;
   ctl.ATRG1FN = TRG_FN_DISABLED;
   ctl.DTRG0FN = TRG_FN_DISABLED;
   ctl.DTRG1FN = TRG_FN_DISABLED;
   ctl.CONVEN  = 1;
   IOREGS->AO_CTL = ctl;

   // set channel init state
   if (shared->InitOnLoad) {
      for (i = 0; i < AO_CHL_COUNT; ++i) {
         IOREGS->AO_CHDAT[i] = shared->AoChanState[i] & AO_DATA_MASK;
      }

      IOREGS->AO_SWTRG.SWSTA = 1;
      IOREGS->AO_SWTRG.SWSTA = 0;
   }
}

void daq_fao_fifo_check_work_func(struct work_struct *work)
{
   daq_device_t *daq_dev = container_of(delayed_work_ptr(work), daq_device_t, fao_fifo_chk_work);
   daq_trace(("rp:%d, wp:%d\n", IOREGS->AO_RP, IOREGS->AO_WP));
   if (IOREGS->AO_RP == IOREGS->AO_WP) {
      daq_fao_stop_acquisition(daq_dev, 0);
   }

   if (daq_dev->shared.FaoStatus.FnState == DAQ_FN_RUNNING){
      schedule_delayed_work(delayed_work_ptr(work), 1 /*jiffy*/);
   }
}

void daq_fao_stop_acquisition(daq_device_t *daq_dev, int cleanup)
{
   DEVICE_SHARED    *shared = &daq_dev->shared;
   FAO_STATUS    *faoStatus = &shared->FaoStatus;
   AO_CTL_R             ctl = {0};
   unsigned long flags;

   spin_lock_irqsave(&daq_dev->fao_lock, flags);
   if (faoStatus->FnState != DAQ_FN_RUNNING){
      spin_unlock_irqrestore(&daq_dev->fao_lock, flags);
   } else {
      faoStatus->FnState = DAQ_FN_STOPPED;
      spin_unlock_irqrestore(&daq_dev->fao_lock, flags);

      IOREGS->AO_IE.xval = 0;

      if (!shared->IsEvtSignaled[KdxAoTransStopped]) {
         shared->IsEvtSignaled[KdxAoTransStopped] = 1;
         daq_device_signal_event(daq_dev, KdxAoTransStopped);
      }

      udelay(500);

      ctl.CCLKSRC = CONV_CLK_INTERN;
      IOREGS->AO_CTL = ctl;
      IOREGS->AO_RP  = 0;
      IOREGS->AO_WP  = 0;

      if (faoStatus->AcqMode != DAQ_ACQ_INFINITE) {
         faoStatus->ReadPos = 0;
      }

      daq_device_signal_event(daq_dev,KdxAoStopped);
      wake_up_interruptible(&daq_dev->fao_queue);

      daq_trace(("Fao Stop, AO RP = %d, WP = %d, WPRunback = %d\n", 
         faoStatus->ReadPos, faoStatus->WritePos, faoStatus->WPRunBack));
   }

   // release the resource for FAO operation
   if (cleanup) {
      daq_dmem_free(&daq_dev->pdev->dev, &daq_dev->fao_dma_buf);
      daq_umem_unmap(&daq_dev->fao_buffer);

      spin_lock_irqsave(&daq_dev->fao_lock, flags);
      faoStatus->FnState = DAQ_FN_IDLE;
      spin_unlock_irqrestore(&daq_dev->fao_lock, flags);
   }
}

int daq_ioctl_ao_set_channel(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   AO_SET_CHAN   xbuf;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   if (xbuf.SetWhich & AO_SET_EXTREFUNI) {
      memcpy(&shared->AoExtRefUnipolar, &xbuf.ExtRefUnipolar, sizeof(shared->AoExtRefUnipolar));
   }
   if (xbuf.SetWhich & AO_SET_EXTREFBI) {
      memcpy(&shared->AoExtRefBipolar, &xbuf.ExtRefBipolar, sizeof(shared->AoExtRefBipolar));
   }

   if (xbuf.SetWhich & AO_SET_CHVRG){
      __u32 i, ch, gains[AO_CHL_COUNT];

      if (unlikely(shared->FaoStatus.FnState == DAQ_FN_RUNNING)){
         return -EBUSY;
      }

      if (unlikely(xbuf.ChanCount > AO_CHL_COUNT)){
         xbuf.ChanCount = AO_CHL_COUNT;
      }
      if (unlikely(copy_from_user(gains, (void *)xbuf.Gains, xbuf.ChanCount * sizeof(__u32)))){
         return -EFAULT;
      }

      for (i = 0; i < xbuf.ChanCount; ++i) {
         ch = (xbuf.ChanStart + i) & AO_CHL_MASK;
         daq_ao_fill_chan_csr(ch, gains[i], &IOREGS->AO_CH[ch]);
         shared->AoChanGain[ch] = gains[i];
      }
   }

   return 0;
}

int daq_ioctl_fao_set_param(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   FAO_CONFIG    xbuf;
   unsigned long flags;
   int           ret = 0;

   if (unlikely(copy_from_user(&xbuf, (void *)arg, sizeof(xbuf)))){
      return -EFAULT;
   }

   spin_lock_irqsave(&daq_dev->fao_lock, flags);
   if (unlikely(shared->FaoStatus.FnState != DAQ_FN_IDLE)){
      ret = -EBUSY;
   } else {
      shared->FaoParam           = xbuf;
      shared->FaoParam.ChanStart = xbuf.ChanStart & AO_CHL_MASK;
      shared->FaoParam.ChanCount = x_min(xbuf.ChanCount, (unsigned)AO_CHL_COUNT);
   }
   spin_unlock_irqrestore(&daq_dev->fao_lock, flags);

   if (likely(!ret)){
      daq_device_signal_event(daq_dev, KdxDevPropChged);
   }

   return ret;
}

int daq_ioctl_fao_set_buffer(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   FAO_CONFIG  *faoParam = &shared->FaoParam;
   FAO_STATUS *faoStatus = &shared->FaoStatus;

   unsigned long flags;
   int           ret = 0;

   if (unlikely(!faoParam->SampleCount)) {
      return -EINVAL;
   }

   spin_lock_irqsave(&daq_dev->fao_lock, flags);
   if (unlikely(faoStatus->FnState != DAQ_FN_IDLE)){
      ret = -EBUSY;
   } else {
      faoStatus->FnState  = DAQ_FN_READY;
      faoStatus->BufLength= shared->FaoParam.SampleCount;
   }
   spin_unlock_irqrestore(&daq_dev->fao_lock, flags);
   if (unlikely(ret)){
      return ret;
   }

   do {
      ret = daq_umem_map(arg, faoParam->SampleCount * AO_DATA_SIZE, 1, &daq_dev->fao_buffer);
      if (unlikely(ret)) break; 

      ret = daq_dmem_alloc(&daq_dev->pdev->dev, AO_FIFO_SIZE * AO_DATA_SIZE, &daq_dev->fao_dma_buf);
      if (unlikely(ret)) break;

   } while (0);

   if (ret){
      daq_umem_unmap(&daq_dev->fao_buffer);
      faoStatus->FnState = DAQ_FN_IDLE;
   }

   return ret;
}

int daq_ioctl_fao_start(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   unsigned long  flags;
   int            ret = 0;

   spin_lock_irqsave(&daq_dev->fao_lock, flags);
   do {
      if (shared->FaoStatus.FnState == DAQ_FN_IDLE){
         ret = -EINVAL;
         break;
      }

      if (shared->FaoStatus.FnState == DAQ_FN_RUNNING){
         ret = -EBUSY;
         break;
      }

      memset(&shared->FaoStatus, 0, sizeof(FAO_STATUS));
      shared->FaoStatus.FnState   = DAQ_FN_RUNNING;
      shared->FaoStatus.AcqMode   = (__u32)arg;
      shared->FaoStatus.BufLength = shared->FaoParam.SampleCount;
      shared->FaoStatus.WPRunBack = 1; 
   } while (0);
   spin_unlock_irqrestore(&daq_dev->fao_lock, flags);

   if (ret){
      return ret;
   }

   daq_dev->fao_stop_asap                   = 0;
   shared->IsEvtSignaled[KdxAoDataTransed]  = 0;
   shared->IsEvtSignaled[KdxAoUnderrun]     = 0;
   shared->IsEvtSignaled[KdxAoTransStopped] = 0;
   shared->IsEvtSignaled[KdxAoStopped]      = 0;
   shared->IsEvtSignaled[KdxAoCacheEmptied] = 0;

   daq_device_clear_event(daq_dev, KdxAoDataTransed);
   daq_device_clear_event(daq_dev, KdxAoUnderrun);
   daq_device_clear_event(daq_dev, KdxAoTransStopped);
   daq_device_clear_event(daq_dev, KdxAoStopped);
   daq_device_clear_event(daq_dev, KdxAoCacheEmptied);

   daq_ao_init_rbuf(daq_dev);
   ret = daq_fao_start_hardware(daq_dev);

   return ret;
}

int daq_ioctl_fao_stop(daq_device_t *daq_dev, unsigned long arg)
{
   DEVICE_SHARED *shared = &daq_dev->shared;
   daq_trace(("daq_ioctl_fao_stop\n"));
   if (shared->FaoStatus.FnState == DAQ_FN_IDLE){
      return 0;
   }

   daq_trace(("daq_ioctl_fao_stop: 0x%x\n", (unsigned)arg));
   if (arg & FAO_STOP_FREE_RES){
      daq_fao_stop_acquisition(daq_dev, 1);
      return 0;
   }

   if (arg & FAO_STOP_BREAK_NOW){
      daq_fao_stop_acquisition(daq_dev, 0);
      return 0;
   }

   if (shared->FaoStatus.AcqMode == DAQ_ACQ_INFINITE) {
      daq_trace(("set fao stop asap\n"));
      daq_dev->fao_stop_asap = 1;
   }

   return 0;
}


