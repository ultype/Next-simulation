/*
 * hw.h
 *
 *  Created on: 2011-10-19
 *      Author: rocky
 */

#ifndef _KERNEL_MODULE_HW_H_
#define _KERNEL_MODULE_HW_H_

// interrupt control & status register
#define INT_DISABLED          0
#define INT_SRC_DI            1
#define INT_SRC_DI_WITH_GATE  2

#define TRIG_EDGE_RISING      1  // rising edge. note: this is the device specified value.
#define TRIG_EDGE_FALLING     0  // falling edge. note: this is the device specified value.

// USB HW Event type: 0 for SYS event, 1 for DI0, and 2 for DI8.
enum FW_EVENT_TYPE {
   FWEvtDIIntr0 = 1,
   FWEvtDIIntr8 = 2,
   FWEVT_TYPE_COUNT
};

typedef struct _EE_WRITE
{
   __u16 Data;
   __u16 Addr;
}EE_WRITE;

#define MAX_EVT_NUM_IN_FIFO 20
typedef struct _EVENT_DATA
{
   __u8 EventType;
   __u8 PortData[2];
}EVENT_DATA;

typedef struct _FW_EVENT_FIFO
{
   __u16      EventCount;
   __u8       IsEmpty;
   __u8       IsOverRun;
   EVENT_DATA EventData[MAX_EVT_NUM_IN_FIFO];
}FW_EVENT_FIFO;

#endif /* _KERNEL_MODULE_HW_H_ */
