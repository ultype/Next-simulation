/*
 * kshared.h
 *
 *  Created on: 2011-8-30
 *      Author: rocky
 */

#ifndef KERNEL_MODULE_SHARED_H_
#define KERNEL_MODULE_SHARED_H_

#include <linux/types.h>


#define ADVANTECH_VID 0x1809
#define DEVICE_ID  	 0x4750
#define DEVICE_PID    BD_USB4750
#define DEVICE_NAME   "USB-4750"
#define DRIVER_NAME   "bio4750"

// ----------------------------------------------------------
// H/W feature and structures.
// ----------------------------------------------------------
#define DIO_PORT_COUNT           2  // 2 DI, 2 DO
#define DIO_CHL_COUNT            (DIO_PORT_COUNT * 8)
#define DI_INT_SRC_COUNT         2  // CH#000 & CH#008
#define DI_INT_SRC_CTL_MASK      0x0303
#define DI_SNAP_SRC_COUNT        DI_INT_SRC_COUNT

#define CNTR_CHL_COUNT           2
#define CNTR_RES_IN_BIT          32
#define CNTR_DATA_SIZE           sizeof(__u32)
#define CNTR_IDLE                0

#define CNTR_RBUF_DEPTH          16
#define CNTR_RBUF_POSMASK        (CNTR_RBUF_DEPTH -1)
#define CNTR_CHK_PERIOD_NS       10000000UL
#define CNTR_CHK_PERIOD_MAX_NS   625000000UL  // 10000000000UL >> 4
#define CNTR_VAL_THRESHOLD_BASE  10

enum KRNL_EVENT_IDX{
   KdxDevPropChged = 0,
   KdxDiBegin,
   KdxDiintChan0 = KdxDiBegin,
   KdxDiintChan8,
   KdxDiEnd      = KdxDiintChan8,
   KrnlSptedEventCount,
};

static inline __u32 GetEventKIndex(__u32 eventType)
{
   __u32 kdx;
   switch ( eventType )
   {
   case EvtPropertyChanged: kdx = KdxDevPropChged; break;
   case EvtDiintChannel000: kdx = KdxDiintChan0; break;
   case EvtDiintChannel008: kdx = KdxDiintChan8; break;
   default: kdx = -1; break;
   }
   return kdx;
}

// -----------------------------------------------------
// default values
// -----------------------------------------------------
#define DEF_INIT_ON_LOAD        1

// DIO default values
#define DEF_DO_STATE            0x0
#define DEF_DI_INT_TRIGEDGE     RisingEdge
#define DEF_DI_INT_GATECTRL     0

#define DEF_CNTR_FM_PERIOD      0

// ----------------------------------------------------------
// Device private data
// ----------------------------------------------------------
typedef struct _DI_SNAP_CONFIG
{
   __u8 PortStart;
   __u8 PortCount;
} DI_SNAP_CONFIG;

typedef struct _DI_SNAP_STATE
{
   __u8 State[DIO_PORT_COUNT];
} DI_SNAP_STATE;

typedef struct _CNTR_CONFIG
{
   __u32 FmPeroid[CNTR_CHL_COUNT];
}CNTR_CONFIG;

typedef struct _CNTR_STATE
{
   __u32     Operation;
   __u32     CanRead;
   __u32     AutoAdaptive;

   // ------------------------------------------
   __u32     CheckPeriod;
   __u32     PrevValue;
   __u32     SummedValue;
   __s64     PrevTime;
   __u64     TotalTime;
   struct  {
      __u32  Head;
      __u32  Tail;
      __u32  CntrDelta[CNTR_RBUF_DEPTH];
      __u32  TimeDelta[CNTR_RBUF_DEPTH];
   };
}CNTR_STATE;

typedef struct _DEVICE_SHARED
{
   __u32          Size;           // Size of the structure
   __u32          ProductId;      // Device Type
   __u32          DeviceNumber;   // Zero-based device number

   // HW Information
   __u32          BoardId;        // Board dip switch number for the device
   __u32          InitOnLoad;

   // --------------------------------------------------------
   __u8           DiintTrigEdge[DI_INT_SRC_COUNT];
   __u8           DiintGateCtrl[DI_INT_SRC_COUNT];
   __u8           DoPortState[DIO_PORT_COUNT];
   DI_SNAP_CONFIG DiSnapParam[DI_SNAP_SRC_COUNT];
   DI_SNAP_STATE  DiSnapState[DI_SNAP_SRC_COUNT];

   // ---------------------------------------------------------
   CNTR_CONFIG    CntrConfig;
   CNTR_STATE     CntrState[CNTR_CHL_COUNT];
   __u32          CntrChkTimerOwner;

   // ---------------------------------------------------------
   __u32          IntCsr;
   __u32          IsEvtSignaled[KrnlSptedEventCount];

} DEVICE_SHARED;

#endif /* KERNEL_MODULE_SHARED_H_ */
