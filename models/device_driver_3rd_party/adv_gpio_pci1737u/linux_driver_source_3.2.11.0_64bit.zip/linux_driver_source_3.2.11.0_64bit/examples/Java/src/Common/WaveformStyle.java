package Common;

public enum WaveformStyle { 
	sine, 
	square,
	triangle
}