package Counter_ContinueCompare;

import java.awt.BorderLayout;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Automation.BDaq.*;

//import org.eclipse.wb.swing.FocusTraversalOnArray;
//import java.awt.Component;

public class ConfigureDialog extends JDialog {
	// define the serialization number.
	private static final long serialVersionUID = 1L;
	
	private final JPanel contentPanel = new JPanel();
	private JComboBox cmbDevice;
	private JComboBox cmbChannel;
	private JComboBox cmbCountingType;
	private JButton btnOK;
	
	public boolean isFirstLoad = true;

	/**
	 * 
	 * Build Date:2011-10-12
	 * Author:Administrator
	 * Function Description: Create the dialog.
	 */
	public ConfigureDialog(ContinueCompare parrent) {
		super(parrent);
		// Add window close action listener.
		addWindowListener(new WindowCloseActionListener());
		
		setTitle("Continue Compare - Configuration");
		setResizable(false);
		setBounds(100, 100, 359, 191);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(SystemColor.control);
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);		

		JLabel lblNewLabel = new JLabel("Device:");
		lblNewLabel.setBounds(23, 20, 80, 15);
		contentPanel.add(lblNewLabel);

		JLabel lblChannelStart = new JLabel("Counter channel:");
		lblChannelStart.setBounds(23, 55, 107, 15);
		contentPanel.add(lblChannelStart);
		
		cmbDevice = new JComboBox();
		cmbDevice.addItemListener(new ComboBoxDiveceItemListener());
		cmbDevice.setBounds(130, 17, 200, 21);
		contentPanel.add(cmbDevice);
		
		cmbChannel = new JComboBox();
		cmbChannel.setBounds(130, 52, 200, 21);
		contentPanel.add(cmbChannel);
		
		btnOK = new JButton("OK");
		btnOK.addActionListener(new ButtonOKActionListener());
		btnOK.setBounds(152, 125, 75, 23);
		getRootPane().setDefaultButton(btnOK);
		contentPanel.add(btnOK);

		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ButtonCancelActionListener());
		btnCancel.setBounds(255, 125, 75, 23);
		contentPanel.add(btnCancel);
		
		JLabel lblCountingType = new JLabel("Counting type:");
		lblCountingType.setBounds(23, 87, 107, 15);
		contentPanel.add(lblCountingType);
		
		cmbCountingType = new JComboBox();
		cmbCountingType.setBounds(130, 84, 200, 21);
		contentPanel.add(cmbCountingType);
		
		Initialization();
	}
	
	/**
	 * 
	 * Build Date:2011-10-12
	 * Author:Administrator
	 * Function Description: This function is used to initialize the Configuration dialog.
	 */
	protected void Initialization() {
		UdCounterCtrl udCounterCtrl = new UdCounterCtrl();
		ArrayList<DeviceTreeNode> installedDevice = udCounterCtrl.getSupportedDevices();

		if (installedDevice.size() <= 0) {
			ShowMessage("No device to support the currently demonstrated function!");
			System.exit(0);
		} else {
			for (DeviceTreeNode installed : installedDevice) {
				cmbDevice.addItem(installed.toString());
			}
			cmbDevice.setSelectedIndex(0);
		}
	}
	
	/**
	 * 
	 * Build Date:2011-10-12
	 * Author:Administrator
	 * Function Description: If some errors occurred, Show the error code to the users.
	 * 
	 * @param message:the message shown to users!
	 */
	protected void ShowMessage(String message) {
		JOptionPane.showMessageDialog(this, message, "Warning MessageBox",
				JOptionPane.WARNING_MESSAGE);
	}
	
	/**
	 * 
	 * @author Administrator
	 * Class Function Description: This class is used to listen the device comboBox's
	 * 							   item selected changing action! 
	 */
	class ComboBoxDiveceItemListener implements ItemListener{
		public void itemStateChanged(ItemEvent e) {
			String selected = ((JComboBox) e.getSource()).getSelectedItem().toString();
			if (e.getStateChange() == ItemEvent.SELECTED) {
				btnOK.setEnabled(true);
				try {
					
					// Set channel start combo box
					UdCounterCtrl udCounterCtrl = new UdCounterCtrl();
					udCounterCtrl.setSelectedDevice(new DeviceInformation(selected));
					int channelCountMax = udCounterCtrl.getFeatures().getChannelCountMax();
					CounterCapabilityIndexer capabilityIndexer = udCounterCtrl.getFeatures().getCapabilities();
					
					for(int i = 0; i < channelCountMax; i++){
						CounterCapability[] capability = capabilityIndexer.valueOf(i);
						for(CounterCapability cap : capability){
							if(cap == CounterCapability.UpDownCount){
								cmbChannel.addItem(String.valueOf(i));
							}
						}
					}
					cmbChannel.setSelectedIndex(0);
					
					//Set Counting type for selected device
					int cntTypeCount = udCounterCtrl.getFeatures().getCountingTypes().length;
					SignalCountingType[] countingType = udCounterCtrl.getFeatures().getCountingTypes();
					for (int i = 0; i < cntTypeCount; i++) {
						cmbCountingType.addItem(countingType[i]);
					}
					cmbCountingType.setSelectedIndex(0);
								
					udCounterCtrl.Cleanup();
				}catch (Exception except) {
					ShowMessage("Sorry, there're some errors occured: " + except.toString());
					btnOK.setEnabled(false);
					return;
				}
			}else{
				cmbChannel.removeAllItems();
				cmbCountingType.removeAllItems();
				return;
			}
		}
	}
	
	/**
	 * 
	 * @author Administrator
	 * Class Function Description: This class is used to listen the OK button's action! 
	 */
	class ButtonOKActionListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0) {
			ContinueCompare parrent = (ContinueCompare)getParent();
			parrent.configure.deviceName = cmbDevice.getSelectedItem().toString();
			parrent.configure.counterChannel = Integer.parseInt(cmbChannel.getSelectedItem().toString());
			parrent.configure.cntType = (SignalCountingType) cmbCountingType.getSelectedItem();
			
			parrent.Initialization();
			parrent.setVisible(true);
			setVisible(false);
		}
	}
	
	/**
	 * 
	 * @author Administrator
	 * Class Function Description: This class is used to listen the Cancel button's action! 
	 */
	class ButtonCancelActionListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0) {
			if (isFirstLoad) {
				System.exit(0);
			} else {
				setVisible(false);
			}
		}
	}

	/**
	 * 
	 * @author Administrator
	 * Class Function Description: This class is used to listen the configure dialog's closing event.
	 */
	class WindowCloseActionListener extends WindowAdapter{
		@Override
		public void windowClosing(WindowEvent e) {
			if (isFirstLoad) {
				System.exit(0);
			}
		}
	}
}
