package AI_AsynOneBufferedAI_TDtp;

import java.awt.BorderLayout;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.text.NumberFormat;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.eclipse.wb.swing.FocusTraversalOnArray;

import Automation.BDaq.*;
import Common.*;

import java.text.Format;
import java.awt.Panel;
import java.awt.Component;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

public class ConfigureDialog extends JDialog {

	// define the serialization number.
	private static final long serialVersionUID = 1L;

	private final JPanel contentPanel = new JPanel();
	
	private JFormattedTextField txtDataCountPerChan;
	private JFormattedTextField txtClockRatePerChan;
	private JComboBox cmbDevice;
	private JComboBox cmbChannelStart;
	private JComboBox cmbChannelCount;
	private JComboBox cmbValueRange;
	private JComboBox cmbTriggerSource;
	private JComboBox cmbTriggerEdge;
	private JFormattedTextField txtTriggerLevel;
	private JFormattedTextField txtDelayCount;
	
	private JComboBox cmbTriggerIndex;
	
	private JButton btnOK;
	
	BufferedAiCtrl bufferedAiCtrl = new BufferedAiCtrl();

	public boolean isFirstLoad = true;
	private boolean isTriggerSupported = false;
	private boolean isTrigger1Supported = false;

	public void DeviceChanged(String deviceDescription)
	{
		try {
			bufferedAiCtrl.setSelectedDevice(new DeviceInformation(deviceDescription));
			AiFeatures feature = bufferedAiCtrl.getFeatures();

			/**
			 * Note that: as a demo, We needn't draw to much channels in one graph, 
			 * So we define the channel count as an integer less than 16.
			 */
			int channelCount = bufferedAiCtrl.getChannelCount();
			if (channelCount > 16) {
				channelCount = 16;
			}
			cmbChannelStart.removeAllItems();
			for(int i = 0; i < feature.getChannelCountMax(); i++){
				cmbChannelStart.addItem(i);
			}
			cmbChannelCount.removeAllItems();
			for (int i = 1; i <= channelCount; i++) {
				cmbChannelCount.addItem(i);
			}
			
			ValueRange[] value = feature.getValueRanges();
			StringBuffer description = new StringBuffer(BDaqApi.VALUE_RANGE_DESC_MAX_LEN);
			MathInterval range = new MathInterval();
			IntByRef unitIndex = new IntByRef();
			cmbValueRange.removeAllItems();
			for (ValueRange i : value) {
				BDaqApi.AdxGetValueRangeInformation(i.toInt(), description, range, unitIndex);
				
				//we filter the celsius degree for the buffered AI cann't support this function.
				if(Global.toValueUnit(unitIndex.value) == ValueUnit.CelsiusUnit){
					continue;
				}
				cmbValueRange.addItem(i);
			}

			isTriggerSupported = bufferedAiCtrl.getFeatures().getTriggerSupported();
			
			cmbTriggerSource.setEnabled(isTriggerSupported);
			txtDelayCount.setEnabled(isTriggerSupported);
			txtTriggerLevel.setEnabled(isTriggerSupported);

			cmbTriggerEdge.setEnabled(isTriggerSupported);
			cmbTriggerIndex.setEnabled(isTriggerSupported);
			
			isTrigger1Supported = bufferedAiCtrl.getFeatures().getTrigger1Supported();
				
			cmbTriggerIndex.removeAllItems();
			if(bufferedAiCtrl.getFeatures().getTriggerSupported())
			{
				cmbTriggerIndex.addItem(new String("Trigger0"));
				cmbTriggerIndex.setSelectedIndex(0);
			}
			 
			if(bufferedAiCtrl.getFeatures().getTriggerSupported())
			{
				cmbTriggerIndex.addItem(new String("Trigger1"));
			}
			
			
			if (isTriggerSupported) {
				// Initialize trigger parameter: trigger source.
			    SignalDrop[] source = bufferedAiCtrl.getFeatures().getTriggerSources();
			    cmbTriggerSource.removeAllItems();
				if (source != null) {
					for (int i = 0; i < source.length; i++) {
						cmbTriggerSource.addItem(source[i]);
					}
				}

				// Initialize trigger parameter: trigger edge.
				cmbTriggerEdge.removeAllItems();
				cmbTriggerEdge.addItem(ActiveSignal.RisingEdge);
				cmbTriggerEdge.addItem(ActiveSignal.FallingEdge);

				// set the initialized position of the comboBox;
				cmbTriggerSource.setSelectedIndex(0);
				cmbTriggerEdge.setSelectedIndex(0);
			}else{
				cmbTriggerSource.removeAllItems();
				cmbTriggerEdge.removeAllItems();
				txtDelayCount.setValue(new Integer(1000));
				txtTriggerLevel.setValue(new Double(3.0));
			}
			

			
			cmbChannelStart.setSelectedIndex(0);
			cmbChannelCount.setSelectedIndex(2);
			cmbValueRange.setSelectedIndex(0);
		} catch (Exception except) {
			ShowMessage("Sorry, there'r some errors occured: " + except.toString());
			btnOK.setEnabled(false);
			return;
		}
		TriggerSourceChanged();
	}
	
	public void TriggerSourceChanged()
	{
		SignalDrop selectedItem = (SignalDrop)cmbTriggerSource.getSelectedItem();
		switch(selectedItem){
			case SignalNone:{
				txtTriggerLevel.setEnabled(false);
				txtDelayCount.setEnabled(false);
				cmbTriggerEdge.setEnabled(false);
			}break;
			case SigExtDigClock:
			case SigExtDigTrigger0:
			case SigExtDigTrigger1:
			case SigExtDigTrigger2:
			case SigExtDigTrigger3:{
				txtTriggerLevel.setEnabled(false);
				txtDelayCount.setEnabled(true);
				cmbTriggerEdge.setEnabled(true);
			}break;
			default:{
				txtTriggerLevel.setEnabled(true);
				txtDelayCount.setEnabled(true);
				cmbTriggerEdge.setEnabled(true);					
			}break;
		}
	}
	/**
	 * Create the dialog.
	 */
	public ConfigureDialog(AsynOneBufferedAI_TDtp parrent) {
		super(parrent);
		// Add window close action listener.
		addWindowListener(new WindowCloseActionListener());

		setTitle("Asynchronous One Buffered AI with Trigger Delay to Stop - Configuration");
		
		setResizable(false);
		setBounds(200, 200, 581, 337);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(SystemColor.control);
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Device:");
		lblNewLabel.setBounds(33, 37, 57, 15);
		contentPanel.add(lblNewLabel);	
		
		cmbDevice = new JComboBox();
		cmbDevice.addItemListener(new ComboBoxDeviceItemListener());
		cmbDevice.setBounds(104, 34, 448, 21);
		contentPanel.add(cmbDevice);
		
		btnOK = new JButton("OK");
		btnOK.addActionListener(new ButtonOKActionListener());
		btnOK.setBounds(377, 275, 75, 23);
		//getRootPane().setDefaultButton(btnOK);
		contentPanel.add(btnOK);

		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ButtonCancelActionListener());
		btnCancel.setBounds(479, 275, 75, 23);
		contentPanel.add(btnCancel);

		//getContentPane().setFocusTraversalPolicy( new FocusTraversalOnArray(new Component[] { cmbDevice, btnOK, btnCancel }));
		
		JPanel pnlParameter = new JPanel();
		pnlParameter.setBackground(SystemColor.control);
		pnlParameter.setBounds(23, 74, 250, 190);
		pnlParameter.setBorder(BorderFactory.createTitledBorder("Buffered AI general setting"));
		contentPanel.add(pnlParameter);
		pnlParameter.setLayout(null);

		JLabel lblChannelStart = new JLabel("Channel start:");
		lblChannelStart.setBounds(10, 26, 95, 15);
		pnlParameter.add(lblChannelStart);
		
		cmbChannelStart = new JComboBox();
		cmbChannelStart.setBounds(103, 23, 118, 21);
		pnlParameter.add(cmbChannelStart);

		JLabel lblChannelCount = new JLabel("Channel count:");
		lblChannelCount.setBounds(10, 60, 95, 15);
		pnlParameter.add(lblChannelCount);

		cmbChannelCount = new JComboBox();
		cmbChannelCount.setBounds(103, 57, 118, 21);
		pnlParameter.add(cmbChannelCount);
	
		JLabel lblValueRange = new JLabel("Value range:");
		lblValueRange.setBounds(10, 92, 95, 15);
		pnlParameter.add(lblValueRange);
		
		cmbValueRange = new JComboBox();
		cmbValueRange.setBounds(103, 89, 118, 21);
		pnlParameter.add(cmbValueRange);
		
		JLabel lblClockRatePerchannel = new JLabel("Clock rate:");
		lblClockRatePerchannel.setBounds(10, 156, 95, 15);
		pnlParameter.add(lblClockRatePerchannel);
		
		txtClockRatePerChan = new JFormattedTextField(NumberFormat.getNumberInstance());
		txtClockRatePerChan.setBounds(103, 153, 118, 21);
		pnlParameter.add(txtClockRatePerChan);
		txtClockRatePerChan.setValue(new Double(1000));
		txtClockRatePerChan.setColumns(10);

		JLabel lblNewLabel_2 = new JLabel("Hz");
		lblNewLabel_2.setBounds(231, 156, 22, 15);
		pnlParameter.add(lblNewLabel_2);
		
		JLabel lblDataCountPerchannel = new JLabel("Samples:");
		lblDataCountPerchannel.setBounds(10, 121, 95, 15);
		pnlParameter.add(lblDataCountPerchannel);

		txtDataCountPerChan = new JFormattedTextField(NumberFormat.getIntegerInstance());
		txtDataCountPerChan.setBounds(103, 121, 118, 21);
		pnlParameter.add(txtDataCountPerChan);
		txtDataCountPerChan.setValue(new Integer(1024));
		txtDataCountPerChan.setColumns(10);

		//pnlParameter.setFocusTraversalPolicy(new FocusTraversalOnArray(new Component[]{cmbChannelStart, cmbChannelCount, cmbValueRange, txtDataCountPerChan,txtClockRatePerChan}));
		
		JPanel pnlTriggerParameter = new JPanel();
		pnlTriggerParameter.setBackground(SystemColor.control);
		pnlTriggerParameter.setBounds(285, 74, 280, 190);
		pnlTriggerParameter.setBorder(BorderFactory.createTitledBorder("Trigger settings"));
		contentPanel.add(pnlTriggerParameter);
		pnlTriggerParameter.setLayout(null);
		
		JLabel lblSource = new JLabel("Source:");
		lblSource.setBounds(10, 60, 89, 15);
		pnlTriggerParameter.add(lblSource);
		
		cmbTriggerSource = new JComboBox();
		cmbTriggerSource.addItemListener(new ComboBoxTriggerSourceListener());
		lblSource.setLabelFor(cmbTriggerSource);
		cmbTriggerSource.setBounds(98, 57, 150, 21);
		pnlTriggerParameter.add(cmbTriggerSource);
		
		JLabel lblDelayCount = new JLabel("Delay count:");
		lblDelayCount.setBounds(10, 121, 89, 15);
		pnlTriggerParameter.add(lblDelayCount);
		
		txtDelayCount = new JFormattedTextField(NumberFormat.getIntegerInstance());
		txtDelayCount.setValue(new Integer(1000));
		lblDelayCount.setLabelFor(txtDelayCount);
		txtDelayCount.setBounds(98, 121, 150, 21);
		pnlTriggerParameter.add(txtDelayCount);
		
		JLabel lblLevel = new JLabel("Trigger level:");
		lblLevel.setBounds(10, 156, 89, 15);
		pnlTriggerParameter.add(lblLevel);
		
		txtTriggerLevel = new JFormattedTextField(NumberFormat.getNumberInstance());
		txtTriggerLevel.setValue(new Double(3.0));
		txtTriggerLevel.addPropertyChangeListener(new TriggerLevelListener());
		lblLevel.setLabelFor(txtTriggerLevel);
		txtTriggerLevel.setBounds(98, 153, 150, 21);
		pnlTriggerParameter.add(txtTriggerLevel);
		
		JLabel lblEdge = new JLabel("Edge:");
		lblEdge.setBounds(10, 92, 89, 15);
		pnlTriggerParameter.add(lblEdge);
		
		cmbTriggerEdge = new JComboBox();
		lblEdge.setLabelFor(cmbTriggerEdge);
		cmbTriggerEdge.setBounds(98, 89, 150, 21);
		pnlTriggerParameter.add(cmbTriggerEdge);
		
		JLabel lblNewLabel_1 = new JLabel("V");
		lblNewLabel_1.setBounds(253, 156, 17, 15);
		pnlTriggerParameter.add(lblNewLabel_1);
		
		JLabel lblTrigger = new JLabel("Trigger:");
		lblTrigger.setBounds(10, 26, 89, 15);
		pnlTriggerParameter.add(lblTrigger);
		
		cmbTriggerIndex = new JComboBox();
		cmbTriggerIndex.setBounds(98, 23, 150, 21);
		pnlTriggerParameter.add(cmbTriggerIndex);
		cmbTriggerIndex.addItemListener(new ComboBoxTriggerIndexListener());

		Initialization();
	}
	/**
	 * 
	 *Build Date:2012-3-13
	 *Author:Administrator
	 *Function Description: Initialize the configuration dialog.
	 */
	protected void Initialization() {
		ArrayList<DeviceTreeNode> installedDevice = bufferedAiCtrl.getSupportedDevices();
		if (installedDevice.size() <= 0) {
			ShowMessage("No device to support the currently demonstrated function!");
			System.exit(0);
		} else {
			for (DeviceTreeNode installed : installedDevice) {
				cmbDevice.addItem(installed.toString());
			}
		}
		
		cmbDevice.setSelectedIndex(0);
	}
	
	/**
	 *Build Date:2012-3-13
	 *Author:Administrator
	 *Function Description: load the configuration parameters. 
	 */
	public void LoadConfiguration(ConfigureParameter config){
		cmbChannelStart.setSelectedItem(config.channelStart);
		cmbChannelCount.setSelectedItem(config.channelCount);
		cmbValueRange.setSelectedItem(config.valueRange);
		txtClockRatePerChan.setValue(config.clockRatePerChan);
		txtDataCountPerChan.setValue(config.dataCountPerChan);
	}
	
	/**
	 * 
	 *Build Date:2012-3-13
	 *Author:Administrator
	 *Function Description: Show the message for users.
	 * @param message: the text message
	 */
	protected void ShowMessage(String message) {
		JOptionPane.showMessageDialog(this, message, "Warning MessageBox",
				JOptionPane.WARNING_MESSAGE);
	}
	
	/**
	 * 
	 * @author Administrator
	 * Class Function Description: This class is used to listen the comboBox device's items
	 * 						 	   selecting changed action.
	 */
	class ComboBoxDeviceItemListener implements ItemListener{
		public void itemStateChanged(ItemEvent e) {
			String selected = ((JComboBox) e.getSource()).getSelectedItem().toString();
			if (e.getStateChange() == ItemEvent.SELECTED) {
				btnOK.setEnabled(true);
				DeviceChanged(selected);
			} else {
				cmbChannelCount.removeAllItems();
				cmbChannelStart.removeAllItems();
				cmbValueRange.removeAllItems();
				cmbTriggerSource.removeAllItems();
				cmbTriggerEdge.removeAllItems();
			}
		}
	}
	
	/**
	 * 
	 * @author Administrator
	 *Class Function Description: This class is used to listen the comboBox trigger source's items
	 *							  selecting changed action.
	 */
	class ComboBoxTriggerSourceListener implements ItemListener{

		@Override
		public void itemStateChanged(ItemEvent e) {
			if(e.getStateChange() == ItemEvent.SELECTED){
				TriggerSourceChanged();
			}
		}
	}
	
	/**
	 * 
	 * @author Administrator
	 *Class Function Description: This class is used to listen the comboBox trigger source's items
	 *							  selecting changed action.
	 */
	class ComboBoxTriggerIndexListener implements ItemListener{

		@Override
		public void itemStateChanged(ItemEvent e) {
			int  index = cmbTriggerIndex.getSelectedIndex();
			String selected = cmbDevice.getSelectedItem().toString();
			if(e.getStateChange() == ItemEvent.SELECTED){
				try {
					bufferedAiCtrl.setSelectedDevice(new DeviceInformation(selected));
					AiFeatures feature = bufferedAiCtrl.getFeatures();
					cmbTriggerSource.removeAllItems();
					if(index == 0)
					{
						// Initialize trigger parameter: trigger source.
						cmbTriggerSource.removeAllItems();
 						SignalDrop[] source = bufferedAiCtrl.getFeatures().getTriggerSources();
						if (source != null) {
							for (int i = 0; i < source.length; i++) {
								cmbTriggerSource.addItem(source[i]);
							}
						}
						SignalDrop src = bufferedAiCtrl.getTrigger().getSource();
						for(int j =0; j < cmbTriggerSource.getItemCount(); ++j)
						{
						   if(src == cmbTriggerSource.getItemAt(j))
						   {
							   cmbTriggerSource.setSelectedIndex(j);
						   }
						}

						// Initialize trigger parameter: trigger edge.
						cmbTriggerEdge.removeAllItems();
						cmbTriggerEdge.addItem(ActiveSignal.RisingEdge);
						cmbTriggerEdge.addItem(ActiveSignal.FallingEdge);
						ActiveSignal edge = bufferedAiCtrl.getTrigger().getEdge();
						if(edge == ActiveSignal.RisingEdge){
							cmbTriggerEdge.setSelectedIndex(0);
						}else if(edge == ActiveSignal.FallingEdge){
							cmbTriggerEdge.setSelectedIndex(1);
						}
						
						txtDelayCount.setValue(bufferedAiCtrl.getTrigger().getDelayCount());
						txtTriggerLevel.setValue(bufferedAiCtrl.getTrigger().getLevel());
					}else if(index == 1){
					
						// Initialize trigger parameter: trigger source.
						cmbTriggerSource.removeAllItems();
 						SignalDrop[] source = bufferedAiCtrl.getFeatures().getTrigger1Sources();
						if (source != null) {
							for (int i = 0; i < source.length; i++) {
								cmbTriggerSource.addItem(source[i]);
							}
						}
						SignalDrop src = bufferedAiCtrl.getTrigger1().getSource();
						for(int j =0; j < cmbTriggerSource.getItemCount(); ++j)
						{
						   if(src == cmbTriggerSource.getItemAt(j))
						   {
							   cmbTriggerSource.setSelectedIndex(j);
						   }
						}

						// Initialize trigger parameter: trigger edge.
						cmbTriggerEdge.removeAllItems();
						cmbTriggerEdge.addItem(ActiveSignal.RisingEdge);
						cmbTriggerEdge.addItem(ActiveSignal.FallingEdge);
						ActiveSignal edge = bufferedAiCtrl.getTrigger1().getEdge();
						if(edge == ActiveSignal.RisingEdge){
							cmbTriggerEdge.setSelectedIndex(0);
						}else if(edge == ActiveSignal.FallingEdge){
							cmbTriggerEdge.setSelectedIndex(1);
						}
						
						txtDelayCount.setValue(bufferedAiCtrl.getTrigger1().getDelayCount());
						txtTriggerLevel.setValue(bufferedAiCtrl.getTrigger1().getLevel());
					}
			    } catch (Exception except) {
					ShowMessage("Sorry, there'r some errors occured: " + except.toString());
					btnOK.setEnabled(false);
					return;
			    }
			}
		
		}
	}
	
	/**
	 * 
	 * @author Administrator
	 * Class Function Description: This class is used to listen the OK button's action. 
	 */
	class ButtonOKActionListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0) {
			AsynOneBufferedAI_TDtp parent = (AsynOneBufferedAI_TDtp)getParent();
			int dataCountPerChan = ((Number) txtDataCountPerChan.getValue()).intValue();
			double clockRatePerChan = ((Number) txtClockRatePerChan.getValue()).doubleValue();

			if(dataCountPerChan < 1 || dataCountPerChan > 10000000 ){
				ShowMessage("The samples per channel is invalid");
				return;
			}
			
			if(clockRatePerChan <= 0 ){
				ShowMessage("The clock rate per channel is invalid");
				return;
			}

			parent.configure.deviceName = cmbDevice.getSelectedItem().toString();
			parent.configure.channelStart = cmbChannelStart.getSelectedIndex();
			// We plus 1 because the index of comboBox's selected item is start with 0.
			parent.configure.channelCount = cmbChannelCount.getSelectedIndex() + 1;
			parent.configure.valueRange = (ValueRange) cmbValueRange.getSelectedItem();
			parent.configure.dataCountPerChan = dataCountPerChan;
			parent.configure.clockRatePerChan = clockRatePerChan;

			parent.configure.TriggerIndex = cmbTriggerIndex.getSelectedIndex();
			if (isTriggerSupported && cmbTriggerIndex.getSelectedIndex() == 0) {
				long delayCount = ((Number) txtDelayCount.getValue()).longValue();
				double triggerLevel = ((Number) txtTriggerLevel.getValue()).doubleValue();
				SignalDrop selectedItem = (SignalDrop)cmbTriggerSource.getSelectedItem();
				
				MathInterval delayCountRange = bufferedAiCtrl.getFeatures().getTriggerDelayRange();
				SamplingMethod method = bufferedAiCtrl.getFeatures().getSamplingMethod();
				int channelCount = 1;
				if(method == SamplingMethod.EqualTimeSwitch){
					channelCount = cmbChannelCount.getSelectedIndex() + 1;
				}else{
					channelCount = 1;
				}
				if(delayCount < 0 || delayCount > delayCountRange.Max / channelCount){
					ShowMessage("The trigger delay count range from 0 to " + delayCountRange.Max
							/ channelCount);
					return;
				}
				
				if(delayCount >= dataCountPerChan && selectedItem != SignalDrop.SignalNone){
					ShowMessage("Delay count must smaller than samples per channel!");
					return;
				}
				
				parent.configure.triggerAction = TriggerAction.DelayToStop;
				parent.configure.triggerSource = (SignalDrop) cmbTriggerSource.getSelectedItem();
				parent.configure.delayCount = delayCount;
				parent.configure.triggerLevel = triggerLevel;
				parent.configure.triggerEdge = (ActiveSignal) cmbTriggerEdge.getSelectedItem();
			}

			if (isTrigger1Supported && cmbTriggerIndex.getSelectedIndex() == 1) {
				long delayCount = ((Number) txtDelayCount.getValue()).longValue();
				double triggerLevel = ((Number) txtTriggerLevel.getValue()).doubleValue();
				SignalDrop selectedItem = (SignalDrop)cmbTriggerSource.getSelectedItem();
				
				MathInterval delayCountRange = bufferedAiCtrl.getFeatures().getTrigger1DelayRange();
				SamplingMethod method = bufferedAiCtrl.getFeatures().getSamplingMethod();
				int channelCount = 1;
				if(method == SamplingMethod.EqualTimeSwitch){
					channelCount = cmbChannelCount.getSelectedIndex() + 1;
				}else{
					channelCount = 1;
				}
				if(delayCount < 0 || delayCount > delayCountRange.Max / channelCount){
					ShowMessage("The trigger1 delay count range from 0 to " + delayCountRange.Max
							/ channelCount);
					return;
				}
				
				if(delayCount >= dataCountPerChan && selectedItem != SignalDrop.SignalNone){
					ShowMessage("Delay count must smaller than samples per channel!");
					return;
				}
				
				parent.configure.triggerAction = TriggerAction.DelayToStop;
				parent.configure.triggerSource = (SignalDrop) cmbTriggerSource.getSelectedItem();
				parent.configure.delayCount = delayCount;
				parent.configure.triggerLevel = triggerLevel;
				parent.configure.triggerEdge = (ActiveSignal) cmbTriggerEdge.getSelectedItem();
			}

			parent.Initialization();
			parent.setVisible(true);

			setVisible(false);
		}
	}
	
	/**
	 * 
	 * @author Administrator
	 * Class Function Description: This class is used to listen the Cancel button's action
	 */
	class ButtonCancelActionListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			if(isFirstLoad ){
				System.exit(0);
			}else{
				setVisible(false);
			}
		}
	}
	
	/**
	 * * 
	 * @author Administrator
	 * Class Function Description: This class is used to listen the trigger level's text changing action.
	 */
	class TriggerLevelListener implements PropertyChangeListener{
		@Override
		public void propertyChange(PropertyChangeEvent evt) {
			double triggerLevel = ((Number)txtTriggerLevel.getValue()).doubleValue();
			
			// we set the valid value of trigger level between -10.0 and 10.0 
			if(triggerLevel < -10 || triggerLevel > 10){
				txtTriggerLevel.setValue(new Double(5.0));
				ShowMessage("The trigger level is invalid");
			}

		}
	}
	
	/**
	 * 
	 * @author Administrator
	 * Class Function Description: This class is used to listen the configure dialog's closing event.
	 */
	class WindowCloseActionListener extends WindowAdapter{
		@Override
		public void windowClosing(WindowEvent e) {
			if (isFirstLoad) {
				System.exit(0);
			}
		}
	}
}
