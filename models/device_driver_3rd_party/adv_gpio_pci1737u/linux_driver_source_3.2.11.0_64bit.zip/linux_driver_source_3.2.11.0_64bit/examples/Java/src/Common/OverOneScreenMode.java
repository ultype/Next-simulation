package Common;

public enum OverOneScreenMode {
	BeginScreen, 
	EndScreen
}
