package Common;

public enum FrequencyUnit {
	Hz, 
	KHz, 
	MHz
}
